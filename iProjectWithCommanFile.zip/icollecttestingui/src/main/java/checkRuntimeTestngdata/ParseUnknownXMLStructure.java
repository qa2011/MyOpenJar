package checkRuntimeTestngdata;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.*;


public class ParseUnknownXMLStructure
{
   public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException
   {
      //Get Document Builder
	   String file_path = "C:\\Users\\SUNNY\\Java_Learning\\JiraIntegrationWithSelenium-master\\src\\test\\java\\checkRuntimeTestngdata\\testng.xml"; 
      DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = factory.newDocumentBuilder();
       
      //Build Document
      Document document = builder.parse(new File(file_path));
       
      //Normalize the XML Structure; It's just too important !!
      document.getDocumentElement().normalize();
       
      //Here comes the root node
     Element root = document.getDocumentElement();
      System.out.println("Root>>>>>>> :"+root.getNodeName());
      
     // Node root_node = document.getFirstChild();

	
		Node suite_var = document.getElementsByTagName("include").item(1);

		// update staff attribute
		NamedNodeMap attr = suite_var.getAttributes();
		Node nodeAttr = attr.getNamedItem("name");
		nodeAttr.setTextContent("Regration");

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(new File(file_path));
		transformer.transform(source, result);
       
      //Get all employees
     /* NodeList nList = document.getElementsByTagName("employee");
      System.out.println("============================");
       
      visitChildNodes(nList);*/
   }
 
   //This function is called recursively
   private static void visitChildNodes(NodeList nList)
   {
      for (int temp = 0; temp < nList.getLength(); temp++)
      {
         Node node = nList.item(temp);
         if (node.getNodeType() == Node.ELEMENT_NODE)
         {
            System.out.println("Node Name = " + node.getNodeName() + "; Value = " + node.getTextContent());
            //Check all attributes
            if (node.hasAttributes()) {
               // get attributes names and values
               NamedNodeMap nodeMap = node.getAttributes();
               for (int i = 0; i < nodeMap.getLength(); i++)
               {
                   Node tempNode = nodeMap.item(i);
                   System.out.println("Attr name : " + tempNode.getNodeName()+ "; Value = " + tempNode.getNodeValue());
               }
               if (node.hasChildNodes()) {
                  //We got more childs; Let's visit them as well
                  visitChildNodes(node.getChildNodes());
               }
           }
         }
      }
   }
}
