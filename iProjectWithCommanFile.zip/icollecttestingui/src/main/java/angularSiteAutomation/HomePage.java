package angularSiteAutomation;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import com.paulhammant.ngwebdriver.ByAngular;


public class HomePage {

	//---------------Home Page--------------------
	public By homeBtn= ByAngular.buttonText("Home");
	public By customerLoginBtn= ByAngular.buttonText("Customer Login");
	public By bankManagerLoginBtn= ByAngular.buttonText("Bank Manager Login");
	
	//--------------Bank Manager Page---------------------	
	public By openAccountBtn= ByAngular.buttonText("Open Account");
	public By addCustomerBtn= ByAngular.buttonText("Add Customer");
	public By customerBtn= ByAngular.buttonText("Customers");
	
	//--------------Add Customer Page---------------------
	public By firstNameTxt=ByAngular.model("fName");
	public By lastNameTxt=ByAngular.model("lName");
	public By postCodeTxt=ByAngular.model("postCd");
	public By addNewCustomerBtn= By.xpath("//*[@type='submit']");
	
	
	//----------------Open Account----------------------
	
	public By customerDropDown=ByAngular.model("custId");
	public By currencyDropDown=ByAngular.model("currency");
	public By processBtn=By.xpath("//*[text()='Process']");
	
	//---------------custome Page------------------------
	public By searchCustomerTxt=ByAngular.model("searchCustomer");
	public By customerNameGet=By.xpath("//*[@class='ng-binding'][1]");
	public By customerAccountNoGet=By.xpath("//*[@class='ng-binding ng-scope'][1]");
	public By deleteBtn=ByAngular.buttonText("Delete");
	
	
	public String AddNewCustomer(String fname,String lname, String pcode) throws InterruptedException{
		AngularBankPageTest.driver.findElement(addCustomerBtn).click();
		Thread.sleep(5000);
		Thread.sleep(1000);
		AngularBankPageTest.driver.findElement(firstNameTxt).sendKeys(fname);
		AngularBankPageTest.driver.findElement(lastNameTxt).sendKeys(lname);
		AngularBankPageTest.driver.findElement(postCodeTxt).sendKeys(pcode);
		AngularBankPageTest.driver.findElement(addNewCustomerBtn).click();
		Thread.sleep(1000);
		Alert alert = AngularBankPageTest.driver.switchTo().alert();
		String msg=alert.getText();
		alert.accept();
		return msg;
	}
	
	public String OpenNewAccount(String custname, String selectcurrency) throws InterruptedException{
		AngularBankPageTest.driver.findElement(openAccountBtn).click();
		Thread.sleep(3000);
		Select cust=new Select(AngularBankPageTest.driver.findElement(customerDropDown));
		Thread.sleep(1000);
		cust.selectByVisibleText(custname); 
		//cust.selectByIndex(3);
		Thread.sleep(1000);
		Select currency=new Select(AngularBankPageTest.driver.findElement(currencyDropDown));
		Thread.sleep(1000);
		currency.selectByVisibleText(selectcurrency); 
		//cust.selectByIndex(3);
		Thread.sleep(2000);
		AngularBankPageTest.driver.findElement(processBtn).click();
		Thread.sleep(3000);
		Alert alert = AngularBankPageTest.driver.switchTo().alert();
		String msg=alert.getText();
		alert.accept();
		return msg;
	}
	
	public void DeleteCustomerAccount(String customename) throws InterruptedException{
		AngularBankPageTest.driver.findElement(customerBtn).click();
		Thread.sleep(2000);
		AngularBankPageTest.driver.findElement(searchCustomerTxt).sendKeys(customename);
		Thread.sleep(1000);
		String custName=AngularBankPageTest.driver.findElement(customerNameGet).getText();
		System.out.println("Customer Name : "+custName);
		Thread.sleep(1000);
		String custAccount=AngularBankPageTest.driver.findElement(customerAccountNoGet).getText();
		System.out.println("Customer Account No : "+custAccount);
		Thread.sleep(1000);
		AngularBankPageTest.driver.findElement(deleteBtn).click();
				
	}
	
	
	
	
	
	
	
	}
