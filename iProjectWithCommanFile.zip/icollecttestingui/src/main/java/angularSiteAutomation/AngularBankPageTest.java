/**
 * 
 */
package angularSiteAutomation;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.paulhammant.ngwebdriver.NgWebDriver;



public class AngularBankPageTest extends HomePage{

	static WebDriver driver;
	static NgWebDriver ngdriver;

	public static void main(String[] args) throws InterruptedException{
		HomePage obj=new HomePage();
		//System.setProperty("webdriver.chrome.driver","./chromedriver.exe");
		System.setProperty("webdriver.chrome.driver",".\\Drivers\\chromedriver.exe");
		//WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		//Sample AngularJs Webpage
		driver.get("http://www.way2automation.com/angularjs-protractor/banking/#/login");
		//driver.manage().window().maximize();
		Thread.sleep(10000);
		ngdriver = new NgWebDriver((JavascriptExecutor) driver);
		//ngdriver.w

		driver.findElement(obj.bankManagerLoginBtn).click();
		Thread.sleep(5000);


		String alertMsg_AddCustmor=obj.AddNewCustomer("Anurag", "Singh", "110096");
		System.out.println("Alert Message for Add New Customer : "+alertMsg_AddCustmor);

		Thread.sleep(5000);

		String alertMsg_OpenAccount=obj.OpenNewAccount("Anurag Singh", "Rupee");
		System.out.println("Alert Message for Open New Account : "+alertMsg_OpenAccount);

		Thread.sleep(5000);
		obj.DeleteCustomerAccount("Anurag");

		Thread.sleep(2000);

		driver.quit();

	}

}