package runTimeChangeTestngValue;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.testng.TestNG;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;


public class XmlUpdateCode
{
	public static String bugType="";
	public static String suiteStatus="";


	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException, InterruptedException
	{
		/*Scanner in = new Scanner(System.in);
		System.out. println("Please Enter Bug priority ");
		String s = in. nextLine();*/
		GetBugPriority test=new GetBugPriority();
		bugType=test.GetBugDetails();
		System.out.println("Getting BugType >>"+bugType);
		if(bugType.equalsIgnoreCase("2"))
		{
			suiteStatus="Regression";
			System.out.println("Regression Suite is Running");
		}
		else if(bugType.equalsIgnoreCase("3")){
			suiteStatus="Sanity";
			System.out.println("Sanity Suite is Running");
		}
		else{
			//System.out.println("Bug Type Not Define");
			suiteStatus="Sanity";
			System.out.println("Happy Path Suite is Running");
		}

		//Get Document Builder
		String file_path = "C:\\Users\\SUNNY\\Java_Learning\\JiraIntegrationWithSelenium-master\\src\\test\\java\\runTimeChangeTestngValue\\testng.xml"; 
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		//Build Document
		Document document = builder.parse(new File(file_path));

		//Normalize the XML Structure; It's just too important !!
		document.getDocumentElement().normalize();

		//Here comes the root node
		Element root = document.getDocumentElement();
		//System.out.println("Root>>>>>>> :"+root.getNodeName());

		// Node root_node = document.getFirstChild();


		Node suite_var = document.getElementsByTagName("include").item(0);

		// update staff attribute
		NamedNodeMap attr = suite_var.getAttributes();
		Node nodeAttr = attr.getNamedItem("name");
		nodeAttr.setTextContent(suiteStatus);

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(new File(file_path));
		transformer.transform(source, result);
		System.out.println("TestNg.XML updated");

		
		//------------Run TestNg File-------------
		// Create object of TestNG Class
		TestNG runner=new TestNG();

		// Create a list of String 
		List<String> suitefiles=new ArrayList<String>();

		// Add xml file which you have to execute
		suitefiles.add(file_path);

		// now set xml file for execution
		runner.setTestSuites(suitefiles);

		// finally execute the runner using run method
		runner.run();

	}
}
