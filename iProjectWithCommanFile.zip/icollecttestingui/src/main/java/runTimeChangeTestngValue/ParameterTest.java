package runTimeChangeTestngValue;

import org.testng.annotations.Test;

public class ParameterTest {
	
	@Test(groups={"Sanity"})
	public void testCase1() {
		System.out.println("Test cases_1 as :- Sanity");
	}
	
	@Test(groups={"Sanity"})
	public void testCase2() {
		System.out.println("Test cases_2 as :- Sanity");
	}
	
	@Test(groups={"Regression"})
	public void testCase3() {
		System.out.println("Test cases_3 as :- Regression");
	}
	
	@Test(groups={"Regression"})
	public void testCase4() {
		System.out.println("Test cases_4 as :- Regression");
	}
	
	@Test(groups={"Regression","Sanity"})
	public void testCase5() {
		System.out.println("Test cases_5 as :- Regression & Sanity");
	}
	
	@Test(groups={"Regression","Sanity"})
	public void testCase6() {
		System.out.println("Test cases_6 as :- Regression & Sanity");
	}
	

	
}