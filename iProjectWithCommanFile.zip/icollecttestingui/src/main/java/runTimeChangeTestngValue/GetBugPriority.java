package runTimeChangeTestngValue;

import java.util.ResourceBundle;

import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

class GetBugPriority {
	
	static String Getpriority="";
	
	public static void main(String agrs[]) throws InterruptedException{
		GetDetails();
		//Getpriority=GetBugDetails();
		//System.out.println(Getpriority);
	}
	
public static void GetDetails() throws InterruptedException{	
		
		RestAssured.baseURI=
				//"https://db-hcl.atlassian.net/rest/api/2/search?jql=project=DBGCS+and+issuetype=Bug";
		"https://db-hcl.atlassian.net/rest/api/2/issue/createmeta?DBGCS&Bug";
		
		/*RestAssured.baseURI=
		"https://db-hcl.atlassian.net/rest/api/2/project/10010";
		"https://db-hcl.atlassian.net/rest/api/latest/search?jql=project=DBGCS+and+issuetype=Bug";
		//"https://db-hcl.atlassian.net/rest/api/latest/search?jql=project=DBGCS+and+issuetype=Bug";
*/		
		
		//RestAssured.urlEncodingEnabled=true;

		PreemptiveBasicAuthScheme auth=new PreemptiveBasicAuthScheme();
		auth.setUserName("anuragsin@hcl.com");
		auth.setPassword("QTLn1lNF08VDtfkVlAw4A631");
		RestAssured.authentication=auth;
		
		RequestSpecification http=RestAssured.given();
		//http.header("content-type","application/json;charset=UTF-8");
		Response response=http.request(Method.GET);
		Thread.sleep(2000);
		String responseBody=response.asString();
		
		System.out.println("Response Body >>>>>> : "+responseBody);
		Thread.sleep(2000);
}
	
	public static String GetBugDetails() throws InterruptedException{
		
		 // clear the cache
	 /*     System.out.println("Clearing Cache...");
	      ResourceBundle.clearCache();
	      System.out.println("Cache Cleared.");*/
		
		RestAssured.baseURI=
		"https://db-hcl.atlassian.net/rest/api/latest/search?jql=project=DBGCS+and+issuetype=Bug";
		//"https://db-hcl.atlassian.net/rest/api/latest/search?jql=project=DBGCS+and+issuetype=Bug";
		//https://db-hcl.atlassian.net/rest/api/latest/search?jql=project=DBGCS+and+issuetype=Bug
		//RestAssured.urlEncodingEnabled=false;

		PreemptiveBasicAuthScheme auth=new PreemptiveBasicAuthScheme();
		auth.setUserName("anuragsin@hcl.com");
		auth.setPassword("QTLn1lNF08VDtfkVlAw4A631");
		RestAssured.authentication=auth;
		
		RequestSpecification http=RestAssured.given();
		Response response=http.request(Method.GET);
		Thread.sleep(2000);
		String responseBody=response.asString();
		
		System.out.println("Response Body >>>>>> : "+responseBody);
		Thread.sleep(2000);

		JSONObject jsonObject = new JSONObject(response.asString());
		String bug_id=jsonObject.getJSONArray("issues").getJSONObject(0).getString("key");
		System.out.println("Bug_ID >>  :"+bug_id);
		Thread.sleep(1000);
		
	/*	JSONArray arr=jsonObject.getJSONArray("issues");
		
		for (int i = 0; i < arr.length(); i++) {
			String bugId=arr.getJSONObject(i).getString("key");
			System.out.println("BugId_"+i+"). "+bugId);
			System.out.println("---------------------------------------------");
			Thread.sleep(1000);
		}
		*/
		
		System.out.println("=========================================================================");
		
		String summary=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields").getString("summary");
		System.out.println("Summary >>  :"+summary);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String description=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields").getString("description");
		System.out.println("Description >>  :"+description);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String name=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("priority").getString("name");
		System.out.println("priority_Name >>  :"+name);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String id=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("priority").getString("id");
		System.out.println("priority_ID >>  :"+id);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String statusName=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("status").getString("name");
		System.out.println("Status_Name >>  :"+statusName);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String statusId=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("status").getString("id");
		System.out.println("Status_Id >>  :"+statusId);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		int statusCategoryId=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("status").getJSONObject("statusCategory").getInt("id");
		System.out.println("statusCategory_ID >>  :"+statusCategoryId);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String statusCategoryKey=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("status").getJSONObject("statusCategory").getString("key");
		System.out.println("statusCategory_Key >>  :"+statusCategoryKey);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		
		String statusCategoryName=jsonObject.getJSONArray("issues").getJSONObject(0).getJSONObject("fields")
				.getJSONObject("status").getJSONObject("statusCategory").getString("name");
		System.out.println("statusCategory_ID >>  :"+statusCategoryName);
		Thread.sleep(1000);
		System.out.println("=========================================================================");
		return id;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
