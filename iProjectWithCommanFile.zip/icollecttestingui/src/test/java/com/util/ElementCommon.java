package com.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;

import com.Icollect.pages.UploadRRPage;

public class ElementCommon extends Setup {

	public By loginUserGetText = By.xpath("//*[@id='gtb_leftNav']//dt[2]");

	public By headerAfterModuleOpen = By.xpath("//*[@class='sectionStack']//*[@class='imgSectionHeaderTitleclosed']/div[1]");
	public By saveBtn_id = By.id("isc_Q");
	public By addNewBtn_id = By.id("isc_B");
	public By oldNewBtn = By.id("isc_B1");
	public By deleteInstBtnF8 = By.id("//*[text()='DEL INST (F8)']");

	public By userinfoBtn = By.xpath("(//*[contains(text(),'User')])[1]");
	public By userinfoBtnF10 = By.xpath("//*[text()='User Info (F10)']");
	public By userinfoBtnF10Capital = By.xpath("//*[text()='USER INFO. (F10)']");
	public By saveBtn = By.xpath("//span[text()='S']");
	public By saveBtn2 = By.xpath("(//*[contains(text(),'ave')])[2]");
	public By saveBtn3 = By.xpath("(//*[contains(text(),'ave')])[1]");
	public By saveBtn4 = By.xpath("(//*[contains(text(),'Save')])[1]");

	public By closeBtn = By.xpath("(//*[contains(text(),'lose')])[1]");
	public By addtogridBtn = By.xpath("//*[text()='Add To Grid']");
	public By cancleBtn = By.xpath("//*[text()='Cancel']");
	public By ModuleHeader = By.xpath("(//td[@class='content_tbltitle'])[1]");
	public By getFileter = By.xpath("(//*[contains(@eventproxy,'headerMenuButton')])[1]");
	public static By popupMessage = By.xpath("//*[@eventproxy='isc_globalWarn_messageStack']//td[@class='normal']");
	public By okBtn = By.xpath("//*[text()='OK']");
	public By okBtnF2 = By.xpath("//*[text()='OK(F2)']");
	public By okBtn2 = By.xpath("(//*[text()='OK'])[2]");
	public By okBtn3 = By.xpath("//*[text()='Ok']");
	public By okBtnRemarkPopup = By.xpath("//*[text()='Ok']");
	public By okBtnReject = By.xpath("//*[text()='Ok']");
	public static By okBtn4 = By.xpath("//*[text()='Ok (O)']");

	public By show_hide_filter = By.xpath("//*[text()='Show/Hide Filter']");
	public By userInfoHeader = By.xpath("(//*[@class='windowHeaderText'])[1]");
	public By makerName = By.xpath("(//*[@class='detail'])[1]");
	public By makerName_schLiqauth = By.xpath("(//*[@class='detail'])[5]");

	public By makerDateTime = By.xpath("(//*[@class='detail'])[3]");
	public By userInfoClose = By.xpath("(//*[@eventproxy='isc_userInfoWindow_0_closeButton'])");
	public By yesBtn = By.xpath("//*[text()='Yes']");
	public By yesBtn1 = By.xpath("//td[text()='Yes']");
	public By yesBtn2 = By.xpath("//*[text()='Yes (Y)']");
	public By addBtn = By.xpath("(//*[contains(text(),'Add')])[1]");
	public By clearBtn = By.xpath("(//*[text()='Clear ('])[1]");
	public By clearBtn_Y = By.xpath("(//*[@class='buttonTitleSelected'])[2]");

	public By detailsBtn = By.xpath("(//*[contains(text(),'Details')])[1]");
	public By addArrangementBtn = By.id("isc_G");
	public By noBtn = By.xpath("//*[text()='No (N)']");
	public By waitforFetching = By.xpath("//*[text()='Fetching dependent values']");
	public By waitforContactingServer = By.xpath("//*[text()='Contacting server...']");
	public static By GeneralFetchingDatapopup = By.id("isc_F");

	public By retrieveBtnF7 = By.xpath("//*[text()='Retrieve (F7)']");
	public By retrieveBtnF7Capital = By.xpath("//*[text()='RETRIEVE (F7)']");
	public By clearBtnF9 = By.xpath("//*[text()='Clear (F9)']");
	public By saveBtnF11 = By.xpath("//*[text()='Save (F11)']");
	public By saveBtnF11Capital = By.xpath("//*[text()='SAVE (F11)']");
	public By clearBtnF1 = By.xpath("//*[text()='Clear (F1)']");
	public By clearBtnF1Capital = By.xpath("//*[text()='CLEAR (F1)']");

	public By remarkTextField = By.xpath("//*[@name='remarks']");
	public By okBtnRejectpopup = By.id("isc_CI");
	public By cancleBtnRejectpopup = By.id("isc_CM");
	public By checkerActionGetText = By.xpath("((//*[@class='detailBlock'])[2]//*[@class='detail'])[4]");
	public By statusCheckerActionRejectPopupGetText = By.xpath("(//*[@class='detail'])[9]");
	public By rejectmsg = By.xpath("//*[text()='Rejected']");

	public By selectBtn = By.xpath("//*[text()='Select']");
	public By addInstF7Btn = By.xpath("//*[text()='ADD INST (F7)']");

	public By cancelBtnC = By.xpath("//*[text()='Cancel (C)']");
	public By nOBtnN = By.xpath("//*[text()='No (N)']");
	public By yesBtnY = By.xpath("//*[text()='Yes (Y)']");
	public By noItemToShowMsg = By.xpath("//*[text()='No items to show.']");
	public By cancleBtnALTQ = By.xpath("//*[text()='Cancel']");
	public By cancleBtnALTQ2 = By.xpath("(//*[text()='Cancel'])[2]");

	public By updateF2 = By.xpath("//*[text()='Update (F2)']");

	public By enrichBtnF2 = By.xpath("//*[text()='Enrich (F2)']");
	public By policyNoTextField = By.name("1_FIELD");
	public By addToGridBtnF3=By.xpath("//*[text()='Add To Grid (F3)']"); 
	public By addInstBtnF4=By.xpath("//*[text()='Add Inst (F4)']");

	public By backBtnF12=By.xpath("(//*[text()='Back (F12)'])[3]");
	public By downloadBtnF2=By.xpath("//*[text()='Download (F2)']");
	public By downloadBtnAllF9=By.xpath("//*[text()='Download All (F9)']");
	public By extractBtnF2=By.xpath("//*[@class='buttonTitleSelected']/div[1]");

	public By uploadF11 = By.xpath("//*[text()='Upload(F11)' and @unselectable='on']");

	/*
	 * 
	 * 
	 * 
	 * public By =By.xpath(""); public By =By.xpath("");
	 */

	/*
	 * public By
	 * waitforContactingServer=By.xpath("//*[text()='Contacting server...']");
	 * public By =By.xpath("//*[text()='ADD INST (F7)']"); public By =By.xpath("");
	 * public By =By.xpath("");
	 */

	public String username = null;

	public Boolean closeALTQ() throws InterruptedException {
		Weblocator.getWindowHandle();
		TimeUnit.SECONDS.sleep(2);
		Boolean status = Weblocator.Openlinks(cancleBtnALTQ);
		TimeUnit.SECONDS.sleep(1);

		if (status == false) {
			status = Weblocator.Openlinks(cancleBtnALTQ2);
			TimeUnit.SECONDS.sleep(1);
		}
		Weblocator.getWindowHandle();
		return status;

	}

	public void GeneralFetchingDataPopup() {
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Weblocator.getWindowHandle();
		Weblocator.Syncing_BufferingContent(GeneralFetchingDatapopup);
		Weblocator.getWindowHandle();
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void FetchingDataPopup() {
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Weblocator.getWindowHandle();
		Weblocator.Syncing_BufferingContent(waitforFetching);
		Weblocator.getWindowHandle();
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void ContactingServerDataPopup() {
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Weblocator.getWindowHandle();
		Weblocator.Syncing_BufferingContent(waitforContactingServer);
		Weblocator.getWindowHandle();
		try {
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String PopupHandle_dataSave() {
		String text="";
		Weblocator.getWindowHandle();
		boolean ispresent=Weblocator.IselementPresent(popupMessage);
		if (ispresent) {
			text = Weblocator.getPagetext(popupMessage);
			Weblocator.Openlinks(okBtn4);
			Weblocator.getWindowHandle();
		}
		else{
			Weblocator.getWindowHandle();
			System.out.println("Popup not present");
		}
		return text;
	}

	public void ClearPopupHandle() {
		try {
			Weblocator.getWindowHandle();
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(clearBtn_Y);
			Weblocator.getWindowHandle();
			Boolean present = Weblocator.IselementPresent(yesBtn2);
			if (present) {
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(yesBtn2);
				Weblocator.getWindowHandle();
			}
			Weblocator.getWindowHandle();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String loginUserName() {
		username = Weblocator.getPagetext(loginUserGetText);
		return username;

	}

	class classException extends Exception{
		UploadRRPage a;
		classException(UploadRRPage uploadRR) {
			a=uploadRR;
		}
		public String toString(){
			return ("Exception  =  "+a) ;
		}
	}

	public void icollectDB() {
		try{
			throw new classException(dashboard.uploadRR);
			// throw is used to create a new exception and throw it.
		}
		catch(classException e){
			// System.out.println(e) ;
		}
	}

	public void rejectRemark(String checkerName) {
		Weblocator.getWindowHandle();
		Weblocator.TextField(remarkTextField, checkerName+">> "+Weblocator.GetDateTime());
		Weblocator.Openlinks(okBtnRemarkPopup);
		Weblocator.getWindowHandle();
	}

}





















