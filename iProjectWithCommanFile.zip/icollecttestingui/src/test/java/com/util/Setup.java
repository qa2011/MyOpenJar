package com.util;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.Icollect.pages.CorrBankWithdrawalDispBankWiseAuthPage;
import com.Icollect.pages.CorrBankWithdrawalDispBankWisePage;
import com.Icollect.pages.DashboardPage;
import com.Icollect.pages.DeferredCollectionEntryAuthPage;
import com.Icollect.pages.DeferredCollectionEntryPage;
import com.Icollect.pages.DeferredEnrichmentEntryAuthPage;
import com.Icollect.pages.DeferredEnrichmentEntryPage;
import com.Icollect.pages.DeferredRemarksEntryAuthPage;
import com.Icollect.pages.DeferredRemarksEntryPage;
import com.Icollect.pages.DispatchAllocationAuthPage;
import com.Icollect.pages.DispatchAllocationPage;
import com.Icollect.pages.DownloadSchedulePage;
import com.Icollect.pages.InstrumentLiqStatReversalAuthPage;
import com.Icollect.pages.InstrumentLiqStatReversalPage;
import com.Icollect.pages.InstrumentLiquidationAuthPage;
import com.Icollect.pages.InstrumentLiquidationPage;
import com.Icollect.pages.InstrumentReceiptAuthPage;
import com.Icollect.pages.InstrumentReceiptPage;
import com.Icollect.pages.LoginPage;
import com.Icollect.pages.TransactionUploadAuthPage;
import com.Icollect.pages.TransactionUploadPage;
import com.Icollect.pages.TransactionsPage;
import com.Icollect.pages.UploadRRPage;
import com.Icollect.pages.scheduleLiquidationAuthPage;
import com.Icollect.pages.scheduleLiquidationPage;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;

public class Setup {

	public static WebDriver driver;

	ReadConfig readconfig=new ReadConfig();
	public String baseURL=readconfig.getApplicationURL();
	public String makerName=readconfig.getMakerName();
	public String checkerName=readconfig.getCheckerName();
	public String password=readconfig.getPassword();
	public String homeURL=readconfig.getHomeURL();
	public String excelPath=readconfig.getExcelPath();

	public static LoginPage login;
	public static ElementCommon elecomm;
	public static DashboardPage dashboard;
	public static TransactionsPage trns;
	public static DeferredCollectionEntryPage deferredcollEntry;
	public static DeferredCollectionEntryAuthPage deferredcollEntryAuth;
	public static DeferredEnrichmentEntryPage  enrichmentEntry;
	public static DeferredEnrichmentEntryAuthPage  enrichmentEntryAuth;
	public static DeferredRemarksEntryPage remarksEntry; 
	public static DeferredRemarksEntryAuthPage remarksEntryAuth; 
	public static InstrumentLiquidationPage instLiq;
	public static InstrumentLiquidationAuthPage instLiqAuth;
	public static InstrumentReceiptPage instReceipt;
	public static InstrumentReceiptAuthPage instReceiptAuth;
	public static scheduleLiquidationPage schLiq;
	public static scheduleLiquidationAuthPage schLiqAuth;
	public static InstrumentLiqStatReversalPage instLiqStatReversal;
	public static InstrumentLiqStatReversalAuthPage instLiqStatReversalAuth;
	public static DispatchAllocationPage dispAllocation;
	public static DispatchAllocationAuthPage dispAllocationAuth;
	public static CorrBankWithdrawalDispBankWisePage corrbankwithbank;
	public static CorrBankWithdrawalDispBankWiseAuthPage corrbankwithbankAuth;
	public static DownloadSchedulePage downloadSch;
	public static TransactionUploadPage tranUpload;
	public static TransactionUploadAuthPage tranUploadAuth;
	public static UploadRRPage uploadRR;

	public String excel_sheetname="iCollectData";
	public static int row;
	public String batchno="";
	public String instrument_No="";
	public String depositNo="";
	public String thereRefNo="";
	public String thereRefNo_Y="";
	public String thereRefNoGet="";
	public String ReceiptAuth_ForSchLiq="";
	public String instStatusreversalAuth="";
	public String schduleno="";

	@BeforeSuite
	public void beforeSuite() {
		System.out.println(" Before Suite");
	}

	@BeforeTest
	public void beforeTest() throws BiffException, IOException {
		System.out.println(" Before Test");

		//------------------------
		Weblocator.ReadExcel();
		for (int i = 1; i < Weblocator.sh.getRows(); i++) // Read data from excel sheet
		{	
			if (Weblocator.sh.getCell(0,i).getContents().equals("NEW")) {
				row=i;
				batchno=Weblocator.sh.getCell(1,i).getContents();
				instrument_No=Weblocator.sh.getCell(3,i).getContents();
				depositNo=Weblocator.sh.getCell(6,i).getContents();
				thereRefNo=Weblocator.sh.getCell(2,i).getContents();
				thereRefNoGet=Weblocator.sh.getCell(2,i).getContents();
				schduleno=Weblocator.sh.getCell(9,i).getContents();

				if (Weblocator.sh.getCell(4,i).getContents().equalsIgnoreCase("Y")) {
					row=i;
					thereRefNo_Y=Weblocator.sh.getCell(2,i).getContents();
				}
				if(Weblocator.sh.getCell(7,i).getContents().equalsIgnoreCase("Y")) {
					row=i;
					ReceiptAuth_ForSchLiq=thereRefNo;
				}
				if(Weblocator.sh.getCell(8,i).getContents().equalsIgnoreCase("Y")) {
					row=i;
					instStatusreversalAuth=thereRefNo;
				}
				break;
			}
		}

		//-----------------

	}

	//---------------before class------
	@Parameters("ModuleName")
	@BeforeMethod
	public void beforeMethod(String Module) {
		System.out.println(" Before Method");
		boolean exception = false;
		try {	
			Weblocator.explicitWait(2);
			
			Boolean homeBtnPresent=false;
			homeBtnPresent=driver.findElements(dashboard.homewithSelected).size()!=0;
			//boolean homebtn=Elements.IselementPresent(dashboard.homewithSelected);
			if(homeBtnPresent) {
				//Elements.Openlinks(dashboard.transactions);
				//Elements.Openlinks(dashboard.home);
			}
			else {
				Weblocator.Openlinks(dashboard.home);
			}
			Weblocator.explicitWait(5);
			if(Module.equals("DataEntryAndAuthPage")) {
				dashboard.Transaction();
			}
			else if (Module.equals("DeferredCollectionEntryPage")) {
				dashboard.DeferredCollectionEntryPage();
			}
			else if(Module.equals("DeferredCollectionEntryPage")) {
				dashboard.DeferredCollectionEntryPageAuth();
			}
			else if(Module.equals("DeferredEnrichmentEntryPageTest")) {
				dashboard.DeferredEnrichmentEntry();
			}
			else if(Module.equals("DeferredEnrichmentEntryPageTest")) {
				dashboard.DeferredEnrichmentEntryAuth();
			}
			else if(Module.equals("InstrumentLiquidationPageTest")) {
				dashboard.InstrumentLiquidation();
			}
			else if(Module.equals("InstrumentLiquidationPageAuthTest")) {
				dashboard.InstrumentLiquidationAuth();
			}
			else if(Module.equals("InstrumentReceiptPageTest")) {
				dashboard.InstrumentReceipt();
			}
			else if(Module.equals("InstrumentReceiptPageTest")) {
				dashboard.InstrumentReceipt();
			}
			else if(Module.equals("DeferredRemarksEntryPageTest")) {
				dashboard.DeferredRemarksEntry();
			}
			else if(Module.equals("DeferredRemarksEntryPageTest")) {
				dashboard.DeferredRemarksEntryAuth();
			}
			else if(Module.equals("scheduleLiquidationPageTest")) {
				dashboard.scheduleLiquidation();
			}
			else if(Module.equals("scheduleLiquidationPageAuthTest")) {
				dashboard.scheduleLiquidationAuth();
			}
			else if(Module.equals("InstrumentLiqStatReversalPageTest")) {
				dashboard.InstrumentLiqStatReversal();
			}
			else if(Module.equals("InstrumentLiqStatReversalPageAuthTest")) {
				dashboard.InstrumentLiqStatReversalAuth();
			}
			else if(Module.equals("DownloadScheduleTest")) {
				dashboard.DownloadSchedule();
			}
			else if(Module.equals("DispatchAllocationTest")) {
				dashboard.DispatchAllocation();
			}
			else if(Module.equals("CorrBankWithdrawalDispBankWise")) {
				dashboard.CorrBankWithdrawalDispBankWise();
			}
			else if(Module.equals("TransactionUpload")) {
				dashboard.TransactionUpload();
				//Elements.AlertAccept();
			}
			else if(Module.equals("UploadRR")) {
				Weblocator.explicitWait(1);
				dashboard.UploadReject();
				Weblocator.explicitWait(1);
			}
			/*
			else if(Module.equals("")) {
				dashboard.();
			}
			else if(Module.equals("")) {
				dashboard.();
			}*/
		

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
	}

	@AfterSuite
	public void afterSuite() throws BiffException, IOException, WriteException {
		System.out.println(" After Suite");
	}

	@AfterTest
	public void afterTest() {
		System.out.println(" After Test");
	}

	//------------after class----------

	@AfterMethod()
	public void afterMethod()  {
		System.out.println(" After Method");

	}

	@BeforeClass
	public void beforeClass()
	{			
		System.out.println(" Before Class");
		Logger.getLogger("DB_iCollect");
		PropertyConfigurator.configure(System.getProperty("user.dir")+"\\src\\test\\resources\\Log4j.properties");

		login=new LoginPage();
		dashboard=new DashboardPage();
		elecomm=new ElementCommon();
		trns=new TransactionsPage();
		deferredcollEntry=new DeferredCollectionEntryPage();
		deferredcollEntryAuth=new DeferredCollectionEntryAuthPage();
		enrichmentEntry=new DeferredEnrichmentEntryPage();
		enrichmentEntryAuth=new DeferredEnrichmentEntryAuthPage();
		remarksEntry=new DeferredRemarksEntryPage();
		remarksEntryAuth=new DeferredRemarksEntryAuthPage();
		instLiq=new InstrumentLiquidationPage();
		instLiqAuth=new InstrumentLiquidationAuthPage();
		instReceipt=new InstrumentReceiptPage();
		instReceiptAuth=new InstrumentReceiptAuthPage();
		schLiq=new scheduleLiquidationPage();
		schLiqAuth=new scheduleLiquidationAuthPage();
		instLiqStatReversal=new InstrumentLiqStatReversalPage();
		instLiqStatReversalAuth=new InstrumentLiqStatReversalAuthPage();
		dispAllocation=new DispatchAllocationPage();
		dispAllocationAuth=new DispatchAllocationAuthPage();
		corrbankwithbank=new CorrBankWithdrawalDispBankWisePage();
		corrbankwithbankAuth=new CorrBankWithdrawalDispBankWiseAuthPage();
		downloadSch=new DownloadSchedulePage();
		tranUpload=new TransactionUploadPage();
		tranUploadAuth=new TransactionUploadAuthPage();
		uploadRR=new UploadRRPage();

		System.setProperty("webdriver.chrome.driver",readconfig.getChromePath());
		//System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,"null");
		
		//WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.silentOutput","true");
		driver=new ChromeDriver();
		System.out.println(driver.manage().window().getSize());
		Dimension d = new Dimension(1382,744);
		driver.manage().window().setSize(d);
		//driver.manage().window().maximize();
		driver.manage().deleteAllCookies();  // Delete all cookies*/	
		Weblocator.BrowserAndOSDetails();
		//System.out.println(driver.manage().window().getSize());

		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		driver.get(baseURL);
		Boolean status=login.login("anuragsin@hcl.com");
		Assert.assertTrue(status, "iCollect URL Not Working.");
		
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("return window.stop");*/
		
		driver.findElement(By.tagName("body")).sendKeys("Keys.ESCAPE");
		
		
	}

	@AfterClass
	public void afterClass() throws IOException
	{
		System.out.println(" After Class");
	
		//if(System.getProperty("os.name").contains("WINDOWS")) {
			Process process = Runtime. getRuntime(). exec("taskkill /F /iM cmd.exe");
			process.destroy();
		//}
		driver.quit();
	}



}
