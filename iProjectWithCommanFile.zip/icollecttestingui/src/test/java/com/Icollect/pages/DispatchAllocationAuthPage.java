package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DispatchAllocationAuthPage extends Setup{
	
    //public By = By.xpath("");
	public By productCodeTextField= By.name("searchProductCode");
	public By clearingLocTextFiled= By.name("searchClearingLoc");
	
	public By searchBtnFirstRow= By.xpath("(//*[@role='listitem']/td[1]/div[1])[2]");
	public By authCheckboxFirstRow= By.xpath("(//*[@role='listitem']/td[8]/div[1]/span[1])[1]");
	public By authCheckboxAll= By.xpath("//*[text()='Auth(F2)']");
	public By rejectCheckboxFirstRow= By.xpath("(//*[@role='listitem']/td[9]/div[1]/span[1])[1]");
	public By clrgLocFilter= By.xpath("(//*[@role='listitem']/td[2]//input[1])[1]");
	public By clearingLocTextField= By.name("searchClearingLoc");
	public By clrgLocFirstRow= By.xpath("(//*[@role='listitem']/td[2]/div[1])[2]");
	
	
	
	public boolean retrieveBtn(String product, String clearingLoc) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.explicitWait(1);
		Weblocator.TextField(productCodeTextField, product);
		Weblocator.explicitWait(1);
		Weblocator.TextField(clearingLocTextField, clearingLoc);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(3);
		status=Weblocator.IselementPresent(searchBtnFirstRow);
		return status;
	}
	
	public String reject() {
		Weblocator.Openlinks(rejectCheckboxFirstRow);
		Weblocator.explicitWait(1);
		elecomm.rejectRemark(elecomm.loginUserName());
		Weblocator.explicitWait(1);
		String color=driver.findElement(clrgLocFirstRow).getCssValue("color"); //color code: #FF0000
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(3);
		return color;
	}
	
	public String auth() {
		Weblocator.Openlinks(authCheckboxAll);
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		elecomm.PopupHandle_dataSave();
		String msg=Weblocator.getPagetext(elecomm.noItemToShowMsg);
		return msg;
	}
	
	
	

}
    
    
    
    
    
    
    
    
