package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class CorrBankWithdrawalDispBankWiseAuthPage extends Setup{

	//public By = By.xpath("");
	public By makerNametextField= By.name("searchMakerCode");
	public By searchReferenceNoTextfield= By.name("searchReferenceNo");
	public By refrencenoFirstRow= By.xpath("(//*[@role='listitem' ]/td[1]/div[1])[2]");
	public By authCheckBox= By.xpath("(//*[@role='listitem' ]/td[10]/div[1])[2]/span[1]");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem' ]/td[11]/div[1])[2]/span[1]");

	public boolean retrieve(String makername , String reference) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1Capital);
		Weblocator.TextField(makerNametextField, makername);
		Weblocator.TextField(searchReferenceNoTextfield, reference);
		Weblocator.Openlinks(elecomm.retrieveBtnF7Capital);
		status=Weblocator.IselementPresent(refrencenoFirstRow);
		return status;
	}

	public boolean reject() {
		boolean status=false;
		Weblocator.Openlinks(rejectCheckBox);
		elecomm.rejectRemark(checkerName);
		status=Weblocator.Openlinks(elecomm.saveBtnF11Capital);
		Weblocator.explicitWait(5);
		/*WebDriverManager.Openlinks(elecomm.userinfoBtnF10Capital);
		WebDriverManager.getWindowHandle();
		String msg=WebDriverManager.getPagetext(elecomm.rejectmsg);
		WebDriverManager.Openlinks(elecomm.userInfoClose);
		WebDriverManager.getWindowHandle();*/
		return status;
	}


	public String auth() {
		Weblocator.Openlinks(authCheckBox);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.saveBtnF11Capital);
		Weblocator.explicitWait(2);
		String msg=Weblocator.getPagetext(elecomm.noItemToShowMsg);
		return msg;
	}


}








