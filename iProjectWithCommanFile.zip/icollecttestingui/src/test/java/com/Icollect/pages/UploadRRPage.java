package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.util.Weblocator;
import com.util.Setup;

public class UploadRRPage extends Setup{
	public static String testdata=null;
	//public By = By.xpath("");

	public By breadcrumbNavigation= By.xpath("//*[text()='Client Input > Transaction Upload Reject Repair']");
	public By batchNumberLabel= By.xpath("//*[text()='Batch Number']");
	public By batchNumberLabelTextFiled= By.xpath("//*[@name='batchNo']");
	public By batch= By.xpath("(//*[@class='formTitleDisabled'])[4]/nobr/label");  //C
	public By batchTextField= By.xpath("//*[@name='batchNo']");//c
	public By batchTextFieldgetBatch= By.xpath("(//*[@name='batchNo'])[1]");//c
	public By status= By.xpath("(//*[@class='formTitleDisabled']//label[text()='Status'])");//c
	public By statusTextField= By.name("batchStatusFlag");//c	
	public By statusTextFieldgetText= By.xpath("(//*[@name='batchStatusFlag'])[1]");//c	
	public By PDCBatch= By.xpath("(//*[@class='formTitleDisabled']//label[text()='PDC Batch'])");//c
	public By PDCBatchRadioBtn_yes= By.xpath("(//*[@name='batchType'])[1]");//c
	public By PDCBatchRadioBtn_no= By.xpath("(//*[@name='batchType'])[2]");	//c
	public By TheirReference= By.xpath("(//*[@class='formTitle']//label[text()='Their Reference'])");//c
	public By TheirReferenceTextField= By.name("referenceNo");//c
	public By PickupLocation= By.xpath("(//*[@class='formTitle']//label[text()='Pickup Location'])");//c
	public By PickupLocationTextField= By.name("pickUpLocCode");//c
	public By PickupLocationTextFieldgetText= By.xpath("(//*[@name='pickUpLocCode'])[1]");//c
	public By PickupDt= By.xpath("(//*[@class='formTitle']//label[text()='Pickup Date'])");//c
	public By PickupDt_date= By.name("pickUpDate");//c
	public By PickupDt_dategetText= By.xpath("(//*[@name='pickUpDate'])[1]");//c

	public By productLabel= By.xpath("(//*[text()='Product'])[1]");
	public By Product= By.xpath("(//*[@class='formTitleDisabled'])[5]/nobr/label");
	public By productLabelTextField= By.xpath("(//*[@name='productCode'])[1]");
	public By ProductTextField= By.xpath("(//*[@name='productCode'])[2]");
	public By ProductTextFieldgetText= By.xpath("(//*[@name='productCode'])[1]");
	public By ActivationDt= By.xpath("//*[@class='formTitle']//label[text()='Activation Date']");
	public By ActivationDt_dateLabel= By.xpath("(//*[text()='Activation Date'])[1]");
	public By ActivationDt_date= By.xpath("(//*[@name='activationDate'])[2]");
	public By ActivationDt_dategetText= By.xpath("(//*[@name='activationDate'])[1]");
	public By DispBank= By.xpath("//*[@class='formTitle']//label[text()='Dispatch Bank']");
	public By DispBankTextField= By.name("dispatchBankCode");
	public By DispBankTextFieldgetText= By.xpath("(//*[@name='dispatchBankCode'])[1]");
	public By DispBranch= By.xpath("//*[@class='formTitle']//label[text()='Dispatch Branch']");
	public By DispBranchTextField= By.name("dispatchBranchCode");
	public By DispBranchTextFieldgetText= By.xpath("(//*[@name='dispatchBranchCode'])[1]");
	public By ArrangementLabel= By.xpath("(//*[text()='Arrangement'])[1]");
	public By Arrangement= By.xpath("(//*[@class='formTitle']//label[text()='Arrangement'])[2]");
	public By ArrangementTextField= By.name("arrangementCode");
	public By ArrangementTextFieldgetText= By.xpath("(//*[@name='arrangementCode'])[1]");
	public By TotalDep= By.xpath("//*[@class='formTitle']//label[text()='Total Dep']");
	public By TotalDepTextField= By.name("totalDeposits");
	public By TotalDepTextFieldgetText= By.xpath("(//*[@name='totalDeposits'])[1]");
	public By TotalAmnt= By.xpath("//*[@class='formTitle']//label[text()='Total Amount']");
	public By TotalAmntField= By.name("totalAmount");
	public By TotalAmntFieldgetText= By.xpath("(//*[@name='totalAmount'])[1]");
	public By RemarksLabel= By.xpath("(//*[text()='Remarks'])[1]");
	public By Remarks= By.xpath("(//*[@class='formTitle']//label[text()='Remarks'])[2]");
	public By RemarkTextField= By.name("frmrejectReason");
	public By RemarksTextField= By.xpath("(//*[@name='depositRemarks'])");
	public By ReportedDep= By.xpath("//*[@class='formTitle']//label[text()= 'Reported Dep']");
	public By ReportedDepTextField= By.name("actualDeposits");
	public By ReportedDepTextFieldgetText= By.xpath("(//*[@name='actualDeposits'])[1]");
	public By ReportedAmntLabel= By.xpath("(//*[text()='Reported Amount'])[1]");
	public By ReportedAmnt= By.xpath("//*[@class='formTitle']//label[text()='Reported Amnt.']");
	public By ReportedAmntTxtFiled= By.name("actualAmount");
	public By ReportedAmntTextFiled= By.xpath("(//*[@name='actualAmount'])[2]");
	public By ReportedAmntTextFiledgetText= By.xpath("(//*[@name='actualAmount'])[1]");

	//-----------------------------------------Buttons On Upload RR page

	public By saveBtnEnabled= By.xpath("//*[@class='buttonTitleSelected']//div[text()='Save (F11)']");
	public By saveBtnDisabled= By.xpath("//*[@class='buttonTitleSelectedDisabled']//div[text()='Save (F11)']");
	public By saveBtnn= By.xpath("(//*[text()='Save (F11)'])[1]");

	public By saveBtn= By.xpath("//*[text()='Save (F11)']");
	public By clearButton= By.xpath("(//*[text()='Clear (F1)'])[1]");
	public By clearBtn= By.xpath("(//*[text()='Clear (F1)'])[2]");
	public By retrieveBtn= By.xpath("//*[text()='Retrieve (F7)']");
	public By userInfoBtn= By.xpath("(//*[@class='buttonTitleSelected']//div[text()='User Info (F10)'])[2]");


	//-------
	public By backBtn= By.id("isc_FN");
	public By userInfoBtnID= By.id("isc_FR");
	public By summaryBtn= By.id("isc_FV");
	public By batchSearch= By.id("isc_J5");
	public By batchNoGetFromBatchSummary= By.xpath("(//*[@role='listitem'])[2]/td[3]/div");

	//------------------------instrument
	public By instrumentNoTextField= By.name("instrumentNo");
	public By draweeBranchCodeTextFiled= By.name("draweeBranchCode");
	public By instrumentAmountTextFiled	= By.name("instrumentAmount");
	public By instrumentDateStrTextFiled= By.name("instrumentDateStr");
	public By batchFromTextField= By.name("searchBatchNo");
	public By batchToTextField= By.name("searchBatchTo");



	///////----------auth-------
	public By selectBatchNo= By.xpath("(//*[@role='listitem'])[2]/td[2]");
	public By authCheckBox= By.xpath("(//*[@role='listitem'])[4]/td[11]//span[1]");
	public By authCheckBoxforABIL= By.xpath("(//*[@class='headerTitle'])[10]");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem'])[4]/td[12]//span[1]");
	public By batchNoFromBatchSummary= By.xpath("(//*[@role='listitem'])[2]/td[3]/div");
	public By emptyMsg= By.xpath("//*[text()='No items to show.']");


	//**********************************************************************************************
	//*******************************************************************************************

	//---------------------Search Buttons -----------------------------------
	public By searchByBatchNo= By.xpath("(//*[@role='listitem'])[1]/td[3]//input");
	public By searchByProduct= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");
	public By searchByPickupdate= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");
	public By searchByPickupLocation= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");
	public By searchByTotalDep= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");
	public By searchByTotalAmt= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");
	public By searchByPDC= By.xpath("(//*[@role='listitem'][1])[1]/td[3]//input");


	//---------------------Gird Headers -----------------------------------
	public By DF2Header= By.xpath("(//*[@class='headerTitle']//div[text()='D(+) (F2)'])");
	public By InfoHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Info'])");
	public By batchNoHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Batch #'])");
	public By productHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Product'])");
	public By pickupDateHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Pickup Date'])");
	public By pickupLocHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Pickup Location'])");
	public By totalDepHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Dep'])");
	public By totalAmtHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Amount'])");
	public By PDCHeader= By.xpath("(//*[@class='headerTitle']//div[text()='PDC?'])");
	public By modfyHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Mod (F4)'])");
	public By delHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Del (F3)'])");


	//----------------------------Table Records Existence---------------
	public By rejtdRcrdTable= By.xpath("(//*[@class='listTable'][1])[2]");
	public By F2rejtdRcrd= By.xpath("(//*[@class='listTable'][1])[2]//tr[1]/td[1]");
	public By EditrejtdRcrd= By.xpath("(//*[@class='listTable'][1])[2]//tr[1]/td[10]");
	public By rejtdRcrdBatchno= By.xpath("(//*[@class='listTable'][1])[2]//tr[1]/td[3]//div");
	public By DeleteRejRec= By.xpath("(//*[@class='listTable'][1])[2]//tr[1]/td[11]//span");



	//----------------------deposit TAB-----------
	public By DepositTabSelected = By.xpath("(//*[@class='tabTitleSelected'][text()='Deposit'])");
	public By DepositEntryheader= By.xpath("//*[text()='Deposit Entry']");
	public By DepIF2Header= By.xpath("//*[@class='headerTitle']//div[text()='I(+) (F2)'])");
	public By DepInfoHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Info'])");
	public By DepSF9= By.xpath("((//*[@class='headerTitle']//div[text()='S(+) (F9)']))");
	public By DepClientHeadr= By.xpath("(//*[@class='headerTitle']//div[text()='Client'])");
	public By DepArngmntHeadr= By.xpath("(//*[@class='headerTitle']//div[text()='Arrangement'])");
	public By DeppckupPointHeader= By.xpath("((//*[@class='headerTitle']//div[text()='Pickup Point']))");
	public By DepDateHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Dep'])");
	public By DepNoHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Amount'])");
	public By DepTotalInsHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Inst.'])");
	public By DepTotalAmtHeader= By.xpath("(//*[@class='headerTitle']//div[text()='Total Amnt.'])");
	public By DepModHeader= By.xpath("((//*[@class='headerTitle']//div[text()='Mod (F4)'])[2])");
	public By F2Inst= By.xpath("(//tr[@role='listitem']/td[@class='instRejCellSelected'][1])");
	public By EditDept= By.xpath("(//tr[@role='listitem']/td[@class='instRejCellSelected'][10])");
	public By PickupLocDept= By.xpath("//input[@name='pickUpPointCode']");
	public By DeptSaveBtn= By.xpath("(//*[text()='Save (F11)'])[2]");
	public By backBtn_f12= By.xpath("//*[text()='Back (F12)']");	
	public By DepEditrejtdRcrd= By.xpath("(//*[@class='listTable'])[4]//tr[1]//td[10]");
	public By batchNo= By.xpath("(//label[text()='Batch #'])");
	public By DepTotalAmntField= By.xpath("(//*[@name='totAmount'])[1]");
	public By DepReportedAmnt= By.xpath("//*[@class='formTitle']//label[text()='Reported Amnt.']");
	public By DepArrangementCodeText= By.xpath("(//*[@name='depositArrangementCode'])[1]");
	//public By DepArrangementCode= By.xpath("//*[@class='formTitleDisabled']//label[text()='Arrangement']");
	public By DepActivationDate= By.xpath("(//*[@class='formTitleDisabled'])[6]/nobr/label");
	public By DepDate = By.xpath("//*[@class='formTitle']//label[text()='Dep. Dt.']");
	public By DepDateText= By.xpath("(//*[@name='depositDate'])[1]");
	public By Summary = By.xpath("//*[@class='formTitle']//label[text()='Summary #']");
	public By SummaryText= By.name("depositSummaryNo");
	public By TotalInst= By.xpath("//*[@class='formTitle']//label[text()='Total Inst.']");
	public By totalInstTextfield= By.xpath("(//*[@name='totInstruments'])[1]");
	public By totalAmountTextfield= By.xpath("(//*[@name='totAmount'])[1]");
	public By ReportedInst= By.xpath("//*[@class='formTitle']//label[text()='Reported Inst.']");
	public By ReportedInsttxt= By.name("actualInstruments");
	public By totalStub= By.xpath("//*[@class='formTitle']//label[text()='Total Stubs']");
	public By totalStubtxt= By.xpath("(//*[@name='depositTotStubs'])[1]");
	public By client= By.xpath("//*[@class='formTitle']//label[text()='Client']");
	public By clientCodeTxt= By.name("clientCode");
	public By pickupPoint= By.xpath("//*[@class='formTitle']//label[text()='Pickup Point']");
	public By pickupPointTxt= By.xpath("(//*[@name='pickUpPointCode'])[1]");
	public By depNo= By.xpath("//*[@class='formTitle']//label[text()='Dep. #']");
	public By depNoText= By.xpath("(//*[@name='inputDepositNo'])[1]");
	public By payerId= By.xpath("//*[@class='formTitleDisabled']//label[text()='Payer ID']");
	public By payerIdText= By.name("payerId");
	public By depTotalAmt= By.xpath("//*[@class='formTitle']//label[text()='Total Amnt.']");
	public By depTotalAmtTxt= By.name("totAmount");
	public By balanceDep= By.xpath("//*[@class='formTitle']//label[text()='Balance Dep.']");
	public By balanceDepText= By.name("balanceDeposit");
	public By balanceAmnt= By.xpath("//*[@class='formTitle']//label[text()='Balance Amnt.']");
	public By balanceAmntText= By.name("balanceAmount");
	public By totalDep= By.xpath("//*[@class='formTitleDisabled']//label[text()='Total Dep.']");
	public By totalDepTextField= By.xpath("(//*[@name='totalCount'])[1]");
	public By totalAmntOfDep= By.xpath("//*[@class='formTitleDisabled']//label[text()='Total Amnt.']");
	public By totalAmntOfDepTextField= By.xpath("(//*[@name='totalAmount'])[2]");

	//-----------------------------UserDetails Popup--------------------------------------------------
	public By UserDetailsPopup= By.xpath("(//*[@class='windowHeader']//td[text()='User Details'])");
	public By RmarksUserInfo= By.xpath("(//*[@class='windowBody']//div[2]//tr[5]/td[2])");
	public By PopupClosebtn= By.xpath("(//*[@Class='imgButton'][@eventproxy='isc_userInfoWindow_1_closeButton'])");
	//-------------------Rej Reason on Inst Screen--------------	
	public By RejRsnOnInsTable= By.xpath("(//*[@class='listTable'])[5]//tr[1]/td[10]//div");
	public By InstDtonInstTable1= By.xpath("(//*[@class='listTable'])[5]//tr[1]/td[5]//div");
	public By InstDtonInstTable= By.xpath("(//*[@class='listTable'])[5]//tr[1]/td[5]//div/span/input");
	public By InstSaveBtn= By.xpath("(//*[text()='Save (F11)'])[3]");
	// --------------------------Dialog box Buttons-----------------
	public By YesBtn= By.xpath("//div[@class='dialogBackground']//td[text()='Yes (Y)']");
	public By NoBtn= By.xpath("//div[@class='dialogBackground']//td[text()='No (N)']");

	//validatRjctdRcrdAvlbl() accepts the Batch# and validates if the batch is available in rejected list
	public boolean validat_RjctdRcrd(String batchNo) {
		boolean status=false;
		Weblocator.TextField(searchByBatchNo, batchNo);
		Weblocator.explicitWait(1);
		Weblocator.PressEnterBtn(searchByBatchNo);
		Weblocator.explicitWait(3);
		status=Weblocator.IselementPresent(rejtdRcrdBatchno);
		Weblocator.explicitWait(3);
		return status;
	}

	public String Open_First_RejRecord() {

		
		Weblocator.Openlinks(F2rejtdRcrd);						
		Weblocator.explicitWait(3);	
		Weblocator.Openlinks(userInfoBtn);
		Weblocator.getWindowHandle();
		String msg=Weblocator.getPagetext(RmarksUserInfo);
		Weblocator.Openlinks(PopupClosebtn);	
		Weblocator.getWindowHandle();
		return msg;	
	}

	//Update_RejRecord() clicks on +icon on first row in the grid on Upload RR screen.
	//Pre-condition:- should be run post Method(Open_First_RejRecord) run 
	//Input: Rejection Reason returned from Open_First_RejRecord.
	public void Update_RejRecord(String Rej_Reason) 
	{	
		String  Rej_Reason1 = "Inst Level errors exist,Inst Level errors exist";
		String  Rej_Reason2 = "Invalid Client-Pickuppt";
		 	 
		if (Rej_Reason1.equalsIgnoreCase(Rej_Reason) )
		{
			Update_Inst();		 		 
		}
		else if (Rej_Reason2.equalsIgnoreCase(Rej_Reason))
		{		 	 	  	 	 
			Update_Dep_With_Location();	 
		}

	}

	//Update_Inst() updates the instrument with the valid data(date, Branch etc.) as per the error found
	//Pre-condition:- should be run post Method(Update_RejRecord) run 
	public void Update_Inst()
	{	
		String  Rej_Reason      = null;
		String  Rej_Reason1     = "Instrument Date > Actvn. Date";
		String  ConfirmationMsg = "You have unsaved data. Do you want to continue?";
		Weblocator.Openlinks(F2Inst);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		
		Weblocator.getWindowHandle();
		
		Weblocator.explicitWait(2);
		for (int i = 0; i <=8; i++) {
			driver.findElement(InstDtonInstTable).sendKeys(Keys.BACK_SPACE);
		}
		Weblocator.TextFieldWithOutTAB(InstDtonInstTable, "22/11/2018");
		Weblocator.explicitWait(2);				
		Weblocator.Openlinks(InstSaveBtn);
		Weblocator.explicitWait(2);
		elecomm.PopupHandle_dataSave();
		elecomm.PopupHandle_dataSave();
		Weblocator.explicitWait(5);	
	}

	public void Update_Dep_With_Location()
	{
		boolean exception = false;
		String ConfirmationMsg = "You have unsaved data. Do you want to continue?";
		Weblocator.Openlinks(EditDept);
		Weblocator.explicitWait(5);	
		//-------------------Add Assertions here	
		ClickYesNoButton(ConfirmationMsg,"Yes");	
		Weblocator.explicitWait(5);	
		//Rej_Reason = Elements.Getactualtext(RejRsnOnInsTable);
		Weblocator.clearText(PickupLocDept);
		Weblocator.TextField(PickupLocDept, "A74");		
		Weblocator.explicitWait(5);	
		Weblocator.Openlinks(DeptSaveBtn);				
		Weblocator.explicitWait(5);
		Weblocator.Openlinks(backBtn_f12);
		ClickYesNoButton(ConfirmationMsg,"Yes");
		Weblocator.explicitWait(5);	

	}

	// Method Delete_Rej_Record() deletes the record corresponding to the batch# passed to it
	public boolean Delete_Rej_Record(String Batchno)
	{
		boolean status=false;
		Weblocator.Openlinks(DeleteRejRec);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(10);
		Weblocator.TextField(searchByBatchNo, Batchno);
		Weblocator.PressEnterBtn(searchByBatchNo);
		Weblocator.explicitWait(5);
		status=Weblocator.IselementPresent(elecomm.noItemToShowMsg);
		return status;

	}

	//Method Not_Delete_Rej_Record() does not delete  the record corresponding to the batch# passed to it
	public boolean Not_Delete_Rej_Record()
	{
		boolean status=false;
		Weblocator.Openlinks(DeleteRejRec);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.noBtn);
		Weblocator.getWindowHandle();
		status=Weblocator.IselementPresent(searchByBatchNo);
		return status;
		
	}

	//Method ClickYesNoButton() is to click on Yes button on Dialog box asking for permission to make changes.
	public void ClickYesNoButton(String ConfirmationMsg, String ActionToTake)
	{
		boolean ConfirmationMsgFlg   ;	
		ConfirmationMsgFlg = driver.findElement(By.xpath("//div[@class='dialogBackground']//td[text()=\""+ ConfirmationMsg + "\"]")).isDisplayed();
		if (ConfirmationMsgFlg)
		{		if (ActionToTake.equalsIgnoreCase("Yes"))
			Weblocator.Openlinks(YesBtn);
		else if (ActionToTake.equalsIgnoreCase("No"))
			Weblocator.Openlinks(NoBtn);
		}

	}


	public void Verify_Batch_Clear_Functionality()
	{

	}

	public void Verify_Dep_Clear_Functionality()
	{

	}


	//this is for both Dep and Batch
	public void ClickOn_EditButton(){

	}

	//this is for both Dep and Batch
	public void ClickOn_UserInfoButton()
	{

	}

	//this is for Inst Dep and Batch
	public void Verify_UserInfoButton()
	{

	}

	//this is for Inst Dep and Batch
	public void Click_InfoButton(){

	}

	//this is for Inst Dep and Batch
	public void Verify_InfoButton(){

	}



	public void Verify_GridHeader_Or_Records()
	{

	}






}






