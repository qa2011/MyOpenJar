package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class TransactionUploadAuthPage extends Setup{
	
	
}








