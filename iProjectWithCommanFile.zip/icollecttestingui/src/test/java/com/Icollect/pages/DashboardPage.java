package com.Icollect.pages;

import org.openqa.selenium.By;

import com.util.ElementCommon;
import com.util.Setup;
import com.util.Weblocator;

public class DashboardPage extends Setup {
	//-----------------------------------------------------------------
	public By logout=By.xpath("//*[@id='banner']/a[2]"); //*[text()='Log Out']
	//public By logout_okBtn=By.xpath("//*[text()='OK']");
	public By logout_okBtn=By.xpath("//*[contains(text(),'Ok')]");
	public By okBtn=By.xpath("//*[text()='OK']");
	public By okBtn2=By.xpath("(//*[text()='OK'])[2]");

	public By home=By.xpath("//*[@id='nav-bar']/a[1]");
	public By queries=By.xpath("//*[@id='nav-bar']/a[6]");
	public By transactions=By.xpath("//*[@id='nav-bar']/a[4]");
	public By txnAuth=By.xpath("//*[@id='nav-bar']/a[5]");
	
	
	public By homewithSelected=By.xpath("//*[@class='first selected' and //*[@id='nav-bar']/a[1]]");
	

	//-------------------------------TABS-------------------------------
	public By mastertab=By.xpath("//*[text()='Masters']");
	public By masterAuthTab=By.linkText("Masters Auth");
	public By TnsAuthTab=By.linkText("Txn. Auth");


	//------------------------------client------------------------------
	public By client_opt=By.xpath("//*[@id='gtb_leftNav']//ul/li[1]/p");
	public By client_opt_list_gettxt=By.xpath("//*[@id='gtb_leftNav']//ul/li[1]/ul/li/a/p");
	//------------------------------product------------------------------
	public By product=By.xpath("//*[@id='gtb_leftNav']//ul/li[3]/p");
	public By products_option=By.xpath("//*[@id='gtb_leftNav']//ul/li[3]/ul/li[1]/a/p");
	public By product_opt_list_gettxt=By.xpath("//*[@id='gtb_leftNav']//ul/li[3]/ul/li/a/p");
	public By productTypeWiseOption=By.xpath("//*[@id='gtb_leftNav']//ul/li[3]/ul/li[2]/a/p");
	public By productCodeWiseOption=By.xpath("//*[@id='gtb_leftNav']//ul/li[3]/ul/li[3]/a/p");

	//------------------------------Risk Manager------------------------------
	public By riskManager_option=By.xpath("//*[@id='JM30']/a/p");
	public By riskManager_Header_gettxt=By.xpath("//*[@id='isc_M']/table/tbody/tr/td");
	public By userinfoBtn_riskManager=By.id("isc_24");
	public By saveBtn_riskManager=By.id("isc_29");
	public By closeBtn_riskManager=By.id("isc_2E");
	//----------------------------System Account-------------------------------------
	public By system=By.xpath("//*[@id='gtb_leftNav']//ul/li[5]/p");
	public By systemAccount_option=By.xpath("//*[@id=\"JM25\"]/a/p");
	//----------------------------Location-------------------------------------
	public By location=By.xpath("//*[text()='Location']");
	public By clusterMaster=By.xpath("//*[text()='Cluster Master']");
	public By systemLocationType=By.xpath("//*[text()='System Location Type']");
	public By clearingLocations=By.xpath("//*[text()='Clearing Locations']");
	//public By =By.xpath("");

	//----------------------------Transaction-------------------------------------
	public By clientInput=By.xpath("//*[text()='Client Input']");
	public By DispatchBankInputs=By.xpath("//*[text()='Dispatch Bank Inputs']");
	public By dataEntry=By.xpath("//*[text()='Data Entry']");
	public By internalProcessing= By.xpath("//*[text()='Internal Processing']");

	public By dispatchBankInputsMenu=By.xpath("//*[text()='Dispatch Bank Inputs']");
	public By scheduleLiquidationSubMenu=By.xpath("(//*[text()='Schedule Liquidation'])[1]");
	public By DeferredCollectionEntryPageMenu=By.xpath("//*[text()='Deferred Collection Entry']");
	public By DeferredEnrichmentEntryMenu=By.xpath("//*[text()='Deferred Enrichment Entry']");
	public By DeferredRemarksEntryMenu=By.xpath("//*[text()='Deferred Remarks Entry']");
	public By instrumentLiquidationMenu=By.xpath("//*[text()='Instrument Liquidation']");
	public By instrumentReceiptMenu=By.xpath("//*[text()='Instrument Receipt']");
	public By instrumentLiqStatReversalMenu=By.xpath("//*[text()='Instrument Liq. Stat. Reversal']");
	//public By = By.xpath("");
	public By dispatchAllocationMenu= By.xpath("//p[text()='Dispatch Allocation']");
	public By downloadScheduleMenu= By.xpath("//p[text()='Download Schedule']");
	public By corrBankWithdrawalDispBankWiseMenu= By.xpath("//p[text()='Corr. Bank Withdrawal Disp. Bank Wise']");
	public By extractScheduleMenu= By.xpath("//*[text()='QDD - Extract Schedule']");
	public By dispatchBankActivationMenu= By.xpath("//*[text()='QDD - Dispatch Bank Activation']");
	public By transactionUpload= By.xpath("//*[text()='Transaction Upload']");
	public By UploadRejRep=By.xpath("//*[text()='Upload Reject Repair']"); 
	
	//----------------------------Transaction Auth-------------------------------------
	public By clientInputAuth=By.xpath("//*[text()='Client Input']");
	public By dataEntryAuth=By.xpath("//*[text()='Data Entry Auth']");
	public By DeferredCollectionEntryPageMenuAuth=By.xpath("//*[text()='Deferred Collection Auth']");
	public By DeferredEnrichmentsAuthorisationMenuAuth=By.xpath("//*[text()='Deferred Enrichments Authorisation']");
	public By DeferredRemarksMenuAuth=By.xpath("//*[text()='Deferred Remarks Authorisation']");
	
	public By dispatchBankInputAuthMenu=By.xpath("//*[text()='Dispatch Bank Inputs']");
	public By instrumentLiquidationAuthSubMenu=By.xpath("//*[text()='Instrument Liquidation Auth']");
	public By instrumentReceiptAuthSubMenu=By.xpath("//*[text()='Instrument Receipt Auth']");
	public By scheduleLiquidationAuthSubMenu=By.xpath("(//*[text()='Schedule Liquidation Auth'])[1]");
	public By instrumentLiqStatReversalAuthMenu=By.xpath("//*[text()='Inst. Liq. Status Reversal - Auth.']");
	//public By = By.xpath("");
	public By dispatchAllocationAuthMenu= By.xpath("//p[text()='Dispatch Allocation - Auth']");
	public By dispatchBankActivationAuthMenu= By.xpath("//*[text()='QDD - Dispatch Bank Activation Auth']");
	public By corrBankWithdrawalDispBankWiseAuthMenu= By.xpath("//p[text()='Corr. Bank Withdrawal Auth']");
	public By transactionUploadAuth= By.xpath("//*[text()='Transaction Upload']");

	public Boolean logout()
	{
		Boolean logouttext=false;
		Boolean logoutbtn=Weblocator.Openlinks(logout);
		if (logoutbtn) {
			Weblocator.explicitWait(1);
			Weblocator.getWindowHandle();
		/*	Boolean logOut=WebDriverManager.IselementPresent(ElementCommon.okBtn4);
			if (logOut) {*/
				Weblocator.explicitWait(1);
				Boolean okbtn=Weblocator.Openlinks(ElementCommon.okBtn4);
				Weblocator.explicitWait(1);
				if (okbtn) {
					logouttext=true;
				}
			//}
			else {
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(okBtn2);
			}
		}
		return logouttext;
	}

	public Boolean logout1()
	{
		Boolean logouttext=false;
		Boolean logoutbtn=Weblocator.Openlinks(logout);
		if (logoutbtn) {
			Weblocator.getWindowHandle();
			Boolean logOut=Weblocator.IselementPresent(logout_okBtn);
			if (logOut) {
				Weblocator.explicitWait(1);
				Boolean okbtn=Weblocator.Openlinks(logout_okBtn);
				if (okbtn) {
					logouttext=true;
				}
			}
			else {
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(okBtn2);
			}
		}
		return logouttext;
	}

	public Boolean product() {
		Boolean check =false;
		Boolean master=Weblocator.Openlinks(mastertab);
		if (master) {
			Boolean productopt=Weblocator.Openlinks(product);
			if (productopt) {
				Boolean product_sub_opt=Weblocator.Openlinks(products_option);
				check=true;
			}
		}
		return check;

	}

	public Boolean Transaction() {
		Boolean check =false;
		Boolean trans=false;
		try {
			trans=Weblocator.Openlinks(transactions);
		}catch (Exception e) {
			Weblocator.Openlinks(dashboard.home);
			trans=Weblocator.Openlinks(transactions);
		}
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInput);
			if (clientinput) {
				Weblocator.Openlinks(dataEntry);
				check=true;
			}
		}
		else {
			System.out.println("not click on Transaction TAB");
		}
		return check;

	}


	public Boolean TransactionAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInputAuth);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(dataEntryAuth);
				check=true;
			}
		}
		return check;

	}

	public Boolean DeferredCollectionEntryPage() {
		Boolean check =false;
		try {
			Weblocator.Openlinks(dashboard.home);
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean clientinput=Weblocator.Openlinks(clientInput);
				if (clientinput) {
					Boolean dataentry=Weblocator.Openlinks(DeferredCollectionEntryPageMenu);
					check=true;
				}
			}
		}catch (Exception e) {
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean clientinput=Weblocator.Openlinks(clientInput);
				if (clientinput) {
					Boolean dataentry=Weblocator.Openlinks(DeferredCollectionEntryPageMenu);
					check=true;
				}
			}
		}
		return check;
	}

	public Boolean DeferredCollectionEntryPageAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInputAuth);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(DeferredCollectionEntryPageMenuAuth);
				check=true;
			}
		}
		return check;
	}

	public Boolean DeferredEnrichmentEntry() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInput);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(DeferredEnrichmentEntryMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean DeferredEnrichmentEntryAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInputAuth);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(DeferredEnrichmentsAuthorisationMenuAuth);
				check=true;
			}
		}
		return check;
	}


	//-----------------------------------------------------------
	public Boolean DeferredRemarksEntry() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInput);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(DeferredRemarksEntryMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean DeferredRemarksEntryAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(clientInputAuth);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(DeferredRemarksMenuAuth);
				check=true;
			}
		}
		return check;
	}

	//-------------------------------------------------------------------------------

	public Boolean InstrumentLiquidation() 
	{
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(DispatchBankInputs);
			if (clientinput) {
				Boolean dataentry=Weblocator.Openlinks(instrumentLiquidationMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean InstrumentLiquidationAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
			if (dispatchBank) {
				Boolean instrumentLiquidation=Weblocator.Openlinks(instrumentLiquidationAuthSubMenu);
				check=true;
			}
		}
		return check;
	}
//---------------------------------------------------------------
	public Boolean InstrumentReceipt() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(DispatchBankInputs);
			if (clientinput) {
				Boolean instrumentReceipt=Weblocator.Openlinks(instrumentReceiptMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean InstrumentReceiptAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
			if (dispatchBank) {
				Boolean instrumentReceiptAuth=Weblocator.Openlinks(instrumentReceiptAuthSubMenu);
				check=true;
			}
		}
		return check;
	}
	//---------------------------------------------------------------------------------

	public Boolean scheduleLiquidation() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(DispatchBankInputs);
			if (clientinput) {
				Boolean scheduleLiquidation=Weblocator.Openlinks(scheduleLiquidationSubMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean scheduleLiquidationAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
			if (dispatchBank) {
				Boolean scheduleLiquidationauth=Weblocator.Openlinks(scheduleLiquidationAuthSubMenu);
				check=true;
			}
		}
		return check;
	}
	//------------------------------------------------------------------------
	public Boolean InstrumentLiqStatReversal() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(transactions);
		if (trans) {
			Boolean clientinput=Weblocator.Openlinks(DispatchBankInputs);
			if (clientinput) {
				Boolean instrumentLiqStatReversal=Weblocator.Openlinks(instrumentLiqStatReversalMenu);
				check=true;
			}
		}
		return check;
	}

	public Boolean InstrumentLiqStatReversalAuth() {
		Boolean check =false;
		Boolean trans=Weblocator.Openlinks(TnsAuthTab);
		if (trans) {
			Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
			if (dispatchBank) {
				Boolean instrumentLiqStatReversalauth=Weblocator.Openlinks(instrumentLiqStatReversalAuthMenu);
				check=true;
			}
		}
		return check;
	}
	
	//------------------------------------------------------------------------
		public Boolean DispatchAllocation() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean internalPro=Weblocator.Openlinks(internalProcessing);
				if (internalPro) {
					Boolean dispatchAllocation=Weblocator.Openlinks(dispatchAllocationMenu);
					check=true;
				}
			}
			return check;
		}

		public Boolean DispatchAllocationAuth() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(TnsAuthTab);
			if (trans) {
				Boolean internalPro=Weblocator.Openlinks(internalProcessing);
				if (internalPro) {
					Boolean dispatchAllocationAuth=Weblocator.Openlinks(dispatchAllocationAuthMenu);
					check=true;
				}
			}
			return check;
		}
		//-----------------------------------------------------------------------------------
/*		public Boolean () {
			Boolean check =false;
			Boolean trans=WebDriverManager.Openlinks();
			if (trans) {
				Boolean =WebDriverManager.Openlinks();
				if () {
					Boolean =WebDriverManager.Openlinks();
					check=true;
				}
			}
			return check;
		}

		public Boolean () {
			Boolean check =false;
			Boolean trans=WebDriverManager.Openlinks();
			if (trans) {
				Boolean =WebDriverManager.Openlinks();
				if () {
					Boolean =WebDriverManager.Openlinks();
					check=true;
				}
			}
			return check;
		}*/
	//---------------------------------------------------------------------------------------.
		public Boolean DownloadSchedule() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean internalPro=Weblocator.Openlinks(internalProcessing);
				if (internalPro) {
					Boolean downloadSchedule=Weblocator.Openlinks(downloadScheduleMenu);
					check=true;
				}
			}
			return check;
		}
	//------------------------------------------------------------------------------------------
		public Boolean DispatchBankActivation() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean internalPro=Weblocator.Openlinks(internalProcessing);
				if (internalPro) {
					Boolean dispatchBankActivation=Weblocator.Openlinks(dispatchBankActivationMenu);
					check=true;
				}
			}
			return check;
		}
		
		public Boolean DispatchBankActivationAuth() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(TnsAuthTab);
			if (trans) {
				Boolean internalPro=Weblocator.Openlinks(internalProcessing);
				if (internalPro) {
					Boolean dispatchBankActivationAuth=Weblocator.Openlinks(dispatchBankActivationAuthMenu);
					check=true;
				}
			}
			return check;
		}
		//-------------------------------------------------------------------------------------
		public Boolean CorrBankWithdrawalDispBankWise() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean clientinput=Weblocator.Openlinks(DispatchBankInputs);
				if (clientinput) {
					Boolean corrBankWithdrawalDispBankWise=Weblocator.Openlinks(corrBankWithdrawalDispBankWiseMenu);
					check=true;
				}
			}
			return check;
		}

		public Boolean CorrBankWithdrawalDispBankWiseAuth() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(TnsAuthTab);
			if (trans) {
				Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
				if (dispatchBank) {
					Boolean corrBankWithdrawalDispBankWiseauth=Weblocator.Openlinks(corrBankWithdrawalDispBankWiseAuthMenu);
					check=true;
				}
			}
			return check;
		}
		//--------------------------------------------------------------------------------------
		
		public Boolean TransactionUpload() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean clientinput=Weblocator.Openlinks(clientInput);
				if (clientinput) {
					Weblocator.explicitWait(1);
					Boolean corrBankWithdrawalDispBankWise=Weblocator.Openlinks(transactionUpload);
					Weblocator.explicitWait(1);
					check=true;
				}
			}
			return check;
		}

		public Boolean TransactionUploadAuth() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(TnsAuthTab);
			if (trans) {
				Boolean dispatchBank=Weblocator.Openlinks(dispatchBankInputAuthMenu);
				if (dispatchBank) {
					Boolean corrBankWithdrawalDispBankWiseauth=Weblocator.Openlinks(corrBankWithdrawalDispBankWiseAuthMenu);
					check=true;
				}
			}
			return check;
		}
		//-----------------------------------------------------------------------------------------------------------
		public Boolean UploadReject() {
			Boolean check =false;
			Boolean trans=Weblocator.Openlinks(transactions);
			if (trans) {
				Boolean clientinput=Weblocator.Openlinks(clientInput);
				if (clientinput) {
					Boolean corrBankWithdrawalDispBankWise=Weblocator.Openlinks(UploadRejRep);
					check=true;
				}
			}
			return check;
		}


/*		public Boolean () {
			Boolean check =false;
			Boolean trans=WebDriverManager.Openlinks();
			if (trans) {
				Boolean =WebDriverManager.Openlinks();
				if () {
					Boolean =WebDriverManager.Openlinks();
					check=true;
				}
			}
			return check;
		}*/
		
}
