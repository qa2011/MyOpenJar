package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class scheduleLiquidationPage extends Setup{
	
    //public By = By.xpath("");
	public By scheduleLiquidationTab= By.xpath("(//*[text()='Schedule Liquidation'])[2]");
	public By instrumentsTab= By.xpath("(//*[text()='Instruments'])[1]");
	public By regularRadioBtn= By.xpath("(//*[@type='RADIO'])[1]");
	public By adhocRadioBtn= By.xpath("(//*[@type='RADIO'])[2]");
	public By productTextField= By.name("dispBankProduct");
	public By scheduleDateTextField= By.name("scheduleDate");
	//public By branchTextField= By.name("dispBranch");
	public By dispBankTextField= By.name("dispBank");
	public By disBranchTextField= By.name("dispBranch");
	public By masterScheduleNumberTextField= By.name("masterScheduleNumber");
	public By makerTextfield= By.name("makerCode");
	public By presentationDateTextFiled= By.name("presentationDate");
	public By statusTextField= By.name("statusFlag");
	public By recordCountTextField= By.id("isc_3Q");
	public By retrieveBtn= By.xpath("(//*[text()='Retrieve (F7)'])[1]");
	public By clearBtn= By.xpath("(//*[text()='Clear (F1)'])[1]");
	public By saveBtn= By.xpath("(//*[text()='Save (F11)'])[1]");
	public By userInfoBtn= By.xpath("(//*[text()='User Info (F10)'])[1]");
	public By summaryBtn= By.xpath("(//*[text()='Summary(F12)'])[1]");
	
	public By scheduleFirstLine= By.xpath("(//*[@role='listitem']//td[2]/div[1])[2]");
	public By scheduleFiletrTextField= By.xpath("//input[contains(@name,'dispBankScheduleNumber')]");
	public By paidChekBox= By.xpath("//*[text()='Paid']");
	


	public By summaryTab= By.xpath("//*[text()='Summary']");
	
	
	public boolean retrieve(String productName, String dispBank, String dispBranch) 
	{
		Boolean status =false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productTextField, productName);
		Weblocator.TextField(dispBankTextField, dispBank);
		Weblocator.explicitWait(1);
		Weblocator.TextField(disBranchTextField, dispBranch);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(5);
		if (Weblocator.IselementPresent(scheduleFirstLine)) {
			status=true;
		}
		return status;
	}
	
	public String searchFilter(String thereRefNoAfterAuthFromRecipt) {
		Weblocator.explicitWait(2);
		Weblocator.TextField(scheduleFiletrTextField, thereRefNoAfterAuthFromRecipt);
		Weblocator.PressEnterBtn(scheduleFiletrTextField);
		Weblocator.explicitWait(2);
		String scheduleNo=Weblocator.getPagetext(scheduleFirstLine);
		return scheduleNo;
	}
	
	public String paid(String thereRefNoAfterAuthFromRecipt) {
		Weblocator.Openlinks(paidChekBox);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(5);
		Weblocator.TextField(scheduleFiletrTextField, thereRefNoAfterAuthFromRecipt);
		Weblocator.PressEnterBtn(scheduleFiletrTextField);
		String noItmes=Weblocator.getPagetext(elecomm.noItemToShowMsg);
		return noItmes;
	}
	
	
	

}
    
    
    
    
    
    
    
    
