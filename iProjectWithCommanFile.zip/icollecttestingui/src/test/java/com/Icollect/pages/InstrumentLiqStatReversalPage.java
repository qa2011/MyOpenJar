package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiqStatReversalPage extends Setup{

	//public By = By.xpath("");

	public By productCodeTextField= By.name("productCode");
	public By schedNumberTextField= By.name("schedNumber");
	public By disBankTextField= By.name("dispBanksCode");
	public By dispBranchTextField= By.name("dispBranchCode");
	public By scheduleDateTextField= By.name("scheduleDate");
	public By schuleNoFirstcol= By.xpath("(//*[@role='listitem']/td[1]/div[1])[2]");
	public By modifyFirstCol= By.xpath("(//*[@role='listitem']/td[13]/div[1])[2]/span");
	public By revesalDropDown= By.xpath("//*[@role='option' and @class='textbox']");
	public By revesalDropDownOption_No= By.xpath("//*[@role='option']//*[text()='No']");
	public By revesalDropDownOption_Lost= By.xpath("//*[@role='option']//*[text()='Lost']");
	public By revesalDropDownOption_Return= By.xpath("//*[@role='option']//*[text()='Return']");
	public By revesalDropDownOption_Paid= By.xpath("//*[@role='option']//*[text()='Paid']");
	public By returnReasonTextField= By.name("returnReason");
	public By remarksTextField= By.name("reversalreason");
	public By reversalStatusGetText= By.xpath("(//*[@role='listitem']/td[9]/div[1])[2]");
	
	public By codeTextField= By.name("code");

	public boolean retrieve(String productName, String scheduleNo) 
	{
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productCodeTextField, productName);
		Weblocator.TextField(schedNumberTextField, scheduleNo);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		status=Weblocator.IselementPresent(schuleNoFirstcol);
		return status;
	}

	public boolean modify() {
		boolean status= false;
		Weblocator.Openlinks(modifyFirstCol);
		Weblocator.explicitWait(2);
		status=Weblocator.IselementPresent(revesalDropDown);
		return status;
	}

	public boolean modifyWithOption(String revesalOption ,String returnReason,String remark) {
		boolean status= false;
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(revesalDropDown);
		Weblocator.explicitWait(2);
		if (revesalOption.equalsIgnoreCase("revesal_No")) {
			status=Weblocator.Openlinks(revesalDropDownOption_No);
			Weblocator.Openlinks(elecomm.updateF2);
			Weblocator.Openlinks(elecomm.saveBtnF11);
		}
		else if (revesalOption.equalsIgnoreCase("revesal_Lost")) {
			status=Weblocator.Openlinks(revesalDropDownOption_Lost);
			Weblocator.TextField(remarksTextField, remark);
			Weblocator.Openlinks(elecomm.updateF2);
			Weblocator.Openlinks(elecomm.saveBtnF11);
		}
		else if (revesalOption.equalsIgnoreCase("revesal_Return")) {
			Weblocator.explicitWait(1);
			status=Weblocator.Openlinks(revesalDropDownOption_Return);
			Weblocator.explicitWait(1);
			Weblocator.TextField(returnReasonTextField, returnReason);
			Weblocator.TextField(remarksTextField, remark);
			Weblocator.Openlinks(elecomm.updateF2);
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(elecomm.saveBtnF11);
			Weblocator.explicitWait(3);
		}
		else if (revesalOption.equalsIgnoreCase("Paid")) {
			status=Weblocator.Openlinks(revesalDropDownOption_Paid);
			Weblocator.TextField(remarksTextField, remark);
			Weblocator.Openlinks(elecomm.updateF2);
			Weblocator.Openlinks(elecomm.saveBtnF11);
		}
		return status;
	}
	
	public String reversalStatusGet() {
		Weblocator.explicitWait(1);
		String reversalStatus=Weblocator.getPagetext(reversalStatusGetText);
		return reversalStatus;
	}

}








