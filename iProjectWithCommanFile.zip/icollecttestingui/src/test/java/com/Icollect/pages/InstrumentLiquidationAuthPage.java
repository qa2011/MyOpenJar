package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiquidationAuthPage extends Setup{

	//public By = By.xpath("");
	public By regularRadioBtn= By.xpath("(//*[@name='schType'])[1]");
	public By adhocRadioBtn= By.xpath("(//*[@name='schType'])[2]");
	public By productTextField= By.name("instLiqProduct");
	public By makerTextField= By.name("instLiqMaker");
	public By branchTextField= By.name("instLiqDispBranch");
	public By dispachBankTextField= By.name("instLiqDispBank");
	public By refNo= By.name("referenceNumber");
	
	public By paidAmoutCheckBox= By.xpath("//*[text()='  Paid Amount > 0']");
	public By returnAmountCheckBox= By.xpath("//*[text()='  Return Amount > 0']");
	
	public By noItemShowGetText2= By.xpath("(//*[text()='No items to show.'])[2]");
	
	public By dispBankFilterTextField= By.xpath("//*[@class='listGrid']//*[@role='list']//input[1]");
	public By FilterTextField= By.xpath("//*[@class='listGrid']//*[@role='list']//input[1]");
	
	public By dispBankFirstCol= By.xpath("(//*[@role='listitem']/td[2])[2]");
	public By rejectRedColor= By.xpath("(//*[@class='rejectedCellSelected'])[2]");
	public By authCheckBoxAll= By.xpath("//*[text()='Authorize (F2)']");
	public By authFirstColCheckBox= By.xpath("(//*[@role='listitem']/td[10])[2]//span");
	public By rejectFirstColCheckBox= By.xpath("(//*[@role='listitem']/td[11])[2]//span[1]");
	
	public By searchBtn= By.xpath("(//*[@role='listitem']/td[1])[2]//span");
	public By remarkGetText= By.name("makerCheckerRemarks");
	public By closeRemarkInfoPage= By.xpath("(//*[@class='windowHeader']//img)[4]");
	
	public By noItemMsgGetText= By.xpath("(//*[text()='No items to show.'])[1]");
	
	public String retrive(String refrence) {
		//CommanClass.TextField(productTextField, product);
		//CommanClass.TextField(makerTextField, makerName);
		Weblocator.TextField(instLiqAuth.refNo, refrence);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(3);
		String check=Weblocator.getPagetext(dispBankFirstCol);
		return check;
	}
	
	
	public String reject(String rejectMSG) {
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(rejectFirstColCheckBox);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, rejectMSG);
		Weblocator.Openlinks(elecomm.okBtn3);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.Openlinks(elecomm.userinfoBtnF10);
		Weblocator.getWindowHandle();
		String check=Weblocator.getPagetext(elecomm.checkerActionGetText);
		Weblocator.Openlinks(elecomm.userInfoClose);
		Weblocator.getWindowHandle();
		return check;
	}
	
	public String auth() {
		Weblocator.Openlinks(authFirstColCheckBox);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(4);
		Weblocator.getWindowHandle();
		String msg=Weblocator.getPagetext(noItemMsgGetText);
		return msg;
	}

}








