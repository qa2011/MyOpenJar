package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiquidationPage extends Setup{

	//public By = By.xpath("");
	public By productCodeTextField= By.name("productCode");
	public By productCodeGet= By.id("isc_DBComboBox_6_HINT");
	public By regularRadioBtn= By.xpath("(//*[@name='scheduleType'])[1]");
	public By adhocRadioBtn= By.xpath("(//*[@name='scheduleType'])[2]");
	public By masterSchdNoTextField= By.name("masterSchdNo");
	public By scheduleNumberTextField= By.name("scheduleNumber");
	public By scheduleDateTextField= By.name("scheduleDate");
	public By dispBankTexfield= By.name("dispBankCode");
	public By dispBankGet= By.id("isc_DBComboBox_8_HINT");

	public By refrenceNo=By.name("refNo");
	public By clientTextField= By.name("botFormClient");
	public By clientSuggestList= By.xpath("(//*[@eventproxy='isc_PickListMenu_1'])[1]");
	public By instTextField= By.name("botFormInstNo");
	public By instAmountTextField= By.name("botFormInstAmt");
	public By instDateTexField= By.name("botFormInstDt");
	public By bankBranchTextField= By.name("botFormBankOrBranch");
	public By returnReasonTextField= By.name("botFormRetReason");
	public By chargeInstTextField= By.name("botFormChargeInst");

	public By returnAmountTextField= By.name("returnAmount");
	public By paidAmountTextField= By.name("collectionAmount");

	public By GetGridDetailsAfterSaveBtn= By.xpath("(//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div");
	public By GetGridDetailsFirstRow= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[1]");
	public By GetGridDetails2Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[2]");
	public By GetGridDetails3Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[3]");
	public By GetGridDetails4Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[4]");
	public By GetGridDetails5Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[5]");
	public By GetGridDetails6Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[6]");
	public By GetGridDetails7Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[7]");
	public By GetGridDetails8Row= By.xpath("((//*[@class='gridBody'])[1]//*[@class='listTable']//*[@role='listitem']/td[1]/div[1])[8]");


	public By status= By.name("statusFlag");
	//public By liqTypeDropListBtnComm= By.xpath("//*[@class='formCell']//div[1]");
	public By liqTypeDropListBtnComm= By.xpath("/html/body/div[5]/div/div/div/div[2]/div/div[4]/div/div[2]/div[3]/div[1]/div/div[7]/div/div[2]/div/form/table/tbody/tr[4]/td[3]/table/tbody/tr/td[1]/table/tbody/tr/td[1]/div");
	public By liqTypeDropListBtn= By.xpath("(//*[@class='selectItemPickerIcon'])[1]");
	public By liqTypeDroplistOption1= By.xpath("//*[@id='isc_PickListMenu_2_row_0']");
	public By liqTypeDroplistOption2= By.xpath("//*[@id='isc_PickListMenu_2_row_1']");
	public By liqTypeDroplistOption3= By.xpath("//*[@id='isc_PickListMenu_2_row_2']");
	public By liqTypeDroplistOptionReturn= By.xpath("//*[text()='Return' and @role='presentation']");
	public By technicalOption= By.xpath("//*[text()='Technical']");
	public By lostOption= By.xpath("//*[text()='Lost']");
	public By paidOption= By.xpath("//*[text()='Paid']");
	public By returnOption= By.xpath("//*[text()='Return']");

	public By autoCBWDropDown= By.xpath("//*[text()='Yes']");
	public By autoCBWDropDown_No_Option= By.xpath("(//*[text()='No'])[2]");

	public By draweeBrTextFile_TecnicalReturnframe= By.name("techDraweeBrCode");
	public By okBtnTecnicalReturnreaseon= By.xpath("(//*[text()='Ok'])[1]");
	public By descriptionTextField= By.xpath("(//*[@name='code'])[1]");
	public By searchBtn= By.xpath("(//*[text()='Search'])[1]");
	public By techinicalReturn_returnReason= By.xpath("(//*[@class='gridBody'])[2]//tr[1]//div[1]");

	public By codetextField_draweeBr= By.xpath("(//*[@name='code'])[2]");
	public By searchBtnDraweeBr= By.xpath("(//*[text()='Search'])[2]");
	public By selectDraweebr= By.xpath("//*[text()='UCC-ADHOC']");
	public By okBtnDraweeBr= By.xpath("/html/body/div[19]/div[2]/div[2]/div/div[1]/table/tbody/tr/td/div");
	public By ok_technicalReturn= By.xpath("/html/body/div[17]/div/div[1]/div/div[2]/div/div[1]/table/tbody/tr/td/div");
	public By instNoGet= By.name("botFormInstNo");
	public By dialogFrame= By.xpath("(//*[@role='dialog'])[1]");

	public By clrgLocTextField= By.name("botFormClrgLoc");
	
	public By balPaidGet= By.name("balPaid");
	public By collectionAmountTextField= By.name("collectionAmount");
	public By balReturnGet= By.name("balReturn");
	//public By returnAmountTextField= By.name("returnAmount");
	//public By = By.xpath("");


	public String retrieve(String product, String thereRef) {
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productCodeTextField, product);
		Weblocator.TextField(scheduleNumberTextField, thereRef);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		String status=Weblocator.GetAttributevalue(this.status);
		return status;
	}

	public String addInst(String clientName, String amount, String liqType) {
		String check=null; 
		Weblocator.Openlinks(elecomm.addInstF7Btn);
		Weblocator.TextField(clientTextField, clientName);
		Weblocator.TextField(instTextField, "Test"+Weblocator.randomestring());
		Weblocator.TextField(instAmountTextField, amount);
		Weblocator.clearText(instDateTexField);
		Weblocator.TextFieldWithOutTAB(instDateTexField, "16/11/2018");
		Weblocator.TextField(bankBranchTextField, "VADGA1,BOM");
		Weblocator.Openlinks(liqTypeDropListBtnComm);

		if (liqType.equals("Return")) {
			Weblocator.Openlinks(liqTypeDroplistOption3);
			Weblocator.TextField(returnReasonTextField, "Testing return");
			Weblocator.clearText(returnAmountTextField);
			Weblocator.TextField(returnAmountTextField, amount);
			Weblocator.scrollingByCoordinatesofAPage();
			Weblocator.Openlinks(elecomm.saveBtnF11Capital);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.selectBtn);
			Weblocator.getWindowHandle();
			check=Weblocator.Getactualtext(GetGridDetailsAfterSaveBtn);
		}

		else if(liqType.equals("Paid")) {
			Weblocator.Openlinks(liqTypeDroplistOption2);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.selectBtn);
			Weblocator.scrollingByCoordinatesofAPage();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.saveBtnF11Capital);
			String msg=elecomm.PopupHandle_dataSave();
			Weblocator.clearText(paidAmountTextField);
			Weblocator.TextField(paidAmountTextField, amount);
			check=Weblocator.Getactualtext(GetGridDetailsAfterSaveBtn);
		}
		else if(liqType.equals("Open")) {
			Weblocator.Openlinks(liqTypeDroplistOption1);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.selectBtn);
			Weblocator.scrollingByCoordinatesofAPage();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.saveBtnF11Capital);
			String msg=elecomm.PopupHandle_dataSave();
			Weblocator.TextField(instLiq.paidAmountTextField, "1000");
			check=Weblocator.Getactualtext(GetGridDetailsAfterSaveBtn);
		}
		return check;
	}

	public void clearData() {
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Boolean noBtn=Weblocator.IselementPresent(elecomm.noBtn);
		if (noBtn) {
			Weblocator.Openlinks(elecomm.noBtn);
		}
	}


	public String addInst_OType(String liqType,String returnreason,String amount) {
		String instNo=null; 
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(instLiq.liqTypeDropListBtnComm);
		Weblocator.explicitWait(1);
		if (liqType.equals("Lost_O_type")) {
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(lostOption);
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(autoCBWDropDown);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(autoCBWDropDown_No_Option);
			Weblocator.explicitWait(1);
			instNo=Weblocator.GetAttributevalue(instNoGet);

		}
		else if (liqType.equals("Technical_O_type")) {
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(technicalOption);
			elecomm.PopupHandle_dataSave();
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(clrgLocTextField);
			for (int i = 0; i < 6; i++) {
				driver.findElement(clrgLocTextField).sendKeys(Keys.BACK_SPACE);
			}
			Weblocator.TextField(clrgLocTextField, "AHMED");
			Weblocator.explicitWait(1);
			instNo=Weblocator.GetAttributevalue(instNoGet);

			/*		for (int i = 0; i < 6; i++) {
				driver.findElement(returnAmountTextField).sendKeys(Keys.BACK_SPACE);
			}
			WebDriverManager.TextField(returnAmountTextField, amount);
			WebDriverManager.explicitWait(2);
			WebDriverManager.Openlinks(elecomm.saveBtnF11Capital);
			elecomm.PopupHandle_dataSave();*/
		}
		else if (liqType.equals("Return_O_type")) {
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(returnOption);

			Weblocator.keyPressALTQ(returnReasonTextField);
			Weblocator.getWindowHandle();
			Weblocator.TextField(descriptionTextField, returnreason);
			Weblocator.Openlinks(searchBtn);
			Weblocator.Openlinks(techinicalReturn_returnReason);
			Weblocator.Openlinks(okBtnTecnicalReturnreaseon);
			Weblocator.getWindowHandle();
			Weblocator.explicitWait(2);
			if (returnreason.equalsIgnoreCase("Technical Return")) {
				Weblocator.clickOnTAB(returnReasonTextField);
				Weblocator.getWindowHandle();
				Weblocator.keyPressALTQ(draweeBrTextFile_TecnicalReturnframe);
				Weblocator.getWindowHandle();
				Weblocator.explicitWait(5);
				Weblocator.TextField(codetextField_draweeBr,"013503002");
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(searchBtnDraweeBr);
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(selectDraweebr);
				Weblocator.explicitWait(3);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(this.okBtnDraweeBr);
				Weblocator.explicitWait(3);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(dialogFrame);
				Weblocator.getWindowHandle();
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(ok_technicalReturn);
				Weblocator.getWindowHandle();
				Weblocator.explicitWait(3);
			}

			Weblocator.Openlinks(autoCBWDropDown);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(autoCBWDropDown_No_Option);
			Weblocator.explicitWait(1);
			instNo=Weblocator.GetAttributevalue(instNoGet);
		}
		else if (liqType.equals("Paid_O_type")) {
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(paidOption);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(autoCBWDropDown);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(autoCBWDropDown_No_Option);
			Weblocator.explicitWait(1);
			instNo=Weblocator.GetAttributevalue(instNoGet);
		}
		return instNo;
	}



}








