package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredCollectionEntryAuthPage extends Setup{
	
    //public By = By.xpath("");
	//-----------------auth---
	public By retrieveF7= By.xpath("//*[text()='Retrieve (F7)']");
	public By clearF1= By.xpath("//*[text()='Clear (F1)']");
	public By batchNoSearchFilterTextField= By.xpath("(//*[@eventproxy='isc_DBListGrid_0']//*[@oninput='isc_TextItem_0._handleInput()'])[1]");
	public By batchNoFirstRow= By.xpath("(//*[@eventproxy='isc_DBListGrid_0']//*[@role='listitem'])[2]/td[2]/div[1]");
	public By authCheckBox= By.xpath("//*[@eventproxy='isc_DBListGrid_1']//*[text()='Auth (F2)']");
	public By rejectCheckBox= By.xpath("//*[@eventproxy='isc_DBListGrid_1']//td[12]/div/span");
	public By noItemMsgGetText= By.xpath("//*[@eventproxy='isc_DBListGrid_0']//*[text()='No items to show.']");
	
	public By batchDetailBAR= By.xpath("//*[@class='imgSectionHeaderTitleopened']");
	public By depositDetaisBAR= By.xpath("(//*[@class='imgSectionHeaderTitleclosed'])[2]");
	public By instrumentDetailBAR= By.xpath("(//*[@class='imgSectionHeaderTitleclosed'])[3]");
	public By enrichmentsDetailBAR= By.xpath("(//*[@class='imgSectionHeaderTitleclosed'])[4]");
	
	public By pickUPDate= By.xpath("//*[@oninput='filterPickupDateStradf._handleInput()']");
	public By rejectRemarkPopUpHeader= By.xpath("(//*[text()='Reject Remarks'])[1]");
	
	public By clientDepositDetailsFirstRow= By.xpath("(//*[@eventproxy='isc_DBListGrid_1']//*[@role='listitem'])[2]/td[2]/div[1]");
	public By userInfoF10= By.xpath("//*[text()='User Info (F10)']");
	
	public By remarkTextField= By.name("remarks");
	public By checkerAction= By.xpath("(//*[@class='detailBlock'])[2]//tr[4]/td[2]");
	public By remarksTextFiledGetText= By.name("makerCheckerRemarks");
	public By batchNotFoundMsg= By.xpath("(//*[@class='emptyMessage'])[1]");
	
/*	
	public By = By.xpath("(//*[@class='emptyMessage'])[1]");
	public By = By.xpath("");
	public By = By.xpath("");
	public By = By.xpath("");
	public By = By.xpath("");*/

	public void Clean_Retrieve() {
		Weblocator.Openlinks(clearF1);
		Weblocator.Openlinks(retrieveF7);
		Weblocator.explicitWait(2);
	}
	
	
	public void SearchBatchNo(String batchNo) {
		//dashboard.DeferredCollectionEntryPageAuth();
		//CommanClass.Openlinks(clearF1);
		//CommanClass.Openlinks(retrieveF7);
		Weblocator.TextFieldWithOutTAB(batchNoSearchFilterTextField, batchNo);
		Weblocator.PressEnterBtn(batchNoSearchFilterTextField);
		Weblocator.explicitWait(2);
		Weblocator.DoubleClick(batchNoFirstRow);
		Weblocator.explicitWait(1);
	}
	
	public void Rejection(String remarkMsg) {
		Weblocator.TextField(remarkTextField, remarkMsg);
		Weblocator.Openlinks(elecomm.okBtn);
	}
	
	public void UserInfo() {
		Weblocator.DoubleClick(clientDepositDetailsFirstRow);
		Weblocator.Openlinks(userInfoF10);
	}
	
	public void authentication(String batchNo) {
		Clean_Retrieve();
		Weblocator.TextFieldWithOutTAB(batchNoSearchFilterTextField, batchNo);
		Weblocator.PressEnterBtn(batchNoSearchFilterTextField);
		Weblocator.explicitWait(1);
		Weblocator.DoubleClick(batchNoFirstRow);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(authCheckBox);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(deferredcollEntry.saveBtnf11);
		Weblocator.explicitWait(4);
		//System.out.println(CommanClass.getPagetext(ElementCommon.popupMessage));
	}
	
	public String BatchRemoveAfterAuth(String batchNo) {
		Clean_Retrieve();
		Weblocator.TextFieldWithOutTAB(batchNoSearchFilterTextField, batchNo);
		//WebDriverManager.explicitWait(2);
		Weblocator.PressEnterBtn(batchNoSearchFilterTextField);
		Weblocator.explicitWait(2);
		//CommanClass.DoubleClick(batchNoFirstRow);
		//WebDriverManager.explicitWait(2);
		String msg=Weblocator.getPagetext(batchNotFoundMsg);
		return msg;
	}

}
    
    
    
    
    
    
    
    
