package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DispatchAllocationPage extends Setup{

	//public By = By.xpath("");

	public By productCodeTextField= By.name("searchProductCode");
	public By clearingLoctextField= By.name("searchClearingLoc");
	public By arrangementTextField= By.name("searchArrangement");
	public By searchBtnFirstRow= By.xpath("(//*[@role='listitem']/td[1]/div[1])[2]");


	public By detailsBtnFirstRow= By.xpath("(//*[@role='listitem']/td[2]/div[1])[2]/span[1]");
	public By modifyBtnFirstRowAfterClickDetailsBtn= By.xpath("(//*[@role='listitem']/td[12])[2]//span[1]");
	public By dispBnkAftermodify= By.name("dispBnk");
	public By dispBkArgAfterModify= By.name("dispBkArg");
	public By addToGridBtn= By.xpath("(//*[text()='Add To Grid (F3)'])[2]");
	public By saveBtn= By.xpath("(//*[text()='Save (F11)'])[2]");

	public By modifyBtnFirstRow= By.xpath("(//*[@role='listitem']/td[11]/div[1]/span)[2]");
	public By allocateCheckBox= By.xpath("//label[text()='Allocate']//preceding::span[1]");
	public By allcateStatusFirstRow= By.xpath("(//*[@role='listitem']/td[10]/div[1])[2]");




	public boolean retrieve(String product, String clearingLoc) {
		boolean status=false;
		Weblocator.TextField(productCodeTextField, product);
		Weblocator.TextField(clearingLoctextField, clearingLoc);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		status=Weblocator.IselementPresent(searchBtnFirstRow);
		return status;
	}


	public boolean modify() {
		boolean status=false;

		Weblocator.Openlinks(detailsBtnFirstRow);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(modifyBtnFirstRowAfterClickDetailsBtn);
		Weblocator.explicitWait(1);
		Weblocator.clearText(dispBnkAftermodify);
		Weblocator.explicitWait(1);
		Weblocator.TextField(dispBnkAftermodify, "UTIG");
		Weblocator.explicitWait(1);
		Weblocator.clearText(dispBkArgAfterModify);
		Weblocator.explicitWait(1);
		Weblocator.TextField(dispBkArgAfterModify, "D+1");
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(addToGridBtn);
		Weblocator.explicitWait(3);
		status=Weblocator.Openlinks(saveBtn);
		Weblocator.explicitWait(3);
		return status;
	}

	public String afterModify() {
		Weblocator.Openlinks(allocateCheckBox);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.addToGridBtnF3);
		Weblocator.explicitWait(1);
		String msg=Weblocator.getPagetext(allcateStatusFirstRow);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(3);
		String popupmsg=elecomm.PopupHandle_dataSave();  //expected msg:  G00023-Incomplete Entry, Please Complete.
		return popupmsg;

	}







}








