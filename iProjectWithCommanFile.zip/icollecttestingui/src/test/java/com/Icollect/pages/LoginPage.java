package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class LoginPage extends Setup{
	
    //public By = By.xpath("");
    public By username=By.id("execute_j_username");
	public By password =By.id("execute_j_password");
	public By login_btn=By.id("login");
	public By mesters_tab=By.xpath("//*[@id='nav-bar']/a[2]");

	public By title_gettxt=By.xpath("//*[@title='Anurag']");
	public By pagereload_gettxt=By.xpath("//*[@jsselect='heading']");
	//public By pagereload_gettxt=By.xpath("//*[text()='An error occurred.']");
    
	
	public Boolean login(String User)  
	{
		Weblocator.explicitWait(1);
		Boolean loginbtn=false;

		Boolean user=Weblocator.TextField(username, User);
		Weblocator.TextField(password, "12345678");
		
		if (user) {
			Weblocator.Openlinks(login_btn);	
			Boolean error=false;
			error=driver.findElements(pagereload_gettxt).size()!=0;
			if (error) 
			{
				driver.get(baseURL);
				login(User);
			}
			loginbtn=true;
		}
		
		return loginbtn;
			
	}
	
/*	public Boolean loginbyDeepak(String User) 
	{
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		Boolean loginbtn=false;
		
		Boolean user=CommanClass.TextField(username, User,"username");
	
		CommanClass.TextField(password, "12345678","password");
		
		if (user) {
			CommanClass.Openlinks(login_btn);	
			Boolean error=false;
			error=driver.findElements(pagereload_gettxt).size()!=0;
			if (error) 
			{
				driver.get(baseURL);
				login(User);
			}
			loginbtn=true;
		}
		
		return loginbtn;
			
	}*/
	
	//@Step("getting login page title step....")
	public String getLoginPageTitle() {
		String title=driver.getTitle();
		return title;
		
	}


}
    
    
    
    
    
    
    
    
