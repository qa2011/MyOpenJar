package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import com.util.Setup;
import com.util.Weblocator;

public class TransactionsPage extends Setup{
	public static String testdata=null;
	public String thereRefNoAfterAuth="";
	public String depositer = "";

	public By breadcrumbNavigation= By.xpath("//*[text()='Client Input > Data Entry']");
	public By batch= By.xpath("(//*[@class='formTitleDisabled']//label)[1]");
	public By batchTextField= By.xpath("(//*[@name='batchNo'])[2]");
	public By status= By.xpath("(//*[@class='formTitleDisabled']//label)[2]");
	public By PDCBatch= By.xpath("(//*[@class='formTitle']//label)[1]");
	public By PDCBatchRadioBtn_yes= By.xpath("(//*[@name='batchType'])[1]");
	public By PDCBatchRadioBtn_no= By.xpath("(//*[@name='batchType'])[2]");
	public By inputDepositNoTextField= By.name("inputDepositNo");
	public By TheirReference= By.xpath("(//*[@class='formTitle']//label)[2]");
	public By TheirReferenceTextField= By.name("referenceNo");
	public By PickupLocation= By.xpath("(//*[@class='formTitle']//label)[3]");
	public By PickupLocationTextField= By.name("pickUpLocCode");
	public By PickupLocationHint= By.xpath("//*[@id='isc_2X']/span");
	public By PickupDt= By.xpath("(//*[@class='formTitle']//label)[4]");
	public By PickupDt_date= By.name("pickUpDate");
	public By Product= By.xpath("(//*[@class='formTitle']//label)[5]");
	public By ProductTextField= By.name("productCode");
	public By ProductHint= By.xpath("//*[@id='isc_3C']/span");
	public By ActivationDt= By.xpath("(//*[@class='formTitle']//label)[6]");
	public By ActivationDt_date= By.name("activationDate");

	public By DispBank= By.xpath("(//*[@class='formTitle']//label)[7]");
	public By DispBankTextField= By.name("dispatchBankCode");
	public By DispBranch= By.xpath("(//*[@class='formTitle']//label)[8]");
	public By DispBranchTextField= By.name("dispatchBranchCode");
	public By Arrangement= By.xpath("(//*[@class='formTitle']//label)[9]");
	public By ArrangementTextField= By.name("arrangementCode");
	public By TotalDep= By.xpath("(//*[@class='formTitle']//label)[10]");
	public By TotalDepTextField= By.name("totalDeposits");
	public By TotalAmnt= By.xpath("(//*[@class='formTitle']//label)[11]");
	public By TotalAmntField= By.name("totalAmount");
	public By Remarks= By.xpath("(//*[@class='formTitle']//label)[12]");
	public By RemarksTextField= By.name("remarks");
	public By ReportedDep= By.xpath("(//*[@class='formTitle']//label)[13]");
	public By ReportedDepTextField= By.name("actualDeposits");
	public By ReportedAmnt= By.xpath("(//*[@class='formTitle']//label)[14]");
	public By ReportedAmntTextFiled= By.name("actualAmount");
	public By EntryDt= By.xpath("(//*[@class='formTitle']//label)[15].");

	public By saveBtn= By.xpath("//*[text()='Save (F11)']");
	public By saveBtn_DepositTAB= By.xpath("(//*[text()='Save (F11)'])[2]");
	public By saveBtn_instrumentTAB= By.xpath("(//*[text()='Save (F11)'])[3]");
	public By clearBtn= By.xpath("//*[text()='Clear (F1)']");
	public By retrieveBtn= By.xpath("//*[text()='Retrieve (F7)']");
	public By userInfoBtn= By.xpath("//*[text()='User Info (F10)']");

	public By backBtn= By.id("isc_FN");
	public By backBtn_f12= By.xpath("//*[text()='Back (F12)']");
	public By userInfoBtnID= By.id("isc_FR");
	public By summaryBtn= By.id("isc_FV");
	public By batchSearch= By.id("isc_J5");
	public By batchNoGetFromBatchSummary= By.xpath("(//*[@role='listitem'])[2]/td[3]/div");

	//----------------------deposit TAB-----------
	public By clientTextField= By.name("clientCode");
	public By pickUpPointTextField= By.name("pickUpPointCode");
	public By totalInstTextfield= By.name("totInstruments");
	public By totalAmountTextfield= By.name("totAmount");
	//------------------------instrument
	public By instrumentNoTextField= By.name("instrumentNo");
	public By draweeBranchCodeTextFiled= By.name("draweeBranchCode");
	public By instrumentAmountTextFiled	= By.name("instrumentAmount");
	public By instrumentDateStrTextFiled= By.name("instrumentDateStr");
	public By add= By.name("instrumentDateStr");
	public By batchFromTextField= By.name("searchBatchNo");
	public By batchToTextField= By.name("searchBatchTo");
	public By selectInstFirstRow= By.xpath("(//*[@role='listitem']/td[1]/div[1])[1]");

	//-------------------------Add Enrichment------------------
	public By noTextField= By.name("1_FIELD");
	public By drawerNameTextField= By.name("2_FIELD");
	public By pickupDateTextField= By.name("3_FIELD");
	public By saveBtnEnrichmentTab= By.xpath("(//*[text()='Save (F11)'])[4]");
	public By saveBtnAfterEnrichment= By.xpath("(//*[text()='Save (F11)'])[3]");


	//----------auth-------
	public By selectBatchNo= By.xpath("(//*[@role='listitem'])[2]/td[2]");
	public By authCheckBox= By.xpath("(//*[@role='listitem'])[4]/td[11]//span[1]");
	public By authCheckBoxforABIL= By.xpath("(//*[@class='headerTitle'])[10]");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem'])[4]/td[12]//span[1]");

	public By batchNoFromBatchSummary= By.xpath("(//*[@role='listitem'])[2]/td[3]/div");
	public By emptyMsg= By.xpath("//*[text()='No items to show.']");

	public By policyNoTextField=By.name("1_FIELD");
	public By savebtnEnrichMentTAB= By.xpath("(//*[text()='Save (F11)'])[4]");

	public String batchCreation() {
		Weblocator.TextField(PickupLocationTextField, "MUM");
		Weblocator.TextField(ProductTextField, "D-DBMICR");
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		Weblocator.TextField(TotalDepTextField, "1");
		Weblocator.TextField(TotalAmntField, "1000");
		Weblocator.random();
		testdata="1"+Weblocator.value;
		String TheirReferenceValue="Testing"+testdata;  //---------to be use in feature

		Weblocator.TextField(TheirReferenceTextField,TheirReferenceValue);
		Weblocator.Openlinks(saveBtn);
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		String batchno=Weblocator.GetAttributevalue(batchTextField);
		System.out.println("Batch No : "+ batchno);
		//WebDriverManager.explicitWait(1);
		Weblocator.TextField(clientTextField, "ABIL");
		//WebDriverManager.explicitWait(2);

		Weblocator.TextField(totalInstTextfield, "1");
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(totalAmountTextfield, "1000");
		//WebDriverManager.explicitWait(2);
		depositer="Depno"+testdata;
		Weblocator.TextField(inputDepositNoTextField, depositer);
		Weblocator.Openlinks(saveBtn_DepositTAB);
		elecomm.PopupHandle_dataSave();
		//WebDriverManager.explicitWait(3);
		/*
		CommanClass.TextField(instrumentNoTextField, "Test"+testdata);
		CommanClass.TextField(draweeBranchCodeTextFiled, "400001001");
		CommanClass.TextField(instrumentAmountTextFiled, "1000");

		try {
			Thread.sleep(2000);
		}catch (Exception e) {
			// TODO: handle exception
		}
		CommanClass.TextFieldWithOutTAB(instrumentDateStrTextFiled, "16112018");
		driver.findElement(instrumentDateStrTextFiled).sendKeys(Keys.TAB);
		//--------------------------------------------------
		CommanClass.Openlinks(saveBtn_instrumentTAB);

		elecomm.PopupHandle_dataSave();
		//elecomm.PopupHandle_dataSave();
		CommanClass.getWindowHandle();
		try {
			TimeUnit.SECONDS.sleep(2);
		}catch (Exception e) {
			System.out.println("error in time");
		}*/
		dashboard.logout();
		//WebDriverManager.explicitWait(2);

		login.login("rachitranjans@hcl.com");
		//WebDriverManager.explicitWait(2);
		dashboard.TransactionAuth();
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(batchFromTextField, batchno);
		Weblocator.TextField(batchToTextField, batchno);
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(retrieveBtn);
		//WebDriverManager.explicitWait(2);
		/*	CommanClass.DoubleClick(selectBatchNo);
		CommanClass.getWindowHandle();
		CommanClass.scrollingByCoordinatesofAPage();*/
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(authCheckBoxforABIL);
		//WebDriverManager.explicitWait(2);
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.Openlinks(saveBtn);
		//WebDriverManager.explicitWait(2);
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		//WebDriverManager.explicitWait(2);
		elecomm.PopupHandle_dataSave();
		//WebDriverManager.explicitWait(2);
		dashboard.logout();
		login.login("anuragsin@hcl.com");
		//dashboard.Transaction();
		thereRefNoAfterAuth=TheirReferenceValue;
		return batchno;
	}

	public String batchCreation_O_Type(String pickUploc, String Product,String Client, String totaldep, String Totalamount ) {
		Weblocator.TextField(PickupLocationTextField, pickUploc);
		Weblocator.TextField(ProductTextField, Product);
		Weblocator.explicitWait(1);
		//elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		Weblocator.TextField(TotalDepTextField, totaldep);
		Weblocator.TextField(TotalAmntField, "1000");
		Weblocator.random();
		String TheirReferenceValue="OTRe"+Weblocator.randomeNum();  //---------to be use in feature

		Weblocator.TextField(TheirReferenceTextField,TheirReferenceValue);
		Weblocator.Openlinks(saveBtn);
		Weblocator.explicitWait(1);
		//elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		String batchno=Weblocator.GetAttributevalue(batchTextField);
		System.out.println("Batch No : "+ batchno);
		//WebDriverManager.explicitWait(1);
		Weblocator.TextField(clientTextField, Client);
		//WebDriverManager.explicitWait(2);
		elecomm.PopupHandle_dataSave();
		Weblocator.TextField(totalInstTextfield, "1");
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(totalAmountTextfield, Totalamount);
		//WebDriverManager.explicitWait(2);
		depositer="Odep"+Weblocator.randomestring();
		Weblocator.TextField(inputDepositNoTextField, depositer);
		Weblocator.Openlinks(saveBtn_DepositTAB);
		elecomm.PopupHandle_dataSave();
		//WebDriverManager.explicitWait(3);

		Weblocator.TextField(instrumentNoTextField, "Oinst"+Weblocator.randomeNum());
		Weblocator.TextField(draweeBranchCodeTextFiled, "APG,PRAGNA");
		Weblocator.TextField(instrumentAmountTextFiled, "1000");
		Weblocator.explicitWait(3);
		Weblocator.TextFieldWithOutTAB(instrumentDateStrTextFiled, "16112018");
		driver.findElement(instrumentDateStrTextFiled).sendKeys(Keys.TAB);
		//--------------------------------------------------
		Weblocator.Openlinks(saveBtn_instrumentTAB);
		elecomm.PopupHandle_dataSave();
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(2);
		//----------------add enrichment---------
		Weblocator.Openlinks(elecomm.enrichBtnF2);
		String polictNo="Pol"+Weblocator.randomeNum();
		Weblocator.TextField(policyNoTextField, polictNo);
		Weblocator.Openlinks(savebtnEnrichMentTAB);
		Weblocator.explicitWait(3);
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();

		dashboard.logout();

		login.login("rachitranjans@hcl.com");
		//WebDriverManager.explicitWait(2);
		dashboard.TransactionAuth();
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(batchFromTextField, batchno);
		Weblocator.TextField(batchToTextField, batchno);
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(retrieveBtn);
		//WebDriverManager.explicitWait(2);
		/*	CommanClass.DoubleClick(selectBatchNo);
		CommanClass.getWindowHandle();
		CommanClass.scrollingByCoordinatesofAPage();*/
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(authCheckBoxforABIL);
		//WebDriverManager.explicitWait(2);
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.Openlinks(saveBtn);
		//WebDriverManager.explicitWait(2);
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		//WebDriverManager.explicitWait(2);
		elecomm.PopupHandle_dataSave();
		//WebDriverManager.explicitWait(2);
		dashboard.logout();
		login.login("anuragsin@hcl.com");
		//dashboard.Transaction();
		thereRefNoAfterAuth=TheirReferenceValue;
		return batchno;
	}

	public String batchCreation_N_Type(String pickUploc, String Product,String Client, String totaldep, String Totalamount, 
			String totalInst, String pickUpPoint, String draweeBranch) {
		Weblocator.TextField(PickupLocationTextField, pickUploc);
		Weblocator.TextField(ProductTextField, Product);
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		Weblocator.TextField(TotalDepTextField, totaldep);
		Weblocator.TextField(TotalAmntField, Totalamount);


		String TheirReferenceValue="Testing"+Weblocator.randomeNum();  //---------to be use in feature

		Weblocator.TextField(TheirReferenceTextField,TheirReferenceValue);
		Weblocator.Openlinks(saveBtn);
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		String batchno=Weblocator.GetAttributevalue(batchTextField);
		System.out.println("Batch No : "+ batchno);
		//WebDriverManager.explicitWait(1);
		Weblocator.TextField(clientTextField, Client);
		Weblocator.explicitWait(2);
		Weblocator.TextField(pickUpPointTextField, pickUpPoint);
		Weblocator.explicitWait(2);
		Weblocator.TextField(totalInstTextfield, totalInst);
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(totalAmountTextfield, Totalamount);
		//WebDriverManager.explicitWait(2);
		depositer="Depno"+Weblocator.randomeNum();
		Weblocator.TextField(inputDepositNoTextField, depositer);
		Weblocator.Openlinks(saveBtn_DepositTAB);
		//elecomm.PopupHandle_dataSave();
		Weblocator.explicitWait(3);

		//---------------------dgsfdgfdgfdg----------------
		for (int i = 1; i <=4; i++) {
			Weblocator.TextField(instrumentNoTextField, "inst"+Weblocator.randomeNum());
			Weblocator.TextField(draweeBranchCodeTextFiled, draweeBranch);
			if (i==1) {
				Weblocator.TextField(instrumentAmountTextFiled,"200");
			}
			if (i==2) {
				Weblocator.TextField(instrumentAmountTextFiled,"800");
			}
			if (i==3) {
				Weblocator.TextField(instrumentAmountTextFiled,"600");
			}
			if (i==4) {
				Weblocator.TextField(instrumentAmountTextFiled,"400");
			}

			Weblocator.explicitWait(2);
			Weblocator.TextFieldWithOutTAB(instrumentDateStrTextFiled, "16112018");
			driver.findElement(instrumentDateStrTextFiled).sendKeys(Keys.TAB);
			if (i==4) {
				break;
			}

			Weblocator.Openlinks(elecomm.addInstBtnF4);
			Weblocator.explicitWait(2);
		}
		//--------------------------------------------------
		Weblocator.Openlinks(saveBtn_instrumentTAB);
		elecomm.PopupHandle_dataSave();
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(3);

		//---------------------fdgdrhdh------------------------
		dashboard.logout();
		//WebDriverManager.explicitWait(2);

		login.login("rachitranjans@hcl.com");
		//WebDriverManager.explicitWait(2);
		dashboard.TransactionAuth();
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(batchFromTextField, batchno);
		Weblocator.TextField(batchToTextField, batchno);
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(retrieveBtn);
		//WebDriverManager.explicitWait(2);
		/*	CommanClass.DoubleClick(selectBatchNo);
		CommanClass.getWindowHandle();
		CommanClass.scrollingByCoordinatesofAPage();*/
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(authCheckBoxforABIL);
		//WebDriverManager.explicitWait(2);
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.Openlinks(saveBtn);
		//WebDriverManager.explicitWait(2);
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		//WebDriverManager.explicitWait(2);
		elecomm.PopupHandle_dataSave();
		//WebDriverManager.explicitWait(2);
		dashboard.logout();
		login.login("anuragsin@hcl.com");
		//dashboard.Transaction();
		thereRefNoAfterAuth=TheirReferenceValue;
		return batchno;
	}

	public String batchAuth(String enterBatchNo) {
		String msg=null;
		Weblocator.TextField(trns.batchFromTextField, enterBatchNo);
		Weblocator.TextField(trns.batchToTextField, enterBatchNo);
		Weblocator.Openlinks(trns.retrieveBtn);

		boolean find=Weblocator.IselementPresent(trns.authCheckBoxforABIL);
		if (find)
		{
			Weblocator.Openlinks(trns.authCheckBoxforABIL);
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			Weblocator.Openlinks(trns.saveBtn);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.yesBtn2);
			Weblocator.explicitWait(3);
			Weblocator.getWindowHandle();
			msg=elecomm.PopupHandle_dataSave();
		}
		else {
			msg="Batch No not present";
		}


		return msg;
	}



}








