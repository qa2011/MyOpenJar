package com.Icollect.pages;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentReceiptAuthPage extends Setup{
	
    //public By = By.xpath("");

	
	public By productTextField= By.name("formProduct");
	public By makerTextField= By.name("inputMakerCode");
	
	public By productFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By authCheckBoxAll= By.xpath("//*[text()='Auth. (F2)']");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem'])[2]/td[10]/div[1]/span[1]");
	
	public By referenceNoFilter= By.xpath("(//*[@class='listGrid']//*[@role='listitem'])[1]/td[5]//input");
	public By searchBtnFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[1]/div[1]");
	public By rejectMsgGetText= By.name("//*[@class='detailBlock']//tr[4]/td[2]");
	
	public By noItemShowMsgGetText= By.xpath("//*[text()='No items to show.']");
	
	
	public String retrieve(String productName, String makerName) {
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productTextField, productName);
		Weblocator.TextField(makerTextField, makerName);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		String product=Weblocator.getPagetext(productFirstRow);
		return product;
	}
	
	

	public String reject(String refNo) throws InterruptedException {
		//WebDriverManager.explicitWait(1);
		Weblocator.TextField(referenceNoFilter, refNo);
		Weblocator.PressEnterBtn(referenceNoFilter);
		TimeUnit.SECONDS.sleep(2);
		Weblocator.Openlinks(rejectCheckBox);
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, "RefReceipt Rejected");
		Weblocator.Openlinks(elecomm.okBtnRemarkPopup);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		TimeUnit.SECONDS.sleep(2);
		Weblocator.TextField(referenceNoFilter, refNo);
		TimeUnit.SECONDS.sleep(1);
		Weblocator.PressEnterBtn(referenceNoFilter);
		Weblocator.Openlinks(elecomm.userinfoBtnF10);
		Weblocator.getWindowHandle();
		String status=Weblocator.getPagetext(elecomm.statusCheckerActionRejectPopupGetText);
		Weblocator.Openlinks(elecomm.userInfoClose);
		Weblocator.getWindowHandle();
		return status;
	}
	
	
	public String auth(String refNo) {
		Weblocator.TextField(referenceNoFilter, refNo);
		Weblocator.PressEnterBtn(referenceNoFilter);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(authCheckBoxAll);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		String msg=Weblocator.getPagetext(noItemShowMsgGetText);
		return msg;
	}
	

	
 

}
    
    
    
    
    
    
    
    
