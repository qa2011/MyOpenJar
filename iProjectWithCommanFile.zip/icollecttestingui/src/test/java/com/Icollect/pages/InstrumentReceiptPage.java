package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentReceiptPage extends Setup{
	
    //public By = By.xpath("");
	
	public By scheduleNoTextField= By.name("formScheduleNo");
	public By productTextField= By.name("formProduct");
	public By dispBankTextField= By.name("formDispBank");
	public By dispBranchTextField= By.name("formDispBranch");
	public By clientCodeTextField= By.name("formClientCode");
	public By draweeBankTextField= By.name("formDraweeBank");
	public By draweeBranchTextField= By.name("formDraweeBranch");
	public By instNumberTextField= By.name("formInstNumber");
	public By instAmountTextField= By.name("formInstAmnt");
	public By instDateTextField= By.name("formInstDate");
	public By inputMakerCodeTextField= By.name("inputMakerCode");
	public By referenceTextField= By.name("referenceNumber");
	
	public By scheduleNoFilter= By.xpath("(//*[@class='listGrid']//*[@role='listitem'])[1]/td[2]//input");
	public By schedulerNoFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By recvdCheckBoxFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[12]/div[1]/span[1]");
	public By noItemShowMsgGetText= By.xpath("//*[text()='No items to show.']");
	
	public By regularRadioBtn= By.xpath("(//*[@name='formBankType'])[1]");
	public By adhocRadioBtn= By.xpath("(//*[@name='formBankType'])[2]");
/*	public By = By.name("");
	public By = By.name("");
	public By = By.name("");
	public By = By.name("");*/
	
	public String retrieve(String productName, String scheduleNo_TheirRefNo) {
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productTextField, productName);
		Weblocator.TextField(scheduleNoTextField, scheduleNo_TheirRefNo);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		String schedulerNo=Weblocator.getPagetext(schedulerNoFirstRow);
		return schedulerNo;
	}
	
	
	public String recivedVerify(String refrenceNo) throws InterruptedException {
		//CommanClass.TextField(scheduleNoFilter, schedulerNo);
		//CommanClass.PressEnterBtn(scheduleNoFilter);
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(referenceTextField, refrenceNo);
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(recvdCheckBoxFirstRow);
		//WebDriverManager.explicitWait(2);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		//WebDriverManager.explicitWait(2);
		String noItemMsg=Weblocator.getPagetext(noItemShowMsgGetText);
		return noItemMsg;
	}

	
 

}
    
    
    
    
    
    
    
    
