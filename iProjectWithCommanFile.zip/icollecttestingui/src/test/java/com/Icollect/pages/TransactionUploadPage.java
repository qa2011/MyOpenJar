package com.Icollect.pages;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.util.Weblocator;
import com.util.ReadConfig;
import com.util.Setup;

public class TransactionUploadPage extends Setup{

	//public By = By.xpath("");
	public By breadcrumbNavigationTransactionUpload= By.xpath("//*[text()='Client Input > Transaction Upload']");
	public By FileLable= By.xpath("(//*[@class='formTitle']//label[text()='File'])");
	public By TransactionUploadTab= By.xpath("(//*[@class='tabTitleSelected'][text()='Transaction Upload'])");
	public By UploadStatusLable= By.xpath("(//*[@class='formTitleFocused']//label[text()='Upload Status'])");
	public By UploadStatusRadioBtn_Online= By.xpath("(//*[@name='uploadStatus'])[1]");
	public By UploadStatusRadioBtn_Offline= By.xpath("(//*[@name='uploadStatus'])[2]");	
	public By UploadTypeLable= By.xpath("(//*[@class='formTitle']//label[text()='Upload Type'])");	
	public By UploadTypelstbox= By.xpath("(//*[@class='selectItemControl']//div)[@class='textbox']");  //public By UploadType= By.xpath("(//div[@class = 'textbox'])");	//   Need to be clarified	
	public By UploadTypeDropDwnicon= By.xpath("(//*[@class='selectItemControl']//*)[@class='selectItemPickerIcon']");
	//public By ProductCode= By.xpath("(//input[@name = 'productcode'])");
	//public By UploadTypeSelection= By.xpath("(//*[@class='pickListCell']//div)[1]");	
	public By UploadTypeTxnUpload= By.xpath("//div[@role='presentation' and text()='Transaction Upload']");
	public By UploadTypeUCCGTxnUpload= By.xpath("//div[@role='presentation' and text()='UCC-G Transaction Upload']");
	public By UploadTypeEBTxnUpload= By.xpath("//div[@role='presentation' and text()='EB Transaction Upload']");
	public By UploadTypeSAFRAN= By.xpath("//div[@role='presentation' and text()='SAFRAN Transaction Upload']");
	public By UploadTypeCluster= By.xpath("//div[@role='presentation' and text()='Cluster Transaction Upload']");	
	public By RetrieveBtn= By.xpath("//div[text() = 'Retrieve(F7)']"); 
	
	public By fileNameFirstRow= By.xpath("(//*[@role='listitem' ]/td[3]/div[1])[2]");
	public By checkBoxFirstRow=By.xpath("(//*[@role='listitem' ]/td[1]/div[1]/span)[2]");
	public By statusCol=By.xpath("(//*[@role='listitem' ]/td[10]/div)[2]");
	
	public By searchIconBtn= By.xpath("(//*[@role='listitem' ]/td[2]/div/span)[2]");
	public By dateTimeCol= By.xpath("(//*[@role='listitem' ]/td[4]/div)[2]");
	public By productCodeCol= By.xpath("(//*[@role='listitem' ]/td[5]/div)[2]");
	public By rejectCountCol= By.xpath("(//*[@role='listitem' ]/td[9]/div)[2]");
	public By status_reject= By.xpath("(//*[@role='listitem' ]/td[10]/div)[2]");
	public By rejectReason= By.xpath("(//*[@role='listitem' ]/td[11]/div)[2]");
	public By clearBtF1= By.xpath("//*[text()='Clear(F1)']");
	public By onlineRadioBtn= By.xpath("(//*[@name='uploadStatus'])[1]");
	public By offlineRadioBtn= By.xpath("(//*[@name='uploadStatus'])[2]");
	public By fileUploadedGetText= By.xpath("//*[@name='uploaded']");
	
	public By productCodeInfo= By.xpath("(//*[@name='productCode'])[2]");
	public By batchNoInfo= By.xpath("(//*[@name='batchNo'])");
	public By pickupLocationInfo= By.xpath("(//*[@name='pickupLocationDesc'])");
	public By statusInfo= By.xpath("(//*[@name='status'])");
	public By closeBtnInfo= By.xpath("(//*[@eventproxy='txnUpldWindow_closeButton'])");
	
/*	public By offlineRadioBtn= By.xpath("(//*[@name='uploadStatus'])[2]");
	public By searchIconBtn= By.xpath("(//*[@role='listitem' ]/td[2]/div/span)[2]");
	public By = By.xpath("");*/
	
	
	//-------------After Upload---------
	public By statusColAfterUpload=By.xpath("(//*[@role='listitem' ]/td[9]/div)[2]");
	public By uploadNoAfterUpload= By.xpath("(//*[@role='listitem' ]/td[11]/div)[2]");
	public By batchNo= By.name("batchNo");
	//public By = By.xpath("");
	//public By = By.xpath("");
	
	
	
	
	
	
	// ("//class name //td[@class ='buttonTitleSelected']// div[text() = 'Retrieve(F7)']"); // buttonTitleSelectedDisabled 
	public By ChooseFilebtn= By.xpath("//input[@Type='FILE' and @name='file']");
	public By FormHintMaxFilelenght= By.xpath("//*[@class = 'formHint'][text()='Max file size is 10 MB']");
	public By OkBtn= By.xpath("//div[text() = 'OK(F2)']"); 
	public By UploadBtn= By.xpath("//*[@name='file']"); 
	public By ClearBtn= By.xpath("//div[text() = 'Clear(F1)']"); 
	public By TotalDepositsLable= By.xpath("(//*[@class='formTitle']//label[text()='Total Deposits'])");
	public By TotalAmmountLable= By.xpath("(//*[@class='formTitle']//label[text()='Total Amount'])");
	public By TotalRejectsLable= By.xpath("(//*[@class='formTitle']//label[text()='Total Rejects'])");
	public By FileUploadedLable= By.xpath("(//*[@class='formTitle']//label[text()='File Uploaded'])");
	public By FileRejectedLable= By.xpath("(//*[@class='formTitle']//label[text()='File Rejected'])");
	
	public By TotalDepositsTxtBox= By.xpath("(*//input[@type ='TEXT'][@name='depositCount'])");
	public By TotalAmmountTxtBox= By.xpath("(*//input[@type ='TEXT'][@name='totalAmount'])");
	public By TotalRejectsTxtBox= By.xpath("(*//input[@type ='TEXT'][@name='rejectCount'])");
	public By FileUploadedTxtBox= By.xpath("(*//input[@type ='TEXT'][@name='uploaded'])");
	public By FileRejectedTxtBox= By.xpath("(*//input[@type ='TEXT'][@name='rejected'])");
	
	
	//*************Grid Header details************************
	
	public By GridHeaderChkBox= By.xpath("(//*[@class='headerTitle']//div[@id='isc_4Q'])");
	public By GridHeaderInfo= By.xpath("(//*[@class='headerTitle']//div[text()='Info'])");
	public By GridHeaderFileName= By.xpath("(//*[@class='headerTitleSelected']//div[text()='File Name'])");
	public By GridHeaderDAteTime= By.xpath("(//*[@class='headerTitle']//div[text()='Date Time'])");
	public By GridHeaderEnc= By.xpath("(//*[@class='headerTitle']//div[text()='Enc?'])");
	public By GridHeaderProduct= By.xpath("(//*[@class='headerTitle']//div[text()='Product'])");
	public By GridHeaderLocation= By.xpath("(//*[@class='headerTitle']//div[text()='Location'])");
	public By GridHeaderDepositCount= By.xpath("(//*[@class='headerTitle']//div[text()='Deposit Count'])");
	public By GridHeaderTotalAmt= By.xpath("(//*[@class='headerTitle']//div[text()='Total Amount'])");
	public By GridHeaderRejCount= By.xpath("(//*[@class='headerTitle']//div[text()='Reject Count'])");
	public By GridHeaderStatus= By.xpath("(//*[@class='headerTitle']//div[text()='Status'])");
	public By GridHeaderRejReason= By.xpath("(//*[@class='headerTitle']//div[text()='Reject Reason'])");
	
	


	public boolean retrieve(String filePath) {
		boolean status=false;
		Weblocator.Openlinks(UploadTypeDropDwnicon);
		Weblocator.Openlinks(UploadTypeTxnUpload);
		//WebDriverManager.TextFieldWithOutTAB(UploadBtn, ".C:\\Users\\AnuragSin\\eclipse-workspace_Demo\\icollecttestingui\\InputFolder\\tranUploadFile\\22111830DEL_30_N.735.txt");
		Weblocator.explicitWait(2);
		WebElement chooseFile = driver.findElement(UploadBtn);
		Weblocator.explicitWait(1);
		chooseFile.sendKeys(filePath);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(RetrieveBtn);
		Weblocator.explicitWait(3);
		status=Weblocator.IselementPresent(fileNameFirstRow);
		return status;
	}
	
	public String readyToUploadFile() {
		String statusMsg="";
		Weblocator.Openlinks(checkBoxFirstRow);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.okBtnF2);
		Weblocator.explicitWait(5);
		if (Weblocator.getPagetext(statusCol).equalsIgnoreCase("Ready For Upload")) { //successful upload
			statusMsg=Weblocator.getPagetext(statusCol);
		}
		else if(Weblocator.getPagetext(status_reject).equalsIgnoreCase("Rejected")){  //duplicate file upload, Invalid file upload, Invalid formate file Upload
			String msg= Weblocator.getPagetext(status_reject);
			statusMsg=Weblocator.getPagetext(rejectReason);
			
		}
		else if (Weblocator.getPagetext(status_reject).equalsIgnoreCase("")) { //empty file upload
			statusMsg="";
		}
		return statusMsg;
	}
	
	
	public String UploadFile() {
		Weblocator.Openlinks(elecomm.uploadF11);
		Weblocator.explicitWait(2);
		String statusMsg=Weblocator.getPagetext(statusColAfterUpload);
		return statusMsg;
	}
	
	public String getBatchNo() {
		Weblocator.explicitWait(2);
		String uploadNo=Weblocator.getPagetext(uploadNoAfterUpload);
		Weblocator.explicitWait(2);
		Weblocator.DoubleClick(uploadNoAfterUpload);
		Weblocator.explicitWait(2);
		String batcho=Weblocator.GetAttributevalue(batchNo);
		return batcho;
	}
	
	
	
	public String getBatchNoFromSuccessUploadFile(String fileName) {
		String getbatchNo = null;
		/*ReadConfig readconfig=new ReadConfig();
		driver.get(homeURL);
		dashboard.TransactionUpload();*/
		Weblocator.Openlinks(dashboard.transactionUpload);
		Weblocator.explicitWait(3);
		boolean filenamepresent=tranUpload.retrieve(fileName);   //readconfig.newFile()
		if (filenamepresent) {
			String statusMsg=tranUpload.readyToUploadFile();
			if (StringUtils.isNotBlank(statusMsg)) {
				String statusMsgAfterUpload=tranUpload.UploadFile();
				if (StringUtils.isNotBlank(statusMsgAfterUpload)) {
					getbatchNo=tranUpload.getBatchNo();
				}
			}
		}
		//Elements.Openlinks(tranUpload.clearBtF1);
		Weblocator.explicitWait(2);
		return getbatchNo;
	
	}
	
	
	

	
/*	public boolean reject() {
		boolean status=false;
	
		return status;
	}


	public String auth() {

		return msg;
	}*/


}








