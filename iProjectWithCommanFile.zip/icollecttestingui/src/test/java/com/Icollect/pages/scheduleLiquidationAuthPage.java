package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class scheduleLiquidationAuthPage extends Setup{
	
    //public By = By.xpath("");
	public By makerNameTextField= By.name("makerCode");
	public By scheduleDateFirstCol= By.xpath("(//*[@role='listitem']//td[2]/div[1])[2]");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem']//td[8]/div[1])[2]/span[1]");
	public By authCheckBoxAll= By.xpath("//*[text()='Authorise(F2)']");
	public By noItemMsgGetText= By.xpath("(//*[text()='No items to show.'])[1]");
	
	
	public boolean retrieve(String makerName) 
	{
		Boolean status =false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(makerNameTextField, makerName);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(5);
		if (Weblocator.IselementPresent(scheduleDateFirstCol)) {
			status=true;
		}
		return status;
	}
	
	public String reject(String rejectMSG) {
		Weblocator.explicitWait(2);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, rejectMSG);
		Weblocator.Openlinks(elecomm.okBtn3);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.Openlinks(elecomm.userinfoBtnF10);
		Weblocator.getWindowHandle();
		String check=Weblocator.getPagetext(elecomm.checkerActionGetText);
		Weblocator.Openlinks(elecomm.userInfoClose);
		Weblocator.getWindowHandle();
		return check;
	}
	
	
	public String auth() {
		Weblocator.Openlinks(elecomm.saveBtnF11);
		elecomm.PopupHandle_dataSave();
		String msg=Weblocator.getPagetext(noItemMsgGetText);
		return msg;
	}
	
	
	

}
    
    
    
    
    
    
    
    
