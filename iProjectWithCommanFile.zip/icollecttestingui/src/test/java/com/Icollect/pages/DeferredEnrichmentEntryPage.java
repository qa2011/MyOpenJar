package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredEnrichmentEntryPage extends Setup{

	//public By = By.xpath("");

	public By instNumberTextField= By.name("filterInstNumber");
	public By clientNameFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[3]/div[1]");
	public By testingTextFiled1= By.xpath("//*[@name='T123_FIELD']");
	public By testingTextFiled2= By.xpath("//*[@name='T124_FIELD']");
	public By enrichSetNoGetText= By.xpath("(//*[@role='listitem'])[4]/td[2]/div[1]");

	public By depDateFromStr= By.name("depDateFromStr");
	public By depDateToStr= By.name("depDateToStr");
	public By depNumber= By.name("filterInputDepNumber");
	public By clientCode= By.name("filterClientCode");
	public By productCode= By.name("filterProductCode");
	public By instNumber= By.name("filterInstNumber");

	public By instCol1= By.xpath("(//*[@class='headerTitle'])[2]/div[1]");
	public By instCol2= By.xpath("(//*[@class='headerTitle'])[3]/div[1]");
	public By instCol3= By.xpath("(//*[@class='headerTitle'])[4]/div[1]");
	public By instCol4= By.xpath("(//*[@class='headerTitle'])[5]/div[1]");
	public By instCol5= By.xpath("(//*[@class='headerTitle'])[6]/div[1]");
	public By instCol6= By.xpath("(//*[@class='headerTitle'])[7]/div[1]");
	public By instCol7= By.xpath("(//*[@class='headerTitle'])[8]/div[1]");
	public By instCol8 = By.xpath("(//*[@class='headerTitle'])[9]/div[1]");
	public By instCol9= By.xpath("(//*[@class='headerTitle'])[10]/div[1]");
	public By instCol10= By.xpath("(//*[@class='headerTitle'])[11]/div[1]");

	public By clientDescInstrumentDetailPopup= By.xpath("//*[@class='detailBlock']//tr[1]/td[2]");
	public By searchBtnInfoCol= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By closeInstrumentDetailPopup= By.xpath("//*[@eventproxy='isc_Window_1_closeButton']");

	public void clear() {
		Weblocator.Openlinks(elecomm.clearBtnF9);
	}

	public String retrieve(String instrumentNo) throws InterruptedException {
		//CommanClass.Openlinks(elecomm.clearBtnF9);
		//CommanClass.clearText(instNumberTextField);
		//WebDriverManager.explicitWait(2);
		for (int i = 0; i < 6; i++) {
			driver.findElement(instNumberTextField).sendKeys(Keys.BACK_SPACE);
		}
		//WebDriverManager.explicitWait(2);
		Weblocator.TextField(instNumberTextField, instrumentNo);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		String clientname=Weblocator.getPagetext(clientNameFirstRow);
		return clientname;
	}

	public String openInstrumentAndSave(String testing1, String testing2) {
		Weblocator.DoubleClick(clientNameFirstRow);
		Weblocator.explicitWait(2);
		Weblocator.TextField(testingTextFiled1, testing1);
		Weblocator.explicitWait(3);
		Weblocator.TextField(testingTextFiled2, testing2);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(1);
		String enrichno=Weblocator.getPagetext(enrichSetNoGetText);
		return enrichno;
	}








}








