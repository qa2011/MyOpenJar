package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.util.Setup;
import com.util.Weblocator;

public class DownloadSchedulePage extends Setup{

	public static String schno="";

	//public By = By.xpath("");

	public By dropdownBtn= By.xpath("(//*[text()='Regular'])[1]");
	public By bothOption= By.xpath("(//*[text()='Both'])[1]");
	public By productTextField= By.name("product");
	public By productNameFirstRow= By.xpath("(//*[@role='listitem']/td[3]/div[1])[2]");
	public By dispBankFirstRow= By.xpath("(//*[@role='listitem']/td[4]/div[1])[2]");

	public By downloadFileCheckBox= By.xpath("//*[text()='Download File']");
	public By downloadPifCheckBox= By.xpath("//*[text()='Download PIF Detail (.prn) File']");
	public By printPIFcheckBox= By.xpath("//*[text()='Print PIF Summary']");
	public By printPIFDetailscheckBox= By.xpath("//*[text()='Print PIF Details']");

	public By sentMsgVerify= By.xpath("//*[text()='TX8652-Schedule(s)  sent for  processing']");

	public By clearingLocationTextField= By.name("clearingLocation");
	public By activationLocationDropDown= By.xpath("/html/body/div[5]/div/div/div/div[2]/div/div[4]/div/div[2]/div[3]/div[1]/div/div[1]/div/form/table/tbody/tr[3]/td[4]/table/tbody/tr/td[1]/div");
	public By optionNew= By.xpath("//*[text()='NEW']");
	public By scheduleFilterHeader= By.xpath("(//*[text()='Schedule #'])[2]");
	public By scheduleFirstRow= By.xpath("(//*[@role='listitem']/td[3]/div[1])[2]");

	public By detailsBtnFirstRow= By.xpath("(//*[@role='listitem']/td[1]/div[1]/span[1])[2]");
	public By activationDateTextField= By.name("activationDateStr");

	public By makerTextField= By.name("maker");
	public By scheduleTextField= By.name("schedule");
	public By scheduleNoFirstRow= By.xpath("(//*[@role='listitem']/td[1]/div[1])[2]");
	public By authCheckBox= By.xpath("(//*[@role='listitem']/td[7]/div[1]/span[1])[2]");


	public boolean retrieve(String productName) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(dropdownBtn);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(bothOption);
		Weblocator.explicitWait(1);
		Weblocator.TextField(productTextField, productName);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(3);
		status=Weblocator.IselementPresent(productNameFirstRow);
		return status;
	}

	public String download() {
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(productNameFirstRow);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.downloadBtnAllF9);
		Weblocator.explicitWait(2);
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(downloadFileCheckBox);
		Weblocator.Openlinks(downloadPifCheckBox);
		Weblocator.Openlinks(printPIFcheckBox);
		//WebDriverManager.Openlinks(printPIFDetailscheckBox);
		Weblocator.Openlinks(elecomm.okBtn);
		Weblocator.explicitWait(2);
		Weblocator.getWindowHandle();
		//------------------------------------------
/*		//Create a map to store  preferences 
		Map<String, Object> prefs = new HashMap<String, Object>();

		//add key and value to map as follow to switch off browser notification
		//Pass the argument 1 to allow and 2 to block
		prefs.put("profile.default_content_setting_values.notifications", 1);*/
		//------------------------------------------
/*		WebDriverManager.explicitWait(3);
		elecomm.PopupHandle_dataSave();*/
		Weblocator.explicitWait(3);
		//String msg =elecomm.PopupHandle_dataSave(); //msg=   TX1101-No pending schedule for the criteria entered.
		//WebDriverManager.explicitWait(3);
		//WebDriverManager.Reload();
		Weblocator.getWindowHandle();
		String msg="";
		return msg;
	}

	public String msgVerify() {
		Weblocator.Openlinks(dashboard.downloadScheduleMenu);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(dashboard.extractScheduleMenu);
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.extractBtnF2);
		Weblocator.explicitWait(1);
		String msg=Weblocator.getPagetext(sentMsgVerify);
		return msg;
	}

	public boolean retrieve_dispatchBankActivation(String productName) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(productTextField, productName);
		Weblocator.TextField(clearingLocationTextField,"NANDED");
		Weblocator.explicitWait(5);
		Weblocator.Openlinks(activationLocationDropDown);
		Weblocator.explicitWait(5);
		Weblocator.Openlinks(optionNew);
		Weblocator.explicitWait(3);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		status=Weblocator.IselementPresent(scheduleFirstRow);
		return status;
	}

	public String detailsStatus() {
		Weblocator.Openlinks(scheduleFilterHeader);
		Weblocator.explicitWait(1);
		String schNo=Weblocator.getPagetext(scheduleFirstRow);
		Weblocator.Openlinks(detailsBtnFirstRow);
		Weblocator.getWindowHandle();
		for (int i = 0; i < 6; i++) {
			driver.findElement(activationDateTextField).sendKeys(Keys.BACK_SPACE);
		}
		Weblocator.TextFieldWithOutTAB(activationDateTextField, "30112018");
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(2);
		return schNo;
	}

	public boolean retrieve_dispatchBankActivationAuth(String scheduleNo) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(scheduleTextField, scheduleNo);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		status=Weblocator.IselementPresent(scheduleNoFirstRow);
		return status;
	}

	public String QDDDispBankActivationauth() {
		Weblocator.Openlinks(authCheckBox);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(3);
		String msg=Weblocator.getPagetext(elecomm.noItemToShowMsg);
		return msg;
	}




}








