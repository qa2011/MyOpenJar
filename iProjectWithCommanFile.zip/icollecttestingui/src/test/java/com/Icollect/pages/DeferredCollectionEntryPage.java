package com.Icollect.pages;
import java.awt.AWTException;

import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredCollectionEntryPage extends Setup{
	
    //public By = By.xpath("");
	public By enterDateTextFiled= By.name("entryDateStr");
	public By batchNoTextFiled= By.name("batchNo");
	public By activationDateTextFiled= By.name("activationDateStr");
	public By productTextFiled= By.name("productCode");
	public By dispBankTextFiled= By.name("dispBankCode");
	public By dispBranchTextFiled= By.name("dispBranchCode");
	public By depSlipTextFiled= By.name("filterInputDepositNo");
	public By clientTextFiled= By.name("filterClientCode");
	public By depdateTextFiled= By.name("filterDepositDateStr");
	public By retrieveBtn= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Clear (F9)'])[1]/preceding::div[2]");
	public By clearBtn= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Retrieve (F7)'])[1]/following::div[3]");
	public By clearBtnf9= By.xpath("//*[text()='Clear (F9)']");
	public By clientSearchFilterTextFiled= By.xpath("//div/input");
	public By IF2Label= By.xpath("//*[text()='I(+)(F2)']");
	public By infoLabel= By.xpath("//*[text()='Info']");
	public By clientLabel= By.xpath("(//*[text()='Client'])[2]");
	public By arrangementLabel= By.xpath("//*[text()='Arrangement']");
	public By pickupPtLabel= By.xpath("//*[text()='Pickup Pt.']");
	public By depDateLabel= By.xpath("//*[text()='Dep. Dt']");
	public By depLabel= By.xpath("//*[text()='Dep. #']");
	public By totalInstLabel= By.xpath("//*[text()='Total Inst.']");
	public By totalAmountLabel= By.xpath("//*[text()='Total Amnt']");
	
	public By clientNameFirstRowGetText= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='User Info (F10)'])[1]/following::div[31]");
	public By infoBtnFirstRow= By.xpath("//div[2]/div/table/tbody/tr/td[2]/div/span");
	public By clientDescriptionGetText= By.xpath("(//*[@class='detailBlock']//td[2])[1]");
	public By closeInfoPopup= By.xpath("//*[@eventproxy='isc_Window_0_closeButton']");
	
	public By selectFirstRow= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='User Info (F10)'])[1]/following::div[31]");
	public By userInfoBtn= By.xpath("//*[text()='User Info (F10)']");
	public By makeNameGetText= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Maker Name:'])[1]/following::td[1]");
	public By checkerNameGetText= By.xpath("(.//*[normalize-space(text()) and normalize-space(.)='Checker Name:'])[1]/following::td[1]");
	public By closeMakerInfoBtn= By.xpath("//*[@eventproxy='isc_userInfoWindow_0_closeButton']");

	public By instrumentNoTextField= By.name("instrumentNo");
	public By draweeBranchCodeTextField= By.name("draweeBranchCode");  //220028002
	public By instAmountTextField= By.name("instrumentAmount"); //1000
	public By instrumentDateStrTextField= By.name("instrumentDateStr");  //16/11/2018
	public By saveBtn= By.id("isc_DC");
	public By saveBtnf11= By.xpath("//*[text()='Save (F11)']");

	
/*	
	public By = By.xpath("");
	public By = By.xpath("");
	public By = By.xpath("");
	public By = By.xpath("");
	public By = By.xpath("");*/

	public String retrieve(String batchNo) throws AWTException {
		Weblocator.Openlinks(clearBtn);
		Weblocator.TextField(batchNoTextFiled, batchNo);
		Weblocator.Openlinks(retrieveBtn);
		Weblocator.explicitWait(1);
		String client=Weblocator.getPagetext(clientNameFirstRowGetText);
		return client;
		
	}
	
	public String BatchCreation_Auth_ABIL() {
		dashboard.Transaction();
		String batchno=trns.batchCreation();
		return batchno;
	}
	
	
	public void DeferredCollectionEntryPage_SeachBatchNo(String batchNo) {
		//dashboard.DeferredCollectionEntryPage();
		Weblocator.Openlinks(clearBtn);
		Weblocator.TextField(batchNoTextFiled,batchNo);
		Weblocator.Openlinks(retrieveBtn);
		Weblocator.DoubleClick(selectFirstRow);
	}
	
	public String AddInstrument(String instrumentNo) {
		//String instrumentNo="Test"+testdata;
		Weblocator.TextField(instrumentNoTextField,instrumentNo);
		Weblocator.TextField(draweeBranchCodeTextField, "220028002");
		Weblocator.TextField(instAmountTextField, "1000");
		Weblocator.TextFieldWithOutTAB(instrumentDateStrTextField, "16/11/2018");
		Weblocator.Openlinks(saveBtnf11);
		String msg=elecomm.PopupHandle_dataSave();
		//s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
		Weblocator.getWindowHandle();
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(clearBtn);
		//dashboard.logout();
		Weblocator.getWindowHandle();
		return msg;
	}
	
	
	
	
	
	public void AddInstrument_DeferredCollectionEntry_ABIL_After_BatchAuth() {
		//BatchCreation_Auth_ABIL();
		//dashboard.DeferredCollectionEntryPage();

		//CommanClass.Openlinks(clearBtn);
		//CommanClass.TextField(batchNoTextFiled, BatchCreation_Auth_ABIL());
/*		try {
			TimeUnit.SECONDS.sleep(2);
		}catch (Exception e) {
			System.out.println("sleep error");
		}
		CommanClass.Openlinks(retrieveBtn);
		try {
			TimeUnit.SECONDS.sleep(2);
		}catch (Exception e) {
			System.out.println("sleep error");
		}
		CommanClass.DoubleClick(selectFirstRow);
		try {
			TimeUnit.SECONDS.sleep(2);
		}catch (Exception e) {
			System.out.println("sleep error");
		}
		*/
		/*String instrumentNo="Test"+testdata;
		CommanClass.TextField(instrumentNoTextField,instrumentNo );
		CommanClass.TextField(draweeBranchCodeTextField, "220028002");
		CommanClass.TextField(instAmountTextField, "1000");
		CommanClass.TextFieldWithOutTAB(instrumentDateStrTextField, "16/11/2018");
		CommanClass.Openlinks(saveBtnf11);
		s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
		CommanClass.getWindowHandle();
		CommanClass.scrollingByCoordinatesofAPage_scrollUp();*/
	/*	try {
			TimeUnit.SECONDS.sleep(3);
		}catch (Exception e) {
			System.out.println("sleep error");
		}*/
		/*CommanClass.getWindowHandle();
		CommanClass.Openlinks(clearBtn);*/
		/*dashboard.logout();
		CommanClass.getWindowHandle();*/
		
	}
	
	

}
    
    
    
    
    
    
    
    
