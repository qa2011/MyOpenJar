package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredEnrichmentEntryAuthPage extends Setup{

	//public By = By.xpath("");
	public By makerTextField= By.name("makerCode");
	public By instNumberFirstRowInstrumentTab= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By authCheckBox= By.xpath("//*[text()='Auth (F2)']");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem'])[2]/td[11]/div[1]/span[1]");
	public By instColor= By.xpath("(//*[@role='listitem']//*[@class='rejectedCellSelected'])[2]");
	public By enrichSetGet= By.xpath("(//*[@role='listitem'])[4]/td[2]/div[1]");
	

	public void clear() {
		Weblocator.Openlinks(elecomm.clearBtnF1);
	}

	public String retrieveandSearchInst(String makerName) 
	{
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.TextField(makerTextField, makerName);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		String instno=Weblocator.getPagetext(instNumberFirstRowInstrumentTab);
		return instno;
	}

	public Boolean reject(String rejectionMsg) {
		Boolean color=false;
		Weblocator.Openlinks(rejectCheckBox);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, rejectionMsg);
		Weblocator.Openlinks(elecomm.okBtn);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		color=Weblocator.IselementPresent(instColor);
		if (color) {
			color=true;
		}
		return color;
	}

	public String auth() {
		//WebDriverManager.TextField(fil, entertext)
		Weblocator.Openlinks(authCheckBox);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(3);
		String msg=elecomm.PopupHandle_dataSave();
		return msg;
	}




}








