package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredRemarksEntryAuthPage extends Setup{

	//public By = By.xpath("");
	public By clientTextField= By.name("clientCodeFilter");
	public By makerTextField= By.name("makerCode");
	public By dateTextField= By.name("batchDateFilter");

	public By clientFirstCol= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By searchBtnFirstCol= By.xpath("(//*[@role='listitem'])[2]/td[1]/div[1]");
	public By authCheckBox= By.xpath("//*[text()='Auth (F2)']");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem'])[2]/td[11]/div[1]/span[1]");

	public By noItemShowTextMsg=By.xpath("(//*[text()='No items to show.'])[2]");

	public By remarksFilter= By.xpath("(//*[@role='listitem'])[1]/td[9]//input");
	
	public By depositFilter= By.xpath("//*[contains(@name,'inputDepNmbr') and @type='TEXT']");


/*	public String retrieve(String clientname, String makername, String date, String remarks) throws InterruptedException {
		//CommanClass.Openlinks(elecomm.clearBtnF1);
		TimeUnit.SECONDS.sleep(2);
		//CommanClass.clearText(instNumberTextField);
		for (int i = 0; i < 6; i++) {
			driver.findElement(clientTextField).sendKeys(Keys.BACK_SPACE);
		}
		TimeUnit.SECONDS.sleep(2);
		CommanClass.TextField(clientTextField, clientname);
		CommanClass.TextField(makerTextField, makername);
		for (int i = 0; i < 8; i++) {
			driver.findElement(dateTextField).sendKeys(Keys.BACK_SPACE);
		}
		CommanClass.TextFieldWithOutTAB(dateTextField, date);
		CommanClass.Openlinks(elecomm.retrieveBtnF7);

		CommanClass.TextField(remarksFilter, remarks);
		CommanClass.PressEnterBtn(remarksFilter);

		String clientName=CommanClass.getPagetext(clientFirstCol);
		return clientName;
	}*/
	
	public Boolean retrieve(String makername) throws InterruptedException {
		Weblocator.TextField(makerTextField, makername);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Boolean clientName=Weblocator.IselementPresent(clientFirstCol);
		return clientName;
	}

	public String reject(String rejectionMsg) {
		Weblocator.Openlinks(rejectCheckBox);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, rejectionMsg);
		Weblocator.Openlinks(elecomm.okBtnReject);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.Openlinks(elecomm.userinfoBtnF10);
		Weblocator.getWindowHandle();
		String rejectcheck=Weblocator.getPagetext(elecomm.checkerActionGetText);
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.userInfoClose);
		return rejectcheck;
	}

	public String auth() throws InterruptedException {
		Weblocator.Openlinks(authCheckBox);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		//WebDriverManager.explicitWait(2);
		String msg=Weblocator.getPagetext(noItemShowTextMsg);
		return msg;
	}





}








