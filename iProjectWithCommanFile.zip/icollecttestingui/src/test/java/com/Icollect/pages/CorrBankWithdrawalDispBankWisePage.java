package com.Icollect.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.util.Setup;
import com.util.Weblocator;

public class CorrBankWithdrawalDispBankWisePage extends Setup{

	//public By = By.xpath("");
	public By paymentDtTextField= By.name("paymentDt");
	public By dispatchBankCodeTextField= By.name("dispatchBankCode");
	public By productCodeTextField= By.name("searchProductCode");
	public By scheduleNoTextField= By.name("scheduleNo");
	public By clearingLocTextField= By.name("clearingLoc");
	public By productCodeFilter= By.name("productCode");
	public By searchSchduleBtnF4= By.xpath("//*[text()='SEARCH SCH. (F4)']");

	public By productFirstRow= By.xpath("//*[@role='listitem' ]/td[2]/div[1]");
	public By schduleNoAfterFilter= By.xpath("//*[@role='listitem' and @aria-selected='true']/td[3]/div[1]");
	public By collectionAmountAfterFilter= By.xpath("//*[@role='listitem' and @aria-selected='true']/td[5]/div[1]");
	public By checkBoxAfterFilter= By.xpath("//*[@role='listitem' and @aria-selected='true']/td[1]/div[1]/span[1]");

	public By payOrderAmntTextField= By.name("payOrderAmnt");
	public By collectionAmntTextField= By.name("totalCollectionAmnt");
	public By schduleNoFirstRowAfterSave= By.xpath("//*[@role='listitem' ]/td[3]/div[1]");
	public By referenceNoTextFiled= By.name("referenceNo");


	public boolean retrieve(String paymentDate, String dispbank, String product) {
		boolean status=false;
		Weblocator.Openlinks(elecomm.clearBtnF1Capital);
		for (int i = 0; i < 6; i++) {
			driver.findElement(paymentDtTextField).sendKeys(Keys.BACK_SPACE);
		}
		Weblocator.TextFieldWithOutTAB(paymentDtTextField,paymentDate);
		Weblocator.TextField(dispatchBankCodeTextField, dispbank);
		Weblocator.TextField(productCodeTextField, product);
		Weblocator.Openlinks(elecomm.retrieveBtnF7Capital);
		status=Weblocator.IselementPresent(productFirstRow);
		return status;
	}

	public String searchSchduleNo(String schduleno) {
		Weblocator.TextField(scheduleNoTextField, schduleno);
		//WebDriverManager.TextField(clearingLocTextField, clearingLoc);
		//WebDriverManager.TextField(productCodeFilter, product);
		Weblocator.Openlinks(searchSchduleBtnF4);
		Weblocator.explicitWait(2);
		String collamount=Weblocator.getPagetext(collectionAmountAfterFilter);
		return collamount;
	}

	public void restCollAmount_PayOrderAmount(String collAmount) {
		Weblocator.TextField_Clean(payOrderAmntTextField);
		Weblocator.TextField(payOrderAmntTextField, collAmount);
		Weblocator.TextField_Clean(collectionAmntTextField);
		Weblocator.explicitWait(1);
		Weblocator.TextField_Clean(collectionAmntTextField);
		Weblocator.TextField(collectionAmntTextField, collAmount);
	}

	public String saveAfterCollAmountChange(String collAmount, String refrence) {
		restCollAmount_PayOrderAmount(collAmount);
		Weblocator.Openlinks(checkBoxAfterFilter);
		Weblocator.Openlinks(elecomm.saveBtnF11Capital);
		Weblocator.explicitWait(3);
		String schno=Weblocator.getPagetext(schduleNoFirstRowAfterSave);
		Weblocator.TextField(referenceNoTextFiled, refrence);
		Weblocator.Openlinks(elecomm.saveBtnF11Capital);
		Weblocator.explicitWait(3);
		return schno;
	}



}








