package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class DeferredRemarksEntryPage extends Setup{
	
    //public By = By.xpath("");
	public By enteryDateTextField= By.name("entryDateStr");
	public By depositTextField= By.name("inputDepNmbrFilter");
	
	public By clientNameDepositDetailsPopup= By.xpath("(//*[@class='detailBlock']//*[@class='detail'])[1]");
	public By arrangementNameDepositDetailsPopup= By.xpath("(//*[@class='detailBlock']//*[@class='detail'])[2]");
	public By pickupLocationDepositDetailsPopup= By.xpath("(//*[@class='detailBlock']//*[@class='detail'])[3]");
	public By pickupPointDepositDetailsPopup= By.xpath("(//*[@class='detailBlock']//*[@class='detail'])[4]");
	public By closeDepositDetailsPopup= By.xpath("//*[@class='windowHeader']/div[4]");
	
	public By remarksTextField= By.name("depositRemarks");
	public By clientNameFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[3]/div[1]");
	public By clientNamefilter= By.xpath("(//*[@class='listGrid']//*[@role='listitem'])[1]/td[3]//input");
	public By dateFirstRow= By.xpath("(//*[@role='listitem'])[2]/td[6]/div[1]");
	public By searchBtnInfoCol= By.xpath("(//*[@role='listitem'])[2]/td[2]/div[1]");
	public By modifyBtnFirstCol= By.xpath("(//*[@role='listitem'])[2]/td[11]/div[1]");
	public By remarksGetText= By.xpath("(//*[@role='listitem'])[2]/td[10]/div[1]");
	
	public By remarksCol1= By.xpath("(//*[@class='headerTitle'])[2]/div[1]");
	public By remarksCol2= By.xpath("(//*[@class='headerTitle'])[3]/div[1]");
	public By remarksCol3= By.xpath("(//*[@class='headerTitle'])[4]/div[1]");
	public By remarksCol4= By.xpath("(//*[@class='headerTitle'])[5]/div[1]");
	public By remarksCol5= By.xpath("(//*[@class='headerTitle'])[6]/div[1]");
	public By remarksCol6= By.xpath("(//*[@class='headerTitle'])[7]/div[1]");
	public By remarksCol7= By.xpath("(//*[@class='headerTitle'])[8]/div[1]");
	public By remarksCol8 = By.xpath("(//*[@class='headerTitle'])[9]/div[1]");
	public By remarksCol9= By.xpath("(//*[@class='headerTitle'])[10]/div[1]");
	public By remarksCol10= By.xpath("(//*[@class='headerTitle'])[11]/div[1]");
	public By remarksCol11= By.xpath("(//*[@class='headerTitle'])[12]/div[1]");
	
	public By searchBtnFirstColInstrumentTab= By.xpath("(//*[@role='listitem'])[26]/td[2]/div[1]");
	public By draweeBankBranchNameInstDetailsPopup= By.xpath("(//*[@class='detailBlock'])[2]//tr[1]/td[2]");
	public By clearingLocationInstDetailsPopup= By.xpath("(//*[@class='detailBlock'])[2]//tr[2]/td[2]");
	public By drawerInstDetailsPopup= By.xpath("(//*[@class='detailBlock'])[2]//tr[3]/td[2]");
	public By closeInstrumentDetailPopup= By.xpath("//*[@name='isc_LHmain']");
	public By instNoFirstColInstrumentTab= By.xpath("(//*[@role='listitem'])[26]/td[2]/div[1]");
	public By modifyColInstrumentTab= By.xpath("(//*[@role='listitem'])[26]/td[10]/div[1]");

   
	public String retrieve() {
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		String clientName=Weblocator.getPagetext(clientNameFirstRow);
		return clientName;
	}
	
	public String DepositDetails() {
		Weblocator.Openlinks(searchBtnInfoCol);
		Weblocator.getWindowHandle();
		String clientname=Weblocator.getPagetext(clientNameDepositDetailsPopup);
		Weblocator.getPagetext(arrangementNameDepositDetailsPopup);
		Weblocator.getPagetext(pickupLocationDepositDetailsPopup);
		Weblocator.getPagetext(pickupPointDepositDetailsPopup);
		Weblocator.Openlinks(closeDepositDetailsPopup);
		return clientname;
	}
	
	
	public String modify(String enterRemarks) {
		Weblocator.Openlinks(modifyBtnFirstCol);
		Weblocator.clearText(remarksTextField);
		Weblocator.TextField(remarksTextField, enterRemarks);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		return enterRemarks;
	}
	
	

	
    
 

}
    
    
    
    
    
    
    
    
