package com.Icollect.pages;
import org.openqa.selenium.By;

import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiqStatReversalAuthPage extends Setup{
	
    //public By = By.xpath("");
	public By makerNameTextField= By.name("inputMakerCode");
	public By productCodeTextField= By.name("formProductCode");
	public By productCodeFirstCol= By.xpath("(//*[@role='listitem']/td[2]/div[1])[2]");
	public By scheduleFilter= By.xpath("(//*[@role='listitem']/td[5]//input[1])[1]");
	public By productFilter= By.xpath("(//*[@role='listitem']/td[2]//input[1])[1]");
	public By disBankFilter= By.xpath("(//*[@role='listitem']/td[3]//input[1])[1]");
	public By disBranchFilter= By.xpath("(//*[@role='listitem']/td[4]//input[1])[1]");
	
	public By authCheckBox= By.xpath("(//*[@role='listitem']/td[12]/div[1]/span[1])[1]");
	public By rejectCheckBox= By.xpath("(//*[@role='listitem']/td[13]/div[1]/span[1])[1]");
	public By codeTextField= By.name("code");
	public By productHeader= By.xpath("(//*[@class='windowHeaderText' and text()='Product'])[1]");
	
	public boolean retrieve() 
	{
		Boolean status =false;
		Weblocator.Openlinks(elecomm.clearBtnF1);
		//WebDriverManager.TextField(makerNameTextField, makerName);
		//WebDriverManager.TextField(productCodeTextField, productCode);
		Weblocator.Openlinks(elecomm.retrieveBtnF7);
		Weblocator.explicitWait(2);
		status=Weblocator.IselementPresent(productCodeFirstCol);
		return status;
	}
	
	public boolean reject(String scheduleNo,String rejectMSG) {
		Boolean status =false;
		Weblocator.TextField(scheduleFilter, scheduleNo);
		Weblocator.PressEnterBtn(scheduleFilter);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(rejectCheckBox);
		Weblocator.explicitWait(1);
		Weblocator.getWindowHandle();
		Weblocator.TextField(elecomm.remarkTextField, rejectMSG);
		Weblocator.Openlinks(elecomm.okBtn3);
		Weblocator.getWindowHandle();
		status=Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(3);
		return status;
	}
	
	
	public String auth(String scheduleNo) {
		Weblocator.explicitWait(2);
		Weblocator.TextField(scheduleFilter, scheduleNo);
		Weblocator.PressEnterBtn(scheduleFilter);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(authCheckBox);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.saveBtnF11);
		Weblocator.explicitWait(2);
		//elecomm.PopupHandle_dataSave();
		Weblocator.TextField(scheduleFilter, scheduleNo);
		Weblocator.PressEnterBtn(scheduleFilter);
		Weblocator.explicitWait(2);
		String msg=Weblocator.getPagetext(elecomm.noItemToShowMsg);
		return msg;
	}
	
	
	
	
	

}
    
    
    
    
    
    
    
    
