package com.Icollect.pagesTest_O_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentReceiptAuthPage;
import com.util.Log;
import com.util.Weblocator;

public class InstrumentReceiptPageWithAuthTest_O_Type extends InstrumentReceiptAuthPage{

	SoftAssert s_assert;
	public String refNo=null;

	@Test(priority=0)
	public void verify_EndToEndInst_Receipt() {
		Log.startTestCase("Instrument Receipt Auth - Verify end to end functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String schdulenoo=instReceipt.retrieve("UCC-D", schduleno);
			s_assert.assertNotNull(schdulenoo, "Schdule not is not Null");
			refNo="RefNo"+Weblocator.randomeNum();
			String noItemMsg=instReceipt.recivedVerify(refNo);
			s_assert.assertEquals(noItemMsg, "No items to show.","Msg Not Match");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			Weblocator.explicitWait(1);
			dashboard.InstrumentReceiptAuth();
			Weblocator.explicitWait(1);
			instReceiptAuth.retrieve("UCC-D", "ANURAGSI");
			String status=instReceiptAuth.reject(refNo);
			s_assert.assertEquals(status, "Rejected");

			instReceiptAuth.retrieve("UCC-D", "ANURAGSI");
			instReceiptAuth.auth(refNo);
			
			Weblocator.Openlinks(dashboard.instrumentReceiptAuthSubMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	


}