package com.Icollect.pagesTest_O_Type;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.scheduleLiquidationAuthPage;
import com.util.Log;
import com.util.Weblocator;

public class ScheduleLiquidationPageWithAuthTest_O_Type extends scheduleLiquidationAuthPage{
	SoftAssert s_assert;
	boolean schdulePaidStatus;
	
	@Test(priority=0)
	public void Verify_Maker_Checker_Info() {
		Log.startTestCase("Verify_Maker_Checker_Info");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			
			Boolean status1=schLiq.retrieve("UCC-D", "UTID", "");
			s_assert.assertTrue(status1, "No Records founds");
			if (status1) {
				String schLiqNo=schLiq.searchFilter(schduleno);
				if (!schLiqNo.equals("No Items Founds")) {
					String msg=schLiq.paid(ReceiptAuth_ForSchLiq);
					//s_assert.assertEquals(msg, "No items to show.", "No items MSG not present");
				}
				s_assert.assertNotEquals(schLiqNo, "No items Founds","No items msg is present");
			}
			
			dashboard.logout();
			login.login(checkerName);
			dashboard.scheduleLiquidationAuth();
			Boolean status=schLiqAuth.retrieve("anuragsi");
			if (status) {
				Boolean authcheckbox=Weblocator.Openlinks(authCheckBoxAll);
				if (authcheckbox) {
					String check=schLiqAuth.auth();
					if (StringUtils.isNotBlank(check)) {
						schdulePaidStatus=true;
					}
					s_assert.assertEquals(check, "No items to show.");
				}
				s_assert.assertTrue(authcheckbox, "Auth Check box is not present");
			}
			s_assert.assertTrue(status, "No data found");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.scheduleLiquidationAuthSubMenu);
		}catch (Exception e) {
		
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}	
	

	
}