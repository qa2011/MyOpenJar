package com.Icollect.pagesTest_O_Type;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.util.Log;
import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiquidationPagewithAuthTest_O_Type extends Setup
{

	SoftAssert s_assert;
	String clientnameonGrid="";
	String instLiq_RefNo="";

	//@Test(priority=0)
	public void verify_LiType_Options() {
		Log.startTestCase("verify_LiType_Options");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("UCC-D", schduleno);
			//instLiq_RefNo="InstLiqRef"+WebDriverManager.randomeNum();
			if (status.equalsIgnoreCase("New")) {
				Weblocator.Openlinks(instLiq.GetGridDetailsFirstRow);
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(instLiq.liqTypeDropListBtnComm);
				Weblocator.explicitWait(2);
				s_assert.assertEquals(Weblocator.Getactualtext(instLiq.paidOption), "Paid");
				s_assert.assertEquals(Weblocator.Getactualtext(instLiq.technicalOption), "Technical");
				s_assert.assertEquals(Weblocator.Getactualtext(instLiq.lostOption), "Lost");
				//instLiq.addInst_OType("Technical_O_type", "500");
				
				Actions action = new Actions(driver);
				action.sendKeys(Keys.ESCAPE).build().perform();
				
				Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
			}

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority=1)
	public void verify_Instrument_Liquidation_with_Auth() {
		Log.startTestCase("Instrument Liquidation with Auth");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("UCC-D", schduleno);
			instLiq_RefNo="InstLiqRef"+Weblocator.randomeNum();
			if (status.equalsIgnoreCase("New")) {
			
				Weblocator.TextField(instLiq.refrenceNo, instLiq_RefNo);
				
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(instLiq.GetGridDetailsFirstRow);
				Weblocator.Openlinks(instLiq.GetGridDetailsFirstRow); // 1 inst
				Weblocator.explicitWait(1);
				String insttNo1=instLiq.addInst_OType("Return_O_type", "Technical Return", "");
				
				Weblocator.Openlinks(instLiq.GetGridDetails2Row); //2 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo2=instLiq.addInst_OType("Return_O_type", "Funds insufficient","");
				
				
				Weblocator.Openlinks(instLiq.GetGridDetails3Row); //3 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo3=instLiq.addInst_OType("Technical_O_type", "","");
				
				Weblocator.Openlinks(instLiq.GetGridDetails4Row); //4 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo4=instLiq.addInst_OType("Technical_O_type", "","");
				
				
				Weblocator.Openlinks(instLiq.GetGridDetails5Row); //5 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo5=instLiq.addInst_OType("Lost_O_type", "","");
				
				Weblocator.Openlinks(instLiq.GetGridDetails6Row); //6 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo6=instLiq.addInst_OType("Paid_O_type", "","");
				
				Weblocator.Openlinks(instLiq.GetGridDetails7Row); //7 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				String insttNo7=instLiq.addInst_OType("Paid_O_type", "","");
				
				Weblocator.Openlinks(instLiq.GetGridDetails8Row); //8 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				Weblocator.explicitWait(2);
				String insttNo8=instLiq.addInst_OType("Paid_O_type", "","");
				
				Weblocator.Openlinks(instLiq.GetGridDetails8Row); //8 inst
				Weblocator.explicitWait(1);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtn2);
				Weblocator.getWindowHandle();
				Weblocator.explicitWait(2);
				String insttNo9=instLiq.addInst_OType("Paid_O_type", "","");
				
				Weblocator.Openlinks(elecomm.saveBtnF11Capital);
				Weblocator.explicitWait(3);
				
				String a=Weblocator.GetAttributevalue(instLiq.balPaidGet);
				
				String balpaid=a.replace( '-', ',' );
				for (int i = 0; i < 6; i++) {
					driver.findElement(instLiq.collectionAmountTextField).sendKeys(Keys.BACK_SPACE);
				}
				Weblocator.explicitWait(2);
				Weblocator.TextField(instLiq.collectionAmountTextField, balpaid);
				Weblocator.explicitWait(2);
				
				String a1=Weblocator.GetAttributevalue(instLiq.balReturnGet);
				String balReturn=a1.replace( '-', ',' );
				for (int i = 0; i < 6; i++) {
					driver.findElement(instLiq.returnAmountTextField).sendKeys(Keys.BACK_SPACE);
				}
				Weblocator.explicitWait(2);
				Weblocator.TextField(instLiq.returnAmountTextField, balReturn);
				Weblocator.explicitWait(2);
				
				Weblocator.Openlinks(elecomm.saveBtnF11Capital);
				Weblocator.explicitWait(3);
				//------------updated------------------
			}
			instLiq.clearData();// wait 7
			Weblocator.explicitWait(4);
			//WebDriverManager.Openlinks(dashboard.instrumentLiquidationMenu);
			//WebDriverManager.explicitWait(2);
			dashboard.logout(); // ===============================================
			Weblocator.explicitWait(2);
			login.login("rachitranjans@hcl.com");
			Weblocator.explicitWait(1);
			dashboard.InstrumentLiquidationAuth();
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.explicitWait(1);
			String msg=instLiqAuth.retrive(instLiq_RefNo);
			
			Weblocator.explicitWait(3);
	/*		WebDriverManager.TextField(instLiqAuth.productTextField, "UCC-D");
			WebDriverManager.TextField(instLiqAuth.makerTextField, "ANURAGSI");
			WebDriverManager.Openlinks(elecomm.retrieveBtnF7);
			WebDriverManager.explicitWait(2);*/
			
			instLiqAuth.auth();
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(dashboard.instrumentLiquidationAuthSubMenu);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


}