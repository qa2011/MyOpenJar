package com.Icollect.pagesTest_O_Type;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.util.Log;
import com.util.ReadConfig;
import com.util.Setup;
import com.util.Weblocator;

public class DispatchAllocationAndAuthPageTest_O_Type extends Setup{

	SoftAssert a_Assert;
	String Product_dispAllo=""; 
	String clearingLoc_dispAllo="";

	@BeforeTest
	public void readConfig() {
		ReadConfig readconfig=new ReadConfig();
		Product_dispAllo=readconfig.pro.getProperty("Product_dispAllo"); 
		clearingLoc_dispAllo=readconfig.pro.getProperty("clearingLoc_dispAllo"); 
	}

	@Test(priority=0)
	public void DispatchAllocationWithAuth() {
		Log.startTestCase("Dispatch Allocation with Auth Test");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean retrievestatus=dispAllocation.retrieve(Product_dispAllo,clearingLoc_dispAllo);
			if (retrievestatus) {
				boolean status=dispAllocation.modify();
				Weblocator.Openlinks(dashboard.dispatchAllocationMenu);
				dashboard.logout();
				if (status) {
				login.login(checkerName);
				dashboard.DispatchAllocationAuth();
				boolean searchbtn=dispAllocationAuth.retrieveBtn(Product_dispAllo, clearingLoc_dispAllo);
				if (searchbtn) {
					String noItem=dispAllocationAuth.auth();
					a_Assert.assertEquals(noItem, "No items to show.");
				}
				a_Assert.assertTrue(searchbtn, "retrive btn working");
			}
			a_Assert.assertTrue(status, "Modify not working");
		}	
		a_Assert.assertTrue(retrievestatus, "No data found after retrieve");


	} catch (Exception e) {
		e.printStackTrace();
		exception = true;
		a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
	}
	a_Assert.assertAll();

}








}