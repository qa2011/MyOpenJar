package com.Icollect.pagesTest_O_Type;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DownloadSchedulePage;
import com.util.Log;
import com.util.ReadConfig;
import com.util.Setup;
import com.util.Weblocator;

import jxl.write.Label;
import jxl.write.WriteException;

public class CorrBankWithdrawalDispBankWiseAndAuthTest_O_Type extends Setup{

	SoftAssert a_Assert;
	String Product=""; 
	
	@BeforeTest
	public void readConfig() {
		ReadConfig readconfig=new ReadConfig();
		Product=readconfig.pro.getProperty("Product"); 
	}

	@Test(priority=0)
	public void Verify_Corr_Bank_With_drawal_Disp_Bank_Wise_And_Auth_Test() {
		Log.startTestCase("Corr. Bank With drawal Disp Bank Wise And Auth Test");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			DownloadScheduleTest_O_Type test=new DownloadScheduleTest_O_Type();
			String schdlenoGetFromDownloadSchedule=	DownloadSchedulePage.schno;
			boolean product=corrbankwithbank.retrieve("22112019", "UTID", "UCC-D"); // note Nedd to change UTID from config
			if (product) {
				String collamount=corrbankwithbank.searchSchduleNo(schdlenoGetFromDownloadSchedule);
				if (StringUtils.isNotBlank(collamount)) {
					String Refno="Ref"+Weblocator.randomeNum();
					String schdulenoget=corrbankwithbank.saveAfterCollAmountChange(collamount, Refno);
					if (StringUtils.isNotBlank(schdulenoget)) {
						dashboard.logout();
						login.login(checkerName);
						dashboard.CorrBankWithdrawalDispBankWiseAuth();
						boolean refno=corrbankwithbankAuth.retrieve("ANURAGSI", Refno);
						if (refno) {
							//corrbankwithbankAuth.reject();
							//a_Assert.assertNotEquals(rejectmsg, "Rejected");
							Weblocator.explicitWait(3);
							String noItemmsg=corrbankwithbankAuth.auth();
							a_Assert.assertEquals(noItemmsg, "No items to show.");
						}
						a_Assert.assertTrue(refno, "Retrieve button is not working");
					}
					a_Assert.assertNotNull(schdulenoget, "save button is not working after change collAmount");
				}
				a_Assert.assertNotNull(collamount, "search schdule filter not working");
			}
			a_Assert.assertTrue(product, "retreive not working");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	
	@AfterTest
	public void closeExl() throws WriteException, IOException  {
		try {
			Weblocator.WriteExcel();
			Label schno = new Label(9, row, DownloadSchedulePage.schno);
			Weblocator.excelSheet.addCell(schno);

			Weblocator.myFirstWbook.write();
		} catch (Exception e) {
			Weblocator.printExceptionTrace(e);
		}
		Weblocator.myFirstWbook.close();
	}

}