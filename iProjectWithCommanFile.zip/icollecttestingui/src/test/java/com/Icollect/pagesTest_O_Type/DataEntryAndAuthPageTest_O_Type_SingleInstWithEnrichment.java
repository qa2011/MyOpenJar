package com.Icollect.pagesTest_O_Type;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.TransactionsPage;
import com.util.Log;
import com.util.ReadConfig;
import com.util.Weblocator;

public class DataEntryAndAuthPageTest_O_Type_SingleInstWithEnrichment extends TransactionsPage{

	SoftAssert a_Assert;
	String pickUploc=""; 
	String Product="";
	String Client=""; 
	String totaldep=""; 
	String Totalamount="";
	
	@BeforeTest
	public void readConfig() {
		ReadConfig readconfig=new ReadConfig();
		
		pickUploc=readconfig.pro.getProperty("pickUploc"); 
		Product=readconfig.pro.getProperty("Product"); 
		Client=readconfig.pro.getProperty("Client"); 
		totaldep=readconfig.pro.getProperty("totaldep"); 
		Totalamount=readconfig.pro.getProperty("Totalamount"); 
	}

	@Test(priority=0)
	public void EndToEndBatchcreationAndAuth() {
		Log.startTestCase("EndToEndBatchcreationAndAuth:");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//trns.batchCreation_O_Type("DEL", "UCC-ADHOC", "ITGIHIB", "1", "1000");
			boolean pickuplocc=Weblocator.TextField(PickupLocationTextField, this.pickUploc);
			if (pickuplocc) {
				boolean product=Weblocator.TextField(ProductTextField, this.Product);
				if (product) {
					Weblocator.explicitWait(1);
					//elecomm.GeneralFetchingDataPopup();
					Weblocator.getWindowHandle();
					boolean totaldepcheck=Weblocator.TextField(TotalDepTextField, this.totaldep);
					if (totaldepcheck) {
						boolean totalAmount=Weblocator.TextField(TotalAmntField, "1000");
						if (totalAmount) {
							String TheirReferenceValue="OTRe"+Weblocator.randomeNum();  //---------to be use in feature
							boolean thersRefText=Weblocator.TextField(TheirReferenceTextField,TheirReferenceValue);
							if (thersRefText) {
								boolean savebtn=Weblocator.Openlinks(saveBtn);
								if (savebtn) {
									Weblocator.explicitWait(1);
									//elecomm.GeneralFetchingDataPopup();
									Weblocator.getWindowHandle();
									String batchno=Weblocator.GetAttributevalue(batchTextField);
									if (StringUtils.isNotBlank(batchno)) {
										System.out.println("Batch No : "+ batchno);
										boolean client=Weblocator.TextField(clientTextField, this.Client);
										if (client) {
											elecomm.PopupHandle_dataSave();
											boolean totalinst=Weblocator.TextField(totalInstTextfield, "1");
											if (totalinst) {
												boolean tatalAmount=Weblocator.TextField(totalAmountTextfield, this.Totalamount);
												if (tatalAmount) {
													depositer="Odep"+Weblocator.randomestring();
													boolean inputdepono=Weblocator.TextField(inputDepositNoTextField, depositer);
													if (inputdepono) {
														boolean saveBtn=Weblocator.Openlinks(saveBtn_DepositTAB);
														if (saveBtn) {
															elecomm.PopupHandle_dataSave();
															boolean instNo=Weblocator.TextField(instrumentNoTextField, "Oinst"+Weblocator.randomeNum());
															if (instNo) {
																boolean branch=Weblocator.TextField(draweeBranchCodeTextFiled, "APG,PRAGNA");
																if (branch) {
																	boolean instAmount=Weblocator.TextField(instrumentAmountTextFiled, "1000");
																	if (instAmount) {
																		Weblocator.explicitWait(3);
																		boolean date=Weblocator.TextFieldWithOutTAB(instrumentDateStrTextFiled, "16112018");
																		if (date) {
																			driver.findElement(instrumentDateStrTextFiled).sendKeys(Keys.TAB);
																			//---------------------
																			boolean saveinst=Weblocator.Openlinks(saveBtn_instrumentTAB);
																			if (saveinst) {
																				elecomm.PopupHandle_dataSave();
																				Weblocator.getWindowHandle();
																				Weblocator.explicitWait(2);

																				//----------------add enrichment---------
																				boolean enrichBtn=Weblocator.Openlinks(elecomm.enrichBtnF2);
																				if (enrichBtn) {
																					String polictNo="Pol"+Weblocator.randomeNum();
																					boolean policyNo=Weblocator.TextField(policyNoTextField, polictNo);
																					if (policyNo) {
																						boolean savebtnEnrich=Weblocator.Openlinks(savebtnEnrichMentTAB);
																						if (savebtnEnrich) {
																							Weblocator.explicitWait(3);
																							Weblocator.scrollingByCoordinatesofAPage_scrollUp();

																							boolean logoutbtn=dashboard.logout();
																							if (logoutbtn) {
																								boolean loginbt=login.login("rachitranjans@hcl.com");
																								if (loginbt) {
																									boolean tranAuth=dashboard.TransactionAuth();
																									if (tranAuth) {

																										boolean batchFrom=Weblocator.TextField(batchFromTextField, batchno);
																										if (batchFrom) {
																											boolean batchTo=Weblocator.TextField(batchToTextField, batchno);
																											if (batchTo) {
																												boolean retrivebtn=Weblocator.Openlinks(retrieveBtn);
																												if (retrivebtn) {
																													boolean authCheckAbil=Weblocator.Openlinks(authCheckBoxforABIL);
																													if (authCheckAbil) {
																														Weblocator.scrollingByCoordinatesofAPage_scrollUp();
																														boolean savebttn=Weblocator.Openlinks(trns.saveBtn);
																														if (savebttn) {
																															Weblocator.getWindowHandle();
																															Weblocator.Openlinks(elecomm.yesBtn2);
																															Weblocator.getWindowHandle();
																															elecomm.PopupHandle_dataSave();
																															//dashboard.logout();
																															thereRefNoAfterAuth=TheirReferenceValue;
																														}
																														a_Assert.assertTrue(savebttn, "saveBtn is not present");
																													}
																													a_Assert.assertTrue(authCheckAbil, "authCheckBoxforABIL is not present");
																												}
																												a_Assert.assertTrue(retrivebtn, "retrieveBtn is not present");
																											}
																											a_Assert.assertTrue(batchTo, "batchToTextField is not present");
																										}
																										a_Assert.assertTrue(batchFrom, "batchFromTextField is not present");																																																											
																									}
																									a_Assert.assertTrue(tranAuth, "TransactionAuth is not present");
																								}
																								a_Assert.assertTrue(loginbt, "Login btn is not present");
																							}
																							a_Assert.assertTrue(logoutbtn, "logout is not present");
																						}
																						a_Assert.assertTrue(savebtnEnrich, "savebtnEnrichMentTAB is not present");
																					}
																					a_Assert.assertTrue(policyNo, "policyNoTextField is not present");
																				}
																				a_Assert.assertTrue(enrichBtn, "enrichBtnF2 is not present");
																			}
																			a_Assert.assertTrue(saveinst, "saveBtn_instrumentTAB is not present");
																		}
																		a_Assert.assertTrue(date, "instrumentDateStrTextFiled is not present");
																	}
																	a_Assert.assertTrue(instAmount, "instrumentAmountTextFiled is not present");
																}
																a_Assert.assertTrue(branch, "draweeBranchCodeTextFiled is not present");
															}
															a_Assert.assertTrue(instNo, "instrumentNoTextField is not present");
														}
														a_Assert.assertTrue(saveBtn, "Save Button is not present");
													}
													a_Assert.assertTrue(inputdepono, "Input Deposit No is not present");
												}
												a_Assert.assertTrue(tatalAmount, "Total Amount is not present");
											}
											a_Assert.assertTrue(totalinst, "Total Inst is not present");
										}
										a_Assert.assertTrue(client, "Client is not present");}
								}
								a_Assert.assertTrue(savebtn, "Save Button is not present");
							}
							a_Assert.assertTrue(thersRefText, "TheirReference Text Field is not present");
						}
						a_Assert.assertTrue(totalAmount, "Total Amount is not present");
					}
					a_Assert.assertTrue(totaldepcheck, "TotalDep is not present");
				}
				a_Assert.assertTrue(product, "Product is not present");
			}
			a_Assert.assertTrue(pickuplocc, "pickUploc is not present");


			//--------------------------------------------------
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();

	}








}