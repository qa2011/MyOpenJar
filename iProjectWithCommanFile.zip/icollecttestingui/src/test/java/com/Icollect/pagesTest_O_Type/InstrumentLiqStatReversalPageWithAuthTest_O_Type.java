package com.Icollect.pagesTest_O_Type;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.util.Log;
import com.util.Setup;
import com.util.Weblocator;

public class InstrumentLiqStatReversalPageWithAuthTest_O_Type extends Setup{
	SoftAssert s_assert;
	
	@Test(priority=0)
	public void Verify_seek_window_maker_name() {
		Log.startTestCase("Verify seek window maker name");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Boolean status=instLiqStatReversal.retrieve("UCC-D", schduleno);
			if (status) {
				boolean status1=instLiqStatReversal.modify();
				if (status1) {
					boolean status2=instLiqStatReversal.modifyWithOption("revesal_Return", "Payment stopped by the drawer." ,"Return "+Weblocator.GetDateTime());
					if (status2) {
						String reveStatus=instLiqStatReversal.reversalStatusGet();
						Weblocator.explicitWait(2);
						Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
						Weblocator.explicitWait(2);
						if (StringUtils.isNotBlank(reveStatus)) {
							dashboard.logout();
							Weblocator.explicitWait(2);
							login.login(checkerName);
							dashboard.InstrumentLiqStatReversalAuth();
							Weblocator.explicitWait(2);
							boolean productcode=instLiqStatReversalAuth.retrieve();
							Weblocator.explicitWait(1);
							if (productcode) {
								boolean msg=instLiqStatReversalAuth.reject(schduleno, "reject "+elecomm.loginUserName()+""+Weblocator.GetDateTime());
								if (msg) {
									String msgnotfound=instLiqStatReversalAuth.auth(schduleno);
									s_assert.assertNotNull(msgnotfound, "Not found message not present");
								}
								s_assert.assertTrue(msg, "Reject Message is not present");
							}
							s_assert.assertTrue(productcode, "after retrive btn productcode Not is not prsent");
						}
						s_assert.assertNotNull(reveStatus, "reversal Status Getting Null");
					}
					s_assert.assertTrue(status2, "return Drop down is not present");
				}
				s_assert.assertTrue(status1, "Modify link not open");
			}
			s_assert.assertTrue(status, "No Records found");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	
	
}