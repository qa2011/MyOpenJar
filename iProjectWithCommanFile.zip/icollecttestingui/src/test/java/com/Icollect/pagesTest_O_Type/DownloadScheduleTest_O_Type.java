package com.Icollect.pagesTest_O_Type;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DownloadSchedulePage;
import com.util.Log;
import com.util.ReadConfig;
import com.util.Weblocator;

public class DownloadScheduleTest_O_Type extends DownloadSchedulePage{

	SoftAssert a_Assert;
	String Product=""; 
	
	
	@BeforeTest
	public void readConfig() {
		ReadConfig readconfig=new ReadConfig();
		Product=readconfig.pro.getProperty("Product"); 
	}

	@Test(priority=0)
	public void downloadSchedule() {
		Log.startTestCase("download Schedule");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean productispresent=downloadSch.retrieve(Product);
			if (productispresent) {
				String msg=downloadSch.download();
				Weblocator.explicitWait(2);
				//a_Assert.assertEquals(msg, "TX1101-No pending schedule for the criteria entered." , "download not working");
			}
			//a_Assert.assertTrue(productispresent, "retrive not working");
			
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	

	@Test(priority=1)
	public void Verify_QDD_ExtractSchedule() {
		Log.startTestCase("Verify_QDD_ExtractSchedule");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			String msg=downloadSch.msgVerify();
			a_Assert.assertEquals(msg, "TX8652-Schedule(s) sent for processing" ,"ExtractSchedule not working");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	
	@Test(priority=2)
	public void Verify_QDD_Dispatch_Bank_Activation() {
		Log.startTestCase("Verify_QDD_Dispatch_Bank_Activation");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.explicitWait(1);
			Weblocator.Openlinks(dashboard.home);
			Weblocator.explicitWait(1);
			dashboard.DispatchBankActivation();
			boolean schispresent=downloadSch.retrieve_dispatchBankActivation(Product);
			if (schispresent) {
				DownloadSchedulePage.schno=downloadSch.detailsStatus();
				if (StringUtils.isNotBlank(schno)) {
					dashboard.logout();
					login.login(checkerName);
					dashboard.DispatchBankActivationAuth();
					boolean schedulenoIspresent=downloadSch.retrieve_dispatchBankActivationAuth(schno);
					if (schedulenoIspresent) {
						String msg=downloadSch.QDDDispBankActivationauth();
						a_Assert.assertEquals(msg, "No items to show.");
					}
					a_Assert.assertTrue(schedulenoIspresent, "Schedule not present");
				}
				a_Assert.assertNotNull(schno, "Schedule is not present");
			}
			a_Assert.assertTrue(schispresent, "Schedule no is not present");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}








}