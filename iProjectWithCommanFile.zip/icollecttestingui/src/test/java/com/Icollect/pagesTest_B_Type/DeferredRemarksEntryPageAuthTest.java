package com.Icollect.pagesTest_B_Type;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredRemarksEntryPage;
import com.util.Log;
import com.util.Weblocator;

public class DeferredRemarksEntryPageAuthTest extends DeferredRemarksEntryPage{

	SoftAssert s_assert;
	String clientName=null;
	String date=null;
	String remark="";

	@Test(priority=0)
	public void verify_RetrieveData() {
		Log.startTestCase("DefRemarksEntryAuth-Verify retrieve button functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.DeferredRemarksEntry();
			Weblocator.TextField(remarksEntry.depositTextField, depositNo);
			remarksEntry.retrieve();
			/*CommanClass.TextFieldWithOutTAB(remarksEntry.clientNamefilter, "ABIL");
			CommanClass.PressEnterBtn(remarksEntry.clientNamefilter);
			clientName=CommanClass.getPagetext(remarksEntry.clientNameFirstRow);
			date=CommanClass.getPagetext(remarksEntry.dateFirstRow);*/
			clientName=Weblocator.getPagetext(remarksEntry.clientNameFirstRow);
			date=Weblocator.getPagetext(remarksEntry.dateFirstRow);
			remark="test"+Weblocator.randomeNum();
			remarksEntry.modify(remark);

			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			dashboard.DeferredRemarksEntryAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);

			Boolean clientname=remarksEntryAuth.retrieve("anuragsi");
			s_assert.assertTrue(clientname, "clientName is not present");
			Weblocator.Openlinks(dashboard.DeferredRemarksMenuAuth);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_Reject() {
		Log.startTestCase("DefRemarksEntryAuth-Reject the saved remarks");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			remarksEntryAuth.retrieve("anuragsi");
			Weblocator.TextField(remarksEntryAuth.depositFilter, depositNo);
			Weblocator.PressEnterBtn(remarksEntryAuth.depositFilter);
			TimeUnit.SECONDS.sleep(2);
			String msg=remarksEntryAuth.reject("Rejecting Def remarks by - "+elecomm.loginUserName()+">>"+Weblocator.GetDateTime());
			//s_assert.assertEquals(msg, "Rejected");
			Weblocator.Openlinks(dashboard.DeferredRemarksMenuAuth);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_Auth() {
		Log.startTestCase("DefRemarksEntryAuth-Approve the saved remarks");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			remarksEntryAuth.retrieve("anuragsi");
			Weblocator.TextField(remarksEntryAuth.depositFilter, depositNo);
			Weblocator.PressEnterBtn(remarksEntryAuth.depositFilter);
			//WebDriverManager.explicitWait(2);
			String noItm=remarksEntryAuth.auth();
			//s_assert.assertEquals(noItm, "No items to show.");
			Weblocator.Openlinks(dashboard.DeferredRemarksMenuAuth);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



}