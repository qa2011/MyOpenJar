package com.Icollect.pagesTest_B_Type;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.TransactionsPage;
import com.util.Log;
import com.util.Weblocator;

public class DataEntryAndAuthPageTest extends TransactionsPage{

	SoftAssert a_Assert;

	@Test(priority=1)
	public void Transactions_verifycontents_DBGCS_4713_TC1() {
		Log.startTestCase("Transactions_verifycontents_DBGCS_4713_TC1: Verify Contents : Transactions -> Data Entry page");
		a_Assert = new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Checking breadcrumbNavigation is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.breadcrumbNavigation), "breadcrumbNavigation is not present");
			//extentTest.log(LogStatus.INFO, "Checking batch is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.batch), " batch is not present");
			//extentTest.log(LogStatus.INFO, "Checking status is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.status), " status is not present");
			//extentTest.log(LogStatus.INFO, "Checking PDCBatch is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.PDCBatch), " PDCBatch is not present");
			//extentTest.log(LogStatus.INFO, "Checking TheirReference  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.TheirReference), " TheirReference is not present");
			//extentTest.log(LogStatus.INFO, "Checking PickupLocation  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.PickupLocation), " PickupLocation is not present");
			//extentTest.log(LogStatus.INFO, "Checking PickupDt  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.PickupDt), " PickupDt is not present");
			//extentTest.log(LogStatus.INFO, "Checking Product  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.Product), " Product is not present");
			//extentTest.log(LogStatus.INFO, "Checking ActivationDt  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.ActivationDt), " ActivationDt is not present");
			//extentTest.log(LogStatus.INFO, "Checking DispBank  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.DispBank), " DispBank is not present");
			//extentTest.log(LogStatus.INFO, "Checking DispBranch  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.DispBranch), " DispBranch is not present");
			//extentTest.log(LogStatus.INFO, "Checking Arrangement  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.Arrangement), " Arrangement is not present");
			//extentTest.log(LogStatus.INFO, "Checking TotalDep  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.TotalDep), " TotalDep is not present");
			//extentTest.log(LogStatus.INFO, "Checking TotalAmnt  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.TotalAmnt), " TotalAmnt is not present");
			//extentTest.log(LogStatus.INFO, "Checking Remarks  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.Remarks), " Remarks is not present");
			//extentTest.log(LogStatus.INFO, "Checking ReportedDep  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.ReportedDep), " ReportedDep is not present");
			/*	//extentTest.log(LogStatus.INFO, "Checking EntryDt  is present");
			a_Assert.assertTrue(CommanClass.IselementPresent(trns.EntryDt), " EntryDt is not present");*/
			//extentTest.log(LogStatus.INFO, "Checking saveBtn  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.saveBtn), " saveBtn is not present");
			//extentTest.log(LogStatus.INFO, "Checking clearBtn  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.clearBtn), " clearBtn is not present");
			//extentTest.log(LogStatus.INFO, "Checking retrieveBtn  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.retrieveBtn), " retrieveBtn is not present");
			//extentTest.log(LogStatus.INFO, "Checking userInfoBtn  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.userInfoBtn), " userInfoBtn is not present");
			//extentTest.log(LogStatus.INFO, "Checking ReportedAmnt  is present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.ReportedAmnt), " ReportedAmnt is not present");
			//extentTest.log(LogStatus.INFO, "Checking EntryDt  is present");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	

	@Test(priority=2)
	public void Transactions_verifydefaultvaluedisp_DBGCS_4713_TC2() {
		Log.startTestCase("Transactions_verifydefaultvaluedisp_DBGCS_4713_TC2:  Verify default value in display : Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Checking Radio button");
			a_Assert.assertTrue(Weblocator.RadioBtn(trns.PDCBatchRadioBtn_no), "Radio button No by default is not selected");
			//extentTest.log(LogStatus.INFO, "Get PickupDt_date");
			Weblocator.GetAttributevalue(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Get //extentTest.log(LogStatus.INFO, \"Get PickupDt_date\");");
			Weblocator.GetAttributevalue(trns.ActivationDt_date);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();

	}	

	@Test(priority=3)
	public void Transactions_verifyPDCbtn_DBGCS_4713_TC3() {
		Log.startTestCase("Transactions_verifyPDCbtn_DBGCS-4713_TC3 : Verify default value in PDC button: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "checking Yes radio button iof PDC batch");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.PDCBatchRadioBtn_yes), "PDC Batch radio button YES is not present");
			//extentTest.log(LogStatus.INFO, "checking NO radio button iof PDC batch");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.PDCBatchRadioBtn_no), "PDC Batch radio button NO is not present");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=4)
	public void Transactions_verifyPDCbatch_DBGCS_4713_TC4() {
		Log.startTestCase("Transactions_verifyPDCbatch_DBGCS-4713_TC4 : Verify user can select value for PDC batch to Yes: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "click on PDCBatchRadioBtn_yes");
			Weblocator.Openlinks(trns.PDCBatchRadioBtn_yes);
			//extentTest.log(LogStatus.INFO, "check PDCBatchRadioBtn_yes is selected");
			a_Assert.assertTrue(Weblocator.RadioBtn(trns.PDCBatchRadioBtn_yes), "PDC batch YES Radio button is not selected");
			//extentTest.log(LogStatus.INFO, "click on clear popup");
			elecomm.ClearPopupHandle();
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=5)
	public void Transactions_validationonTheirReferencefield_DBGCS_4713_TC5() {
		Log.startTestCase("Transactions_validationonTheirReferencefield_DBGCS-4713_TC5 : Check validation on Their Reference field: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter in TheirReferenceTextField test data");
			Weblocator.TextField(trns.TheirReferenceTextField, "TestingTesting");
			//extentTest.log(LogStatus.INFO, "get value of TheirReferenceTextField");
			String getvalue=Weblocator.GetAttributevalue(trns.TheirReferenceTextField);
			//Assert.assertEquals(getvalue, "TestingTesting","TheirReferenceTextFiled is allow more then 12 char");
			//extentTest.log(LogStatus.INFO, "click on clear popup");
			elecomm.ClearPopupHandle();
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=6)
	public void Transactions_validationonPickuplocation_DBGCS_4713_TC6() {
		Log.startTestCase("Transactions_validationonPickuplocation_DBGCS-4713_TC6 : Check validation on Pickup location field: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "check PickupLocationHint");
			a_Assert.assertEquals(Weblocator.getPagetext(trns.PickupLocationHint), "Mumbai");
			//extentTest.log(LogStatus.INFO, "clear PickupLocationTextField");
			driver.findElement(trns.PickupLocationTextField).clear();
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "testing232323");
			//extentTest.log(LogStatus.INFO, "check PickupLocationHint");
			a_Assert.assertEquals(Weblocator.getPagetext(trns.PickupLocationHint), "?");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=7)
	public void Transactions_validationoninvalidPickuplocation_DBGCS_4713_TC7() {
		Log.startTestCase("Transactions_validationoninvalidPickuplocation_DBGCS-4713_TC7 : Check validation on invalid Pickup location field: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter data data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "testing232323");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "AAA121");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "12");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField,"23");
			//extentTest.log(LogStatus.INFO, "click on save button");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "check PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "PCV102-Pickup Location Not Found");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=8)
	public void Transactions_validationonProductfield_DBGCS_4713_TC8() {
		Log.startTestCase("Transactions_validationonProductfield_DBGCS-4713_TC8 : Check validation on Product field: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "check ProductHint");
			a_Assert.assertEquals(Weblocator.getPagetext(trns.ProductHint), "MICR Cheques - DB Br.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=9)
	public void Transactions_validationonproductclearingloc_DBGCS_4713_TC9() {
		Log.startTestCase("Transactions_validationonproductclearingloc_DBGCS-4713_TC9 : Check validation when product clearing location is not mapped to the Product: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "AGRA");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "Enter test data DispBranchTextField");
			Weblocator.TextField(trns.DispBranchTextField, "12");
			//extentTest.log(LogStatus.INFO, "Enter test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "12");
			//extentTest.log(LogStatus.INFO, "Enter test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField,"23");
			//extentTest.log(LogStatus.INFO, "Clieck on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "check PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "PCV205-Product - Drawnon Location Not Found");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=11)
	public void Transactions_invalidproduct_DBGCS_4713_TC11() {
		Log.startTestCase("Transactions_invalidproduct_DBGCS-4713_TC11 : Check validation when invalid product name is entered: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "testing232323");
			//extentTest.log(LogStatus.INFO, "Enter test data in DispBankTextField");
			Weblocator.TextField(trns.DispBankTextField, "testing232323");
			//extentTest.log(LogStatus.INFO, "Enter test data in ArrangementTextField");
			Weblocator.TextField(trns.ArrangementTextField, "testing232323");
			//extentTest.log(LogStatus.INFO, "Enter test data in DispBranchTextField");
			Weblocator.TextField(trns.DispBranchTextField, "12");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "12");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField,"23");
			//extentTest.log(LogStatus.INFO, "Click on save button");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "check PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "PCV201-Product Not Found");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=12)
	public void Transactions_pickupdate_DBGCS_4713_TC12() {
		Log.startTestCase("Transactions_pickupdate_DBGCS-4713_TC12 : Check user can enter Pickup date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "22/11/2020");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=13)
	public void Transactions_validationonpickupdate_futuredate_DBGCS_4713_TC13() {
		Log.startTestCase("Transactions_validationonpickupdate_futuredate_DBGCS-4713_TC13 : Validation on future Pickup date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "3");
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data in");
			Weblocator.TextField(trns.PickupDt_date, "24/11/2018");
			//extentTest.log(LogStatus.INFO, " Clicking on save button");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "calling GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getting WindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Saving data from Alert");
			elecomm.PopupHandle_dataSave();
			//a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0102-Invalid Pickup Date entered.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=14)
	public void Transactions_validationonpickupdate_backdate_DBGCS_4713_TC14() {
		Log.startTestCase("Transactions_validationonpickupdate_backdate_DBGCS-4713_TC14 : Validation on back Pickup date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField,testdata);
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "20/11/2018");
			//extentTest.log(LogStatus.INFO, "click on save button");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "scrollingByCoordinatesofAPage");
			Weblocator.scrollingByCoordinatesofAPage();
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "scrollingByCoordinatesofAPage");
			Weblocator.scrollingByCoordinatesofAPage();
			//extentTest.log(LogStatus.INFO, "check backBtn");

			//a_Assert.assertTrue(CommanClass.IselementPresent(trns.backBtn), "Back Button is not present");
			//extentTest.log(LogStatus.INFO, "check userInfoBtnID");
			//a_Assert.assertTrue(CommanClass.IselementPresent(trns.userInfoBtnID), "UserInfo Button is not present");
			//extentTest.log(LogStatus.INFO, "Check summaryBtn");
			//a_Assert.assertTrue(CommanClass.IselementPresent(trns.summaryBtn), "Summary Button is not present");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=15)
	public void Holiday_Transactions_pickupdateholiday_DBGCS_4713_TC15() {
		Log.startTestCase("Holiday_Transactions_pickupdateholiday_DBGCS_4713_TC15 : Validation If the Date entered is an holiday: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data in PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data in ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "Enter test data in TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "3");
			//extentTest.log(LogStatus.INFO, "Enter test data in ActivationDt_date");
			Weblocator.TextField_Clean(trns.ActivationDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data in ActivationDt_date");
			Weblocator.TextField(trns.ActivationDt_date, "23/11/2018");
			//extentTest.log(LogStatus.INFO, "Click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "check PopupHandle_dataSave");
			elecomm.PopupHandle_dataSave();
			//a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0119-Entered date is a holiday in the primary location of the batch.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=16)
	public void Transactions_activationdate_DBGCS_4713_TC16() {
		Log.startTestCase("Transactions_activationdate_DBGCS-4713_TC16 : Validation on activation date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "get GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "enter test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "3");
			//extentTest.log(LogStatus.INFO, "clear PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "enter test data PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "20/11/2018");
			//extentTest.log(LogStatus.INFO, "clear ActivationDt_date");
			Weblocator.TextField_Clean(trns.ActivationDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data ActivationDt_date");
			Weblocator.TextField(trns.ActivationDt_date, "18/11/2018");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "get GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0103-Invalid Activation Date entered.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=17)
	public void Transactions_validationonactivationdate_DBGCS_4713_TC17() {
		Log.startTestCase("Transactions_validationonactivationdate_DBGCS-4713_TC17 : Validation on activation date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "Enter test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "3");
			//extentTest.log(LogStatus.INFO, "clear PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "22/11/2018");
			//extentTest.log(LogStatus.INFO, "Clear ActivationDt_date");
			Weblocator.TextField_Clean(trns.ActivationDt_date);
			//extentTest.log(LogStatus.INFO, "Enter test data ActivationDt_date");
			Weblocator.TextField(trns.ActivationDt_date, "30/09/2018");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0121-The Activation Date Should Not Be Less Than The First Day of Previous Month");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=18)
	public void Transactions_validationonactivationdate_DBGCS_4713_TC18() {
		Log.startTestCase("Transactions_validationonactivationdate_DBGCS_4713_TC18 : Validation on activation date: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "2");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "3");
			//extentTest.log(LogStatus.INFO, "clear PickupDt_date ");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "22/11/2018");
			//extentTest.log(LogStatus.INFO, "clear ActivationDt_date");
			Weblocator.TextField_Clean(trns.ActivationDt_date);
			//extentTest.log(LogStatus.INFO, "Enter Test data ");
			Weblocator.TextField(trns.ActivationDt_date, "23/11/2020");
			//extentTest.log(LogStatus.INFO, "click on saveBtn ");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0123-Activation date should not be greater than 2 years from application date");

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	/*	@Test(priority=20)
	public void Transactions_activationdateeditable_DBGCS_4713_TC20() {
		Log.startTestCase("Transactions_activationdateeditable_DBGCS-4713_TC20 : Check activation date editable after batch creation: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		try {

		} catch (Exception e) {
			e.printStackTrace();
		}
		a_Assert.assertAll();
	}*/

	@Test(priority=21)
	public void Transactions_dispatchbankfield_DBGCS_4713_TC21() {
		Log.startTestCase("Transactions_dispatchbankfield_DBGCS-4713_TC21 : Verify the Dispatch bank field value is auto populated: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "verify DispBankTextField is enable");
			//a_Assert.assertFalse(CommanClass.verify_Element_Is_Enabled(trns.DispBankTextField), "DispBankTextField is enabled");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=22)
	public void Transactions_dispatchbankinvalid_DBGCS_4713_TC22() {
		Log.startTestCase("Transactions_dispatchbankinvalid_DBGCS-4713_TC22 : Verify when Dispatch bank field value is invalid: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=24)
	public void Transactions_dispatchbranch_DBGCS_4713_TC24() {
		Log.startTestCase("Transactions_dispatchbranch_DBGCS-4713_TC24 : Verify the Dispatch branch field value is auto populated: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "get value DispBranchTextField");
			a_Assert.assertEquals(Weblocator.GetAttributevalue(trns.DispBranchTextField), "784");
			//extentTest.log(LogStatus.INFO, "Verify DispBranchTextField");
			a_Assert.assertTrue(Weblocator.verify_Element_Is_Enabled(trns.DispBranchTextField), "DispBranchTextField is not enable");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=25)
	public void Transactions_dispatchbranchinvalid_DBGCS_4713_TC25() {
		Log.startTestCase("Transactions_dispatchbranchinvalid_DBGCS-4713_TC25 : Check If entered Dispatch Branch is invalid: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=26)
	public void Transactions_arrangementfield_DBGCS_4713_TC26() {
		Log.startTestCase("Transactions_arrangementfield_DBGCS-4713_TC26 :  VVerify the Arrangement field value is auto populated: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			////extentTest.log(LogStatus.INFO, "get value ArrangementTextField");
			//a_Assert.assertEquals(CommanClass.GetAttributevalue(trns.ArrangementTextField), "D+1");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=27)
	public void Transactions_arrangmntfieldinvalid_DBGCS_4713_TC27() {
		Log.startTestCase("Transactions_arrangmntfieldinvalid_DBGCS-4713_TC27 : Check If entered arrangemntfield is invalid: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=28)
	public void Transactions_remarksfield_DBGCS_4713_TC28() {
		Log.startTestCase("Transactions_remarksfield_DBGCS-4713_TC28  : Enter the data in the Remarks field in the Data entry screen: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, testdata);
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, testdata);
			//extentTest.log(LogStatus.INFO, "clear PickupDt_date");
			Weblocator.TextField_Clean(trns.PickupDt_date);
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupDt_date");
			Weblocator.TextField(trns.PickupDt_date, "22/11/2018");
			//extentTest.log(LogStatus.INFO, "clear ActivationDt_date");
			Weblocator.TextField_Clean(trns.ActivationDt_date);
			//extentTest.log(LogStatus.INFO, "Enter Test data ActivationDt_date");
			Weblocator.TextField(trns.ActivationDt_date, "22/11/2018");
			//extentTest.log(LogStatus.INFO, "Enter Test data RemarksTextField");
			Weblocator.TextField(trns.RemarksTextField, "testing automation Remarks"+testdata);
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Verify all buttons");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.backBtn), "Back Button is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.userInfoBtnID), "UserInfo Button is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(trns.summaryBtn), "Summary Button is not present");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=29)
	public void Transactions_totaldeposit_DBGCS_4713_TC29() {
		Log.startTestCase("Transactions_totaldeposit_DBGCS-4713_TC29 : Enter a value in the Total Deposits in the Data Entry screen: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "0");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "Click on saveBtn ");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "PopupHandle_dataSave");
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0104-Total deposits entered has to be greater than zero.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=30)
	public void Transactions_totalamount_DBGCS_4713_TC30() {
		Log.startTestCase("Transactions_totalamount_DBGCS-4713_TC30 : Enter a value in the Total amount in the Data Entry screen: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage();

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=31)
	public void Transactions_reporteddepositvalidation_DBGCS_4713_TC31() {
		Log.startTestCase("Transactions_reporteddepositvalidation_DBGCS-4713_TC31  : Enter a value in the Reported deposit in the Data Entry screen: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data ReportedDepTextField");
			Weblocator.TextField(trns.ReportedDepTextField, testdata);
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();
			Weblocator.scrollingByCoordinatesofAPage();

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=32)
	public void Transactions_reportedamount_DBGCS_4713_TC32() {
		Log.startTestCase("Transactions_reportedamount_DBGCS-4713_TC32  : Enter a value in the Reported amount in the Data Entry screen: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data ReportedAmntTextFiled");
			Weblocator.TextField(trns.ReportedAmntTextFiled, testdata);
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=33)
	public void Transactions_clicksavebtn_DBGCS_4713_TC33() {
		Log.startTestCase("Transactions_clicksavebtn_DBGCS-4713_TC33  : Save the data: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(trns.batchTextField), "Batch no is not generate is getting Null");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=34)
	public void Transactions_clicksavebtn_gridadd_DBGCS_4713_TC34() {
		Log.startTestCase("Transactions_clicksavebtn_gridadd_DBGCS-4713_TC34  : ");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			Weblocator.getWindowHandle();
			String batchno=Weblocator.GetAttributevalue(trns.batchTextField);
			System.out.println("Batch No : "+ batchno);
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage();
			//extentTest.log(LogStatus.INFO, "click on backbtn");
			Weblocator.Openlinks(trns.backBtn_f12);
			try {
				TimeUnit.SECONDS.sleep(3);
			}catch (Exception e) {
				e.printStackTrace();
			}
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(trns.retrieveBtn);
			try {
				TimeUnit.SECONDS.sleep(3);
			}catch (Exception e) {
				e.printStackTrace();
			}
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage();
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data ");
			Weblocator.TextField(trns.batchSearch, batchno);
			Weblocator.PressEnterBtn(trns.batchSearch);
			String getbatch=Weblocator.getPagetext(trns.batchNoGetFromBatchSummary);
			System.out.println("Get batch no : "+getbatch);
			a_Assert.assertEquals(batchno, getbatch);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=35)
	public void Transactions_clicksavebtn_checkvalidation_DBGCS_4713_TC35() {
		Log.startTestCase("Transactions_clicksavebtn_checkvalidation_DBGCS-4713_TC35 : ");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "0");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			a_Assert.assertEquals(elecomm.PopupHandle_dataSave(), "TX0104-Total deposits entered has to be greater than zero.");

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=36)
	public void Transactions_clicksavebtn_checkmandatoryfield_DBGCS_4713_TC36() {
		Log.startTestCase("Transactions_clicksavebtn_checkmandatoryfield_DBGCS-4713_TC36 : Save the data and check mandatory field error : Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=37)
	public void Transactions_clicksavebtn_checkbatchno_DBGCS_4713_TC37() {
		Log.startTestCase("Transactions_clicksavebtn_checkbatchno_DBGCS-4713_TC37 : Save the data and check batch number is generated: Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1");
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			String batchno=Weblocator.GetAttributevalue(trns.batchTextField);
			System.out.println("Batch No : "+ batchno);
			a_Assert.assertEquals(batchno, "181122000642");
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(trns.batchTextField), "Batch no is not generate is getting Null.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	//@Test(priority=38)
	public void EndToEndBatchcreationAndAuth() {

		Log.startTestCase("EndToEndBatchcreationAndAuth:");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//extentTest.log(LogStatus.INFO, "Enter Test data PickupLocationTextField");
			Weblocator.TextField(trns.PickupLocationTextField, "MUM");
			//extentTest.log(LogStatus.INFO, "Enter Test data ProductTextField");
			Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalDepTextField");
			Weblocator.TextField(trns.TotalDepTextField, "1");
			//extentTest.log(LogStatus.INFO, "Enter Test data TotalAmntField");
			Weblocator.TextField(trns.TotalAmntField, "1000");

			String TheirReferenceValue="Testing"+testdata;  //---------to be use in feature

			//extentTest.log(LogStatus.INFO, "Enter Test data TheirReferenceTextField");
			Weblocator.TextField(trns.TheirReferenceTextField,TheirReferenceValue);
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			//extentTest.log(LogStatus.INFO, "GeneralFetchingDataPopup");
			elecomm.GeneralFetchingDataPopup();
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			String batchno=Weblocator.GetAttributevalue(trns.batchTextField);
			System.out.println("Batch No : "+ batchno);
			//extentTest.log(LogStatus.INFO, "Enter Test data clientTextField");
			Weblocator.TextField(trns.clientTextField, "CILE");
			//extentTest.log(LogStatus.INFO, "Enter Test data totalInstTextfield");
			Weblocator.TextField(trns.totalInstTextfield, "1");
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("Error in TimeUnit");
			}
			//extentTest.log(LogStatus.INFO, "Enter Test data totalAmountTextfield");
			Weblocator.TextField(trns.totalAmountTextfield, "1000");
			Weblocator.Openlinks(trns.saveBtn_DepositTAB);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("Error in TimeUnit");
			}

			//extentTest.log(LogStatus.INFO, "Enter Test data instrumentNoTextField");
			Weblocator.TextField(trns.instrumentNoTextField, "Test"+testdata);
			//extentTest.log(LogStatus.INFO, "Enter Test data draweeBranchCodeTextFiled");
			Weblocator.TextField(trns.draweeBranchCodeTextFiled, "400001001");
			//extentTest.log(LogStatus.INFO, "Enter Test data instrumentAmountTextFiled");
			Weblocator.TextField(trns.instrumentAmountTextFiled, "1000");

			try {
				Thread.sleep(2000);
			}catch (Exception e) {
				// TODO: handle exception
			}
			// driver.findElement(trns.instrumentDateStrTextFiled).sendKeys("16112018");
			//driver.findElement(trns.instrumentDateStrTextFiled).sendKeys(Keys.TAB);
			//extentTest.log(LogStatus.INFO, "Enter Test data instrumentDateStrTextFiled");
			Weblocator.TextFieldWithOutTAB(trns.instrumentDateStrTextFiled, "16112018");
			driver.findElement(trns.instrumentDateStrTextFiled).sendKeys(Keys.TAB);
			//--------------------------------------------------
			Weblocator.Openlinks(trns.saveBtn_instrumentTAB);

			elecomm.PopupHandle_dataSave();
			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			dashboard.TransactionAuth();
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("error in time");
			}
			//extentTest.log(LogStatus.INFO, "Enter Test data trns");
			Weblocator.TextField(trns.batchFromTextField, batchno);
			//extentTest.log(LogStatus.INFO, "Enter Test data batchToTextField");
			Weblocator.TextField(trns.batchToTextField, batchno);
			//extentTest.log(LogStatus.INFO, "Enter Test data ");
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("error in time");
			}
			//extentTest.log(LogStatus.INFO, "click on retrieveBtn");
			Weblocator.Openlinks(trns.retrieveBtn);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("error in time");
			}
			Weblocator.DoubleClick(trns.selectBatchNo);
			//extentTest.log(LogStatus.INFO, "getWindowHandle");
			Weblocator.getWindowHandle();
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage();
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("error in time");
			}
			//extentTest.log(LogStatus.INFO, "click on authCheckBox");
			Weblocator.Openlinks(trns.authCheckBox);
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			//extentTest.log(LogStatus.INFO, "scrollingPage");
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			//extentTest.log(LogStatus.INFO, "click on saveBtn");
			Weblocator.Openlinks(trns.saveBtn);
			try {
				TimeUnit.SECONDS.sleep(4);
			}catch (Exception e) {
				// TODO: handle exception
			}
			elecomm.PopupHandle_dataSave();
			dashboard.logout();
			//login.login("anuragsin@hcl.com");
			//dashboard.Transaction();
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();

	}








}