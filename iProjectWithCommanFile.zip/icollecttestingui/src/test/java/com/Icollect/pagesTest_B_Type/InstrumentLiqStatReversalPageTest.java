package com.Icollect.pagesTest_B_Type;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentLiqStatReversalPage;
import com.util.Log;
import com.util.Weblocator;

public class InstrumentLiqStatReversalPageTest extends InstrumentLiqStatReversalPage{
	SoftAssert s_assert;
	
	@Test(priority=1)
	public void Verify_contents_in_Liquidation_Reversal_page() {
		Log.startTestCase("Verify contents in Liquidation Reversal page");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(productCodeTextField, "dgfsd");
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "Either Schedule# or Dispatch Bank/Branch should be entered");
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=2)
	public void Verify_Alt_Q_for_product_Field() {
		Log.startTestCase("Verify Alt Q for product Field");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(instLiqStatReversal.productCodeTextField);
			driver.findElement(instLiqStatReversal.productCodeTextField).sendKeys(Keys.ALT,"q");
			Weblocator.getWindowHandle();
			boolean codetext=Weblocator.IselementPresent(instLiqStatReversal.codeTextField);
			s_assert.assertTrue(codetext,"ALT Q function not working");
			elecomm.closeALTQ();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=3)
	public void Verify_Dispatch_Bank_validation() {
		Log.startTestCase("Verify Dispatch Bank validation");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(instLiqStatReversal.productCodeTextField, "D-DBMICR");
			Weblocator.TextField(instLiqStatReversal.disBankTextField, "sdfsafa");
			Weblocator.TextField(instLiqStatReversal.dispBranchTextField, "784");
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "SV2718-Dispatch Bank - Product not found.");
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=4)
	public void Verify_on_scheduleDate_text_field() {
		Log.startTestCase("Verify on scheduleDate text field");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(instLiqStatReversal.productCodeTextField, "D-DBMICR");
			Weblocator.TextField(instLiqStatReversal.disBankTextField, "DB");
			for (int i = 0; i < 6; i++) {
				driver.findElement(instLiqStatReversal.scheduleDateTextField).sendKeys(Keys.BACK_SPACE);
			}
			Weblocator.TextFieldWithOutTAB(instLiqStatReversal.scheduleDateTextField, "29/11/2020");
			Weblocator.TextField(instLiqStatReversal.dispBranchTextField, "784");
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TX0503 - Schedule Date must be less than or equal to Application Date");
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=5)
	public void Verify_that_modify_functionality() {
		Log.startTestCase("Verify that modify functionality ");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(instLiqStatReversal.productCodeTextField, "D-DBMICR");
			Weblocator.TextField(instLiqStatReversal.disBankTextField, "DB");
			Weblocator.TextField(instLiqStatReversal.dispBranchTextField, "784");
			for (int i = 0; i < 6; i++) {
				driver.findElement(instLiqStatReversal.scheduleDateTextField).sendKeys(Keys.BACK_SPACE);
			}
			Weblocator.TextFieldWithOutTAB(instLiqStatReversal.scheduleDateTextField, "22/11/2018");
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			boolean status=instLiqStatReversal.modify();
			s_assert.assertTrue(status, "Modify functionality not working");
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}	
	
	
	
}