package com.Icollect.pagesTest_B_Type;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredCollectionEntryAuthPage;
import com.util.Log;
import com.util.Setup;
import com.util.Weblocator;

import jxl.write.Label;
import jxl.write.WriteException;

public class DeferredCollectionEntryPageAuthTest extends DeferredCollectionEntryAuthPage{
	SoftAssert s_assert;
	String instrument_NoAuth="";
	String remarkMsg="Rejecting Deposit by checker";
	
	@AfterTest
	public void closeExl() throws WriteException, IOException  {
		try {
			Weblocator.WriteExcel();
			Label label6 = new Label(3, Setup.row, instrument_NoAuth);
			Weblocator.excelSheet.addCell(label6);
			Weblocator.myFirstWbook.write();
		} catch (Exception e) {
			Weblocator.printExceptionTrace(e);
		}
		Weblocator.myFirstWbook.close();
	}


	@Test
	public void verify_Add_Instrument() {
		Log.startTestCase("DefCollectionAuth- Verify Instrument added successfully");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String clientname=deferredcollEntry.retrieve(batchno);
			s_assert.assertNotNull(clientname, "Client name geting null");
			if (StringUtils.isNotBlank(clientname)) {
				//CommanClass.scrollingByCoordinatesofAPage();
				Weblocator.DoubleClick(deferredcollEntry.selectFirstRow);
				//WebDriverManager.explicitWait(2);
				instrument_No="Test"+Weblocator.randomeNum();
				Weblocator.TextField(deferredcollEntry.instrumentNoTextField, instrument_No);
				Weblocator.TextField(deferredcollEntry.draweeBranchCodeTextField, "220028002");
				Weblocator.TextField(deferredcollEntry.instAmountTextField, "1000");
				Weblocator.TextFieldWithOutTAB(deferredcollEntry.instrumentDateStrTextField, "16/11/2018");
				Weblocator.Openlinks(elecomm.saveBtnF11);
				try {
					s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
				}catch (Exception e) {
					Weblocator.Openlinks(elecomm.saveBtnF11);
					s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
				}

				Weblocator.Openlinks(deferredcollEntry.clearBtn);
				dashboard.logout();

				Weblocator.getWindowHandle();
				login.login("rachitranjans@hcl.com");
				//WebDriverManager.explicitWait(4);
				dashboard.DeferredCollectionEntryPageAuth();

			
				deferredcollEntryAuth.Clean_Retrieve();
				deferredcollEntryAuth.SearchBatchNo(batchno);
				deferredcollEntryAuth.authentication(batchno);
				String msg=deferredcollEntryAuth.BatchRemoveAfterAuth(batchno);
				s_assert.assertEquals(msg, "No items to show.");
				if (msg.equalsIgnoreCase("No items to show.")) {
					instrument_NoAuth=instrument_No;
				}
			}
			else {
				String msg=elecomm.PopupHandle_dataSave();
				System.out.println("Popup msg:  "+msg);
			}
			Log.endTestCase("");	
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}



	/*@Test(priority=0)
	public void VerifyBatchCreationAndAuthForABIL() {
		extentTest = extent.startTest("VerifyBatchCreationAndAuthForABIL");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			batchNo=deferredcollEntry.BatchCreation_Auth_ABIL();
			Assert.assertNotNull(batchNo, "Batch no is getting Null");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void VerifyAddInstrument() {
		extentTest = extent.startTest("VerifyAddInstrument");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			instrumentNo="Test"+testdata;
			deferredcollEntry.DeferredCollectionEntryPage_SeachBatchNo(batchNo);
			String msg=deferredcollEntry.AddInstrument(instrumentNo);
			Assert.assertEquals(msg, "Instrument(s) are saved successfully");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void VerifyBARFrame() {
		extentTest = extent.startTest("VerifyBARFrame");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			dashboard.DeferredCollectionEntryPageAuth();
			deferredcollEntryAuth.Clean_Retrieve();
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.batchDetailBAR), "batchDetailBAR is not open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.depositDetaisBAR), "depositDetaisBAR is open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.instrumentDetailBAR), "instrumentDetailBAR is open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.enrichmentsDetailBAR), "enrichmentsDetailBAR is open");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void VerifyRejectionPopup() {
		extentTest = extent.startTest("VerifyRejection");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.DeferredCollectionEntryPageAuth();
			deferredcollEntryAuth.Clean_Retrieve();
			deferredcollEntryAuth.SearchBatchNo(batchNo);
			CommanClass.Openlinks(deferredcollEntryAuth.rejectCheckBox);
			CommanClass.getWindowHandle();
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.rejectRemarkPopUpHeader), "Reject Remarks");
			s_assert.assertTrue(CommanClass.IselementPresent(elecomm.okBtn), "Ok button is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(elecomm.cancleBtn), "Cancle Button is not present");
			deferredcollEntryAuth.Rejection(remarkMsg);
			CommanClass.getWindowHandle();
			CommanClass.Openlinks(deferredcollEntry.saveBtnf11);

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=4)
	public void VerifyUserInfoDetails_BatchDetails() {
		extentTest = extent.startTest("VerifyUserInfoDetails");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.DeferredCollectionEntryPageAuth();
			deferredcollEntryAuth.Clean_Retrieve();
			deferredcollEntryAuth.SearchBatchNo(batchNo);
			deferredcollEntryAuth.UserInfo();
			CommanClass.getWindowHandle();
			s_assert.assertNotNull(CommanClass.getPagetext(elecomm.makerName), "Maker name is  null");
			s_assert.assertNotNull(CommanClass.getPagetext(elecomm.makerDateTime), "Maker Date Time is  null");
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.checkerAction), "Rejected");
			s_assert.assertEquals(CommanClass.GetAttributevalue(deferredcollEntryAuth.remarksTextFiledGetText), remarkMsg);
			CommanClass.Openlinks(elecomm.userInfoClose);
			CommanClass.getWindowHandle();
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=5)
	public void VerifyAuthentication() {
		extentTest = extent.startTest("VerifyAuthentication");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.DeferredCollectionEntryPageAuth();
			deferredcollEntryAuth.Clean_Retrieve();
			deferredcollEntryAuth.SearchBatchNo(batchNo);
			deferredcollEntryAuth.authentication(batchNo);
			String msg=deferredcollEntryAuth.BatchRemoveAfterAuth(batchNo);
			s_assert.assertEquals(msg, "No items to show.");

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	//@Test(priority=100)
	public void ItsRunningCodeBatchCreation() {
		extentTest = extent.startTest("Verify");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {

			//--batch create and Auth---------
			CommanClass.Openlinks(dashboard.home);
			dashboard.Transaction();
			String batchno=trns.batchCreation();
			//String batchno="181122000808";
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("error in time");
			}
			dashboard.DeferredCollectionEntryPage();

			CommanClass.Openlinks(deferredcollEntry.clearBtn);
			CommanClass.TextField(deferredcollEntry.batchNoTextFiled, batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntry.selectFirstRow);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.TextField(deferredcollEntry.instrumentNoTextField,instrumentNo );
			CommanClass.TextField(deferredcollEntry.draweeBranchCodeTextField, "220028002");
			CommanClass.TextField(deferredcollEntry.instAmountTextField, "1000");
			CommanClass.TextFieldWithOutTAB(deferredcollEntry.instrumentDateStrTextField, "16/11/2018");
			CommanClass.Openlinks(deferredcollEntry.saveBtnf11);
			s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
			CommanClass.getWindowHandle();
			CommanClass.scrollingByCoordinatesofAPage_scrollUp();
			try {
				TimeUnit.SECONDS.sleep(3);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.getWindowHandle();
			CommanClass.Openlinks(deferredcollEntry.clearBtn);

			dashboard.logout();
			CommanClass.getWindowHandle();

			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			CommanClass.getWindowHandle();
			login.login("rachitranjans@hcl.com");
			try {
				TimeUnit.SECONDS.sleep(4);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			dashboard.DeferredCollectionEntryPageAuth();
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			String remarkMsg="Rejecting Deposit by checker";

			CommanClass.Openlinks(deferredcollEntryAuth.clearF1);
			CommanClass.Openlinks(deferredcollEntryAuth.retrieveF7);

			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.batchDetailBAR), "batchDetailBAR is not open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.depositDetaisBAR), "depositDetaisBAR is open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.instrumentDetailBAR), "instrumentDetailBAR is open");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntryAuth.enrichmentsDetailBAR), "enrichmentsDetailBAR is open");

			CommanClass.TextFieldWithOutTAB(deferredcollEntryAuth.batchNoSearchFilterTextField, batchno);
			CommanClass.PressEnterBtn(deferredcollEntryAuth.batchNoSearchFilterTextField);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			Assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.batchNoFirstRow), batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.batchNoFirstRow);

			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.Openlinks(deferredcollEntryAuth.rejectCheckBox);
			CommanClass.getWindowHandle();
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.rejectRemarkPopUpHeader), "Reject Remarks");
			s_assert.assertTrue(CommanClass.IselementPresent(elecomm.okBtn), "Ok button is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(elecomm.cancleBtn), "Cancle Button is not present");
			CommanClass.Openlinks(elecomm.cancleBtn);
			CommanClass.getWindowHandle();

			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.clientDepositDetailsFirstRow);
			CommanClass.Openlinks(deferredcollEntryAuth.userInfoF10);
			CommanClass.getWindowHandle();
			s_assert.assertNotNull(CommanClass.getPagetext(elecomm.makerName), "Maker name is  null");
			s_assert.assertNotNull(CommanClass.getPagetext(elecomm.makerDateTime), "Maker Date Time is  null");
			CommanClass.Openlinks(elecomm.userInfoClose);
			CommanClass.getWindowHandle();

			//-----------------------jfhgjhjjgjg

			CommanClass.Openlinks(deferredcollEntryAuth.clearF1);
			CommanClass.Openlinks(deferredcollEntryAuth.retrieveF7);
			CommanClass.TextFieldWithOutTAB(deferredcollEntryAuth.batchNoSearchFilterTextField, batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.PressEnterBtn(deferredcollEntryAuth.batchNoSearchFilterTextField);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.batchNoFirstRow);

			CommanClass.Openlinks(deferredcollEntryAuth.rejectCheckBox);
			CommanClass.getWindowHandle();
			CommanClass.clearText(deferredcollEntryAuth.remarkTextField);
			CommanClass.TextField(deferredcollEntryAuth.remarkTextField, remarkMsg);
			CommanClass.Openlinks(elecomm.okBtn);
			CommanClass.getWindowHandle();
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.Openlinks(deferredcollEntry.saveBtnf11);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}

			//---------------------------------------------
			CommanClass.scrollingByCoordinatesofAPage_scrollUp();
			CommanClass.Openlinks(deferredcollEntryAuth.clearF1);
			CommanClass.Openlinks(deferredcollEntryAuth.retrieveF7);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.TextFieldWithOutTAB(deferredcollEntryAuth.batchNoSearchFilterTextField, batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.PressEnterBtn(deferredcollEntryAuth.batchNoSearchFilterTextField);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.batchNoFirstRow);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.clientDepositDetailsFirstRow);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}

			CommanClass.Openlinks(deferredcollEntryAuth.userInfoF10);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.getWindowHandle();
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.checkerAction), "Rejected");
			s_assert.assertEquals(CommanClass.GetAttributevalue(deferredcollEntryAuth.remarksTextFiledGetText), remarkMsg);
			CommanClass.Openlinks(elecomm.userInfoClose);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.getWindowHandle();
			//------------------------------------

			CommanClass.Openlinks(deferredcollEntryAuth.clearF1);
			CommanClass.Openlinks(deferredcollEntryAuth.retrieveF7);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.TextFieldWithOutTAB(deferredcollEntryAuth.batchNoSearchFilterTextField, batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.PressEnterBtn(deferredcollEntryAuth.batchNoSearchFilterTextField);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.DoubleClick(deferredcollEntryAuth.batchNoFirstRow);

			CommanClass.Openlinks(deferredcollEntryAuth.authCheckBox);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.Openlinks(deferredcollEntry.saveBtnf11);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			System.out.println(CommanClass.getPagetext(elecomm.popupMessage));
			//---------------------------
			CommanClass.Openlinks(deferredcollEntryAuth.clearF1);
			CommanClass.Openlinks(deferredcollEntryAuth.retrieveF7);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.TextFieldWithOutTAB(deferredcollEntryAuth.batchNoSearchFilterTextField, batchno);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			CommanClass.PressEnterBtn(deferredcollEntryAuth.batchNoSearchFilterTextField);
			try {
				TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			//CommanClass.DoubleClick(deferredcollEntryAuth.batchNoFirstRow);
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntryAuth.batchNotFoundMsg), "No items to show.");

			//----------------------------

		} catch (Exception e) {
			//e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	 */






}