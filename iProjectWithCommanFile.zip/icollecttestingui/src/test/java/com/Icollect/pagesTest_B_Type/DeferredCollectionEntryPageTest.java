package com.Icollect.pagesTest_B_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredCollectionEntryPage;
import com.util.Log;
import com.util.Weblocator;

public class DeferredCollectionEntryPageTest extends DeferredCollectionEntryPage{

	SoftAssert s_assert;
	public static String testdata=null;
	int row;
	String batchno="";


	@Test(priority=0)
	public void verify_Default_onPageLoadvalues() {
		Log.startTestCase("DefCollection-Verify by default values are coming on page load");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			s_assert.assertEquals(Weblocator.GetAttributevalue(deferredcollEntry.enterDateTextFiled),"22/11/2018");
			s_assert.assertEquals(Weblocator.GetAttributevalue(deferredcollEntry.activationDateTextFiled),"00/00/0000");
			s_assert.assertEquals(Weblocator.GetAttributevalue(deferredcollEntry.depdateTextFiled),"00/00/0000");
			Weblocator.Openlinks(dashboard.DeferredCollectionEntryPageMenu);
			Log.endTestCase("");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority=1)
	public void verify_Search_Result_WhenNoDataInDate() {
		Log.startTestCase("DefCollection-Verify error message when data is not present on specific date");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextFieldWithOutTAB(deferredcollEntry.enterDateTextFiled, "20/11/2018");
			Weblocator.Openlinks(deferredcollEntry.retrieveBtn);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TX3807-No Data Retrieved for the entered criteria");
			Weblocator.Openlinks(clearBtn);
			Weblocator.Openlinks(clearBtn);
			Weblocator.Openlinks(dashboard.DeferredCollectionEntryPageMenu);
			Log.endTestCase("");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_GridLabels() {
		Log.startTestCase("DefCollection-Verify Grid labels on page");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {

			deferredcollEntry.retrieve(batchno);
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			//WebDriverManager.explicitWait(2);
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.IF2Label), "IF2 Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.infoLabel), "info Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.clientLabel), "client Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.arrangementLabel), "arrangement Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.pickupPtLabel), "pickupPt Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.depDateLabel), "depDate Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.depLabel), "dep Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.totalInstLabel), "totalInst Label is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.totalAmountLabel), "totalAmount Label is not present");
			Weblocator.Openlinks(dashboard.DeferredCollectionEntryPageMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	@Test(priority=3)
	public void verify_Info_Details() {
		Log.startTestCase("DefCollection-Verify the details of first row in Grid");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			deferredcollEntry.retrieve(batchno);
			Weblocator.scrollingByCoordinatesofAPage();
			String clientname=Weblocator.getPagetext(deferredcollEntry.clientNameFirstRowGetText);
			Weblocator.Openlinks(deferredcollEntry.infoBtnFirstRow);
			Weblocator.getWindowHandle();
			s_assert.assertEquals(Weblocator.getPagetext(deferredcollEntry.clientDescriptionGetText), clientname);
			Weblocator.Openlinks(deferredcollEntry.closeInfoPopup);
			Weblocator.getWindowHandle();
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			Weblocator.Openlinks(dashboard.DeferredCollectionEntryPageMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	@Test(priority=4)
	public void verify_UserInfo_Details() {
		Log.startTestCase("DefCollection-Verify User Info button");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			deferredcollEntry.retrieve(batchno);
			Weblocator.scrollingByCoordinatesofAPage();
			Weblocator.Openlinks(deferredcollEntry.selectFirstRow);
			Weblocator.scrollingByCoordinatesofAPage();
			Weblocator.Openlinks(deferredcollEntry.userInfoBtn);
			Weblocator.getWindowHandle();
			Weblocator.getPagetext(deferredcollEntry.makeNameGetText);
			Weblocator.getPagetext(deferredcollEntry.checkerNameGetText);
			s_assert.assertTrue(Weblocator.IselementPresent(deferredcollEntry.makeNameGetText), "Maker Name is not present");
			Weblocator.Openlinks(deferredcollEntry.closeMakerInfoBtn);
			Weblocator.getWindowHandle();
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();
			Weblocator.Openlinks(dashboard.DeferredCollectionEntryPageMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	//===============================================================================
	/*	@Test(priority=0)
	public void verify() {
		Log.startTestCase("Verify");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			s_assert.assertEquals(CommanClass.GetAttributevalue(deferredcollEntry.enterDateTextFiled),"22/11/2018");
			s_assert.assertEquals(CommanClass.GetAttributevalue(deferredcollEntry.activationDateTextFiled),"00/00/0000");
			s_assert.assertEquals(CommanClass.GetAttributevalue(deferredcollEntry.depdateTextFiled),"00/00/0000");
			//-----------------------------
			CommanClass.TextFieldWithOutTAB(deferredcollEntry.enterDateTextFiled, "20/11/2018");
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TX3807-No Data Retrieved for the entered criteria");
			//----------------------------
			CommanClass.Openlinks(deferredcollEntry.clearBtn);
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			//CommanClass.scrollingByCoordinatesofAPage();
			CommanClass.scrollingByCoordinatesofAPage_scrollUp();
			try {
			TimeUnit.SECONDS.sleep(2);
			}catch (Exception e) {
				System.out.println("sleep error");
			}
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.IF2Label), "IF2 Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.infoLabel), "info Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.clientLabel), "client Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.arrangementLabel), "arrangement Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.pickupPtLabel), "pickupPt Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.depDateLabel), "depDate Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.depLabel), "dep Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.totalInstLabel), "totalInst Label is not present");
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.totalAmountLabel), "totalAmount Label is not present");
			try {
				TimeUnit.SECONDS.sleep(2);
				}catch (Exception e) {
					System.out.println("sleep error");
				}
			CommanClass.scrollingByCoordinatesofAPage_scrollUp();
			//----------------------------
			CommanClass.Openlinks(deferredcollEntry.clearBtn);
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			CommanClass.scrollingByCoordinatesofAPage();
			String clientname=CommanClass.getPagetext(deferredcollEntry.clientNameFirstRowGetText);
			CommanClass.Openlinks(deferredcollEntry.infoBtnFirstRow);
			CommanClass.getWindowHandle();
			s_assert.assertEquals(CommanClass.getPagetext(deferredcollEntry.clientDescriptionGetText), clientname);
			CommanClass.Openlinks(deferredcollEntry.closeInfoPopup);
			CommanClass.getWindowHandle();
			CommanClass.scrollingByCoordinatesofAPage_scrollUp();
			//----------------------------
			CommanClass.Openlinks(deferredcollEntry.clearBtn);
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			CommanClass.scrollingByCoordinatesofAPage();
			CommanClass.Openlinks(deferredcollEntry.selectFirstRow);
			CommanClass.scrollingByCoordinatesofAPage();
			CommanClass.Openlinks(deferredcollEntry.userInfoBtn);
			CommanClass.getWindowHandle();
			CommanClass.getPagetext(deferredcollEntry.makeNameGetText);
			CommanClass.getPagetext(deferredcollEntry.checkerNameGetText);
			s_assert.assertTrue(CommanClass.IselementPresent(deferredcollEntry.makeNameGetText), "Maker Name is not present");
			CommanClass.Openlinks(deferredcollEntry.closeMakerInfoBtn);
			CommanClass.getWindowHandle();
			//----------------------------
			//--batch create and Auth---------
			CommanClass.Openlinks(dashboard.home);
			dashboard.Transaction();
			String batchno=trns.batchCreation();
			//String batchno="181122000780";

			dashboard.DeferredCollectionEntryPage();

			CommanClass.Openlinks(deferredcollEntry.clearBtn);
			CommanClass.TextField(deferredcollEntry.batchNoTextFiled, batchno);
			CommanClass.Openlinks(deferredcollEntry.retrieveBtn);
			CommanClass.DoubleClick(deferredcollEntry.selectFirstRow);
			try {
				TimeUnit.SECONDS.sleep(2);
				}catch (Exception e) {
					System.out.println("sleep error");
				}
			CommanClass.TextField(deferredcollEntry.instAmountTextField, "Test"+testdata);
			CommanClass.TextField(deferredcollEntry.draweeBranchCodeTextField, "220028002");
			CommanClass.TextField(deferredcollEntry.instAmountTextField, "1000");
			CommanClass.TextFieldWithOutTAB(deferredcollEntry.instrumentDateStrTextField, "16/11/2018");
			CommanClass.Openlinks(deferredcollEntry.saveBtn);
			s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
			dashboard.logout();

			//----------------------------

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/


}