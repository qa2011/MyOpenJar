package com.Icollect.pagesTest_B_Type;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentLiquidationAuthPage;
import com.util.Log;
import com.util.Weblocator;

import jxl.write.Label;
import jxl.write.WriteException;

public class InstrumentLiquidationPageAuthTest extends InstrumentLiquidationAuthPage{

	SoftAssert s_assert;
	String clientnameonGrid="";
	String instLiq_RefNo="";

	@AfterTest
	public void closeExl() throws WriteException, IOException  {
		try {
			Weblocator.WriteExcel();
			Label label6 = new Label(4, row, "Y");
			Weblocator.excelSheet.addCell(label6);

			if (clientnameonGrid.equalsIgnoreCase("ABIL")) {
				Label label7 = new Label(5, row, instLiq_RefNo);
				Weblocator.excelSheet.addCell(label7);
			}
			Weblocator.myFirstWbook.write();
		} catch (Exception e) {
			Weblocator.printExceptionTrace(e);
		}
		Weblocator.myFirstWbook.close();
	}

	@Test(priority=0)
	public void verify_ErrorMsg_Paid_returnCheckbox() {
		Log.startTestCase("Instrument Liquidation Auth - Verify Paid and Return checkbox validations");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiquidation();
			String status=instLiq.retrieve("D-DBMICR", thereRefNo);
			instLiq_RefNo="InstLiqRef"+Weblocator.randomeNum();
			Weblocator.TextField(instLiq.refrenceNo, instLiq_RefNo);
			if (status.equalsIgnoreCase("New")) {
				Boolean clientNameIspresent=Weblocator.IselementPresent(instLiq.GetGridDetailsAfterSaveBtn);
				if (clientNameIspresent) {
					Weblocator.Openlinks(instLiq.liqTypeDropListBtn);
					Weblocator.Openlinks(instLiq.liqTypeDroplistOptionReturn);
					//CommanClass.TextField(link, entertext)
					Weblocator.TextField(instLiq.returnReasonTextField, "Testing return");
					Weblocator.clearText(instLiq.returnAmountTextField);
					Weblocator.TextField(instLiq.returnAmountTextField, "1000");
					Weblocator.scrollingByCoordinatesofAPage();
					Weblocator.Openlinks(elecomm.saveBtnF11Capital);
					Weblocator.getWindowHandle();
					//WebDriverManager.Openlinks(elecomm.selectBtn);
					Weblocator.getWindowHandle();
					clientnameonGrid=Weblocator.Getactualtext(instLiq.GetGridDetailsAfterSaveBtn);
					s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
				}
				else {
					clientnameonGrid=instLiq.addInst("ABIL", "1000","Return");
					s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
				}
			}
			instLiq.clearData();// wait 7
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);

			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			dashboard.InstrumentLiquidationAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			//WebDriverManager.explicitWait(2);
			Weblocator.Openlinks(instLiqAuth.paidAmoutCheckBox);
			//WebDriverManager.explicitWait(2);
			Weblocator.Openlinks(instLiqAuth.returnAmountCheckBox);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TX996-Either Paid amount flag or Return amount flag should be Y");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.instrumentLiquidationAuthSubMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_Reject() {
		Log.startTestCase("Instrument Liquidation Auth - Rejecting the entry");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			TimeUnit.SECONDS.sleep(1);
			String msg=instLiqAuth.retrive(instLiq_RefNo);
			s_assert.assertTrue(Weblocator.IselementPresent(instLiqAuth.dispBankFirstCol), "Retrive functinlity is not working");
			String check=instLiqAuth.reject("Reject By--"+elecomm.username+">>"+Weblocator.GetDateTime());
			s_assert.assertEquals(check, "Rejected");
			Weblocator.Openlinks(dashboard.instrumentLiquidationAuthSubMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_Auth() {
		Log.startTestCase("Instrument Liquidation Auth - Approving the entry");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			String msg=instLiqAuth.retrive(instLiq_RefNo);
			//WebDriverManager.explicitWait(2);
			instLiqAuth.auth();
			if (Weblocator.IselementPresent(instLiqAuth.rejectRedColor)==false) {
				s_assert.assertFalse(Weblocator.IselementPresent(instLiqAuth.rejectRedColor), "successful Auth");
			}
			Weblocator.Openlinks(dashboard.instrumentLiquidationAuthSubMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


}