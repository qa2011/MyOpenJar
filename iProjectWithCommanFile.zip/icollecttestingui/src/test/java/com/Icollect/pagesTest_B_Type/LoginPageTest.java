package com.Icollect.pagesTest_B_Type;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.Icollect.pages.LoginPage;
import com.util.Log;
import com.util.Weblocator;

/*import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;
*/
public class LoginPageTest extends LoginPage{


	/*@Test(priority=0, description="Verify login page title test")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test case Description :  Verify Login page Title test on Page")
	@Story("Story Name : To check login page Title")*/
	public void verifyLoginPageTest() {
		Log.startTestCase("VerifyTitleLoginPage");
		boolean exception = false;
		try {
			System.out.println("The login page Title  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+login.getLoginPageTitle());
			Assert.assertTrue(Weblocator.IselementPresent(dashboard.home), " User is not able to login.");
			Assert.assertTrue(Weblocator.IselementPresent(dashboard.transactions), " User is not able to login.");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}

	}	

}