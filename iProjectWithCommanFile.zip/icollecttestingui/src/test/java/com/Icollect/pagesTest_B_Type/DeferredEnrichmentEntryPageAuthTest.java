package com.Icollect.pagesTest_B_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredEnrichmentEntryAuthPage;
import com.util.Log;
import com.util.Weblocator;

public class DeferredEnrichmentEntryPageAuthTest extends DeferredEnrichmentEntryAuthPage{

	SoftAssert s_assert;

	@Test(priority=0)
	public void verify_Enrichment_End_to_End() {
		Log.startTestCase("DefEnrichmentEntryAuth-Verify end to end Enrichment functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.explicitWait(1);
			dashboard.DeferredEnrichmentEntry();
			String enrichmentSet=verify_Add_New_Enrichment();
			System.out.println(enrichmentSet);
			
			dashboard.logout();
			//WebDriverManager.explicitWait(2);
			login.login("rachitranjans@hcl.com");
			dashboard.DeferredEnrichmentEntryAuth();
			enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			Weblocator.DoubleClick(enrichmentEntryAuth.instNumberFirstRowInstrumentTab);
			s_assert.assertEquals(enrichmentSet,Weblocator.getPagetext(enrichmentEntryAuth.enrichSetGet));
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();

			enrichmentEntryAuth.clear();
			enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			Boolean color=enrichmentEntryAuth.reject("Reject Testing");
			s_assert.assertTrue(color, "Color not change so this insturment not rejected");
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();

			enrichmentEntryAuth.clear();
			enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			String msg=enrichmentEntryAuth.auth();
			s_assert.assertEquals(msg, "TA0206-No records retrieved");
			Weblocator.scrollingByCoordinatesofAPage_scrollUp();

			enrichmentEntryAuth.clear();
			enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			String msg1=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg1, "TA0206-No records retrieved");
			Log.endTestCase("");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	/*@Test(priority=1)
	public void verify_Reject_Enrichment() {
		Log.startTestCase("Verify");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntryAuth.clear();
			//String enrichmentSet=verify_Add_New_Enrichment();
			//	login.login("rachitranjans@hcl.com");
			//dashboard.DeferredEnrichmentEntryAuth();
			String instno=enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			Boolean color=enrichmentEntryAuth.reject("Reject Testing");
			s_assert.assertTrue(color, "Color not change so this insturment no not rejected");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_Auth_Enrichment() {
		Log.startTestCase("Verify");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntryAuth.clear();
			//String enrichmentSet=verify_Add_New_Enrichment();
			//	login.login("rachitranjans@hcl.com");
			//dashboard.DeferredEnrichmentEntryAuth();
			String instno=enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
			String msg=enrichmentEntryAuth.auth();
			s_assert.assertEquals(msg, "TA0206-No records retrieved");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void verify_instrument_Not_Present_After_Auth_Enrichment() {
		Log.startTestCase("Verify");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntryAuth.clear();
			//String enrichmentSet=verify_Add_New_Enrichment();
			//login.login("rachitranjans@hcl.com");
			//dashboard.DeferredEnrichmentEntryAuth();
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TA0206-No records retrieved");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	 */
	public String verify_Add_New_Enrichment() throws InterruptedException {

		//enrichmentEntry.clear();
		//CommanClass.clearText(enrichmentEntry.instNumberTextField);
		//CommanClass.TextField(enrichmentEntry.instNumberTextField, Keys.chord(Keys.CONTROL, "a") + Keys.DELETE);
		String clientname=enrichmentEntry.retrieve(instrument_No);  //harcoded the value for now, integration with excel sheet is in progress
		String enrichmentSet=enrichmentEntry.openInstrumentAndSave("PORAS", Weblocator.randomeNum());
		return 	enrichmentSet;

	}


}