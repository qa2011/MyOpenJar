package com.Icollect.pagesTest_B_Type;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.scheduleLiquidationAuthPage;
import com.util.Log;
import com.util.Setup;
import com.util.Weblocator;

import jxl.write.Label;
import jxl.write.WriteException;

public class ScheduleLiquidationPageAuthTest extends scheduleLiquidationAuthPage{
	SoftAssert s_assert;
	boolean schdulePaidStatus;
	
	@AfterTest
	public void closeExl() throws WriteException, IOException  {
		try {
			Weblocator.WriteExcel();
			
			if (schdulePaidStatus) {
				Label label61 = new Label(8, Setup.row, "Y");
				Weblocator.excelSheet.addCell(label61);
			}
			Weblocator.myFirstWbook.write();
		} catch (Exception e) {
			Weblocator.printExceptionTrace(e);
		}
		Weblocator.myFirstWbook.close();
	}
	
	@Test(priority=0)
	public void Verify_Maker_Checker_Info() {
		Log.startTestCase("Verify_Maker_Checker_Info");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.logout();
			login.login(checkerName);
			dashboard.scheduleLiquidationAuth();
			Boolean status=schLiqAuth.retrieve("anuragsi");
			if (status) {
				Weblocator.Openlinks(scheduleDateFirstCol);
				Weblocator.Openlinks(elecomm.userinfoBtnF10);
				Weblocator.getWindowHandle();
				Boolean check=Weblocator.IselementPresent(elecomm.makerName_schLiqauth);
				s_assert.assertTrue(check, "Maker Name is not present");
				Weblocator.Openlinks(elecomm.userInfoClose);
				Weblocator.getWindowHandle();
			}
			s_assert.assertTrue(status, "No data found");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.scheduleLiquidationAuthSubMenu);
		}catch (Exception e) {
		
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}	
	
	@Test(priority=1)
	public void Verify_Reject_ScheduleLiquidation() {
		Log.startTestCase("Verify_Reject_ScheduleLiquidation");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Boolean status=schLiqAuth.retrieve("anuragsi");
			if (status) {
				Boolean rejectcheckbox=Weblocator.Openlinks(rejectCheckBox);
				if (rejectcheckbox) {
					String rejectmsg="Reject By--"+Weblocator.GetDateTime();
					String check=schLiqAuth.reject(rejectmsg);
					s_assert.assertEquals(check, "Rejected");
				}
				s_assert.assertTrue(rejectcheckbox, "Reject Check box is not present");
			}
			s_assert.assertTrue(status, "No data found");
			
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.scheduleLiquidationAuthSubMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=2)
	public void Verify_Auth_ScheduleLiquidation() {
		Log.startTestCase("Verify_Auth_ScheduleLiquidation");
		s_assert = new SoftAssert();
		boolean exception = false;
		schdulePaidStatus=false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Boolean status=schLiqAuth.retrieve("anuragsi");
			if (status) {
				Boolean authcheckbox=Weblocator.Openlinks(authCheckBoxAll);
				if (authcheckbox) {
					String check=schLiqAuth.auth();
					if (StringUtils.isNotBlank(check)) {
						schdulePaidStatus=true;
					}
					s_assert.assertEquals(check, "No items to show.");
				}
				s_assert.assertTrue(authcheckbox, "Auth Check box is not present");
			}
			s_assert.assertTrue(status, "No data found");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.scheduleLiquidationAuthSubMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
}