package com.Icollect.pagesTest_B_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredRemarksEntryPage;
import com.util.Log;
import com.util.Weblocator;

public class DeferredRemarksEntryPageTest extends DeferredRemarksEntryPage{

	SoftAssert s_assert;

	@Test(priority=0)
	public void verify_OnLoad_remarksPage() {
		Log.startTestCase("DefRemarksEntry-Verify on load default values");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			s_assert.assertEquals(Weblocator.GetAttributevalue(remarksEntry.enteryDateTextField), "22/11/2018");
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_popupMsg_InvaildData() {
		Log.startTestCase("DefRemarksEntry-Verify search results when invalid deposit number is retrieved");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			Weblocator.TextField(remarksEntry.depositTextField, "invalid_invalid");
			remarksEntry.retrieve();
			s_assert.assertEquals(elecomm.PopupHandle_dataSave(), "TA0206 - No records retrieved");
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_Deposit_Coloums() {
		Log.startTestCase("DefRemarksEntry-Verify grid labels");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			remarksEntry.retrieve();
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol1), "I(+)(F2) col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol2), "Info col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol3), "Client col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol4), "Arrangement col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol5), "Pickup Point col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol6), "Dep Dt col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol7), "Dep Dt col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol8), "Total Inst. col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol9), "Total Amnt is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol10), "Remarks col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(remarksEntry.remarksCol11), "Mod (F4) col is not present");
			Weblocator.Openlinks(elecomm.clearBtnF9);
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void verify_Deposit_Details_popup() {
		Log.startTestCase("DefRemarksEntry-Verify Info details pop up in first row");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			remarksEntry.retrieve();
			String clientnameinside=remarksEntry.DepositDetails();
			s_assert.assertEquals(Weblocator.getPagetext(remarksEntry.clientNameFirstRow), clientnameinside);
			Weblocator.Openlinks(elecomm.clearBtnF9);
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=4)
	public void verify_Deposit_UserInfo() {
		Log.startTestCase("DefRemarksEntry-Verify User Info button details");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			remarksEntry.retrieve();
			Weblocator.TextFieldWithOutTAB(clientNamefilter, "ABIL");
			Weblocator.PressEnterBtn(clientNamefilter);
			Weblocator.Openlinks(remarksEntry.clientNameFirstRow);
			Weblocator.Openlinks(elecomm.userinfoBtnF10);
			Weblocator.getWindowHandle();
			s_assert.assertTrue(Weblocator.IselementPresent(elecomm.makerName));
			Weblocator.Openlinks(elecomm.userInfoClose);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.clearBtnF9);
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=5)
	public void verify_Modify_Remarks() {
		Log.startTestCase("DefRemarksEntry-Modify remarks");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.clearBtnF9);
			remarksEntry.retrieve();
			String remark="test"+Weblocator.randomeNum();
			String getremarks=remarksEntry.modify(remark);
			s_assert.assertEquals(getremarks, remark);
			Weblocator.Openlinks(elecomm.clearBtnF9);
			Weblocator.Openlinks(dashboard.DeferredRemarksEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

}