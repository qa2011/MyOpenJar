package com.Icollect.pagesTest_B_Type;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentLiqStatReversalPage;
import com.util.Log;
import com.util.Weblocator;

public class InstrumentLiqStatReversalPageAuthTest extends InstrumentLiqStatReversalPage{
	SoftAssert s_assert;
	
	@Test(priority=0)
	public void Verify_seek_window_maker_name() {
		Log.startTestCase("Verify seek window maker name");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			driver.findElement(instLiqStatReversalAuth.makerNameTextField).sendKeys(Keys.ALT,"q");
			Weblocator.getWindowHandle();
			boolean codetext=Weblocator.IselementPresent(instLiqStatReversalAuth.codeTextField);
			s_assert.assertTrue(codetext,"ALT Q function not working");
			elecomm.closeALTQ();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=1)
	public void Verify_product_seek_window() {
		Log.startTestCase("Verify product seek window");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			driver.findElement(instLiqStatReversalAuth.productCodeTextField).sendKeys(Keys.ALT,"q");
			Weblocator.getWindowHandle();
			boolean codetext=Weblocator.IselementPresent(instLiqStatReversalAuth.codeTextField);
			s_assert.assertTrue(codetext,"ALT Q function not working");
			String prod=Weblocator.getPagetext(instLiqStatReversalAuth.productHeader);
			s_assert.assertEquals(prod, "Product");
			elecomm.closeALTQ();
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=2)
	public void Verify_product_Filter() {
		Log.startTestCase("Verify product Filter");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			Weblocator.TextField(instLiqStatReversalAuth.productFilter, "UCC");
			Weblocator.PressEnterBtn(instLiqStatReversalAuth.productFilter);
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=3)
	public void Verify_DispBank_Filter() {
		Log.startTestCase("Verify DispBank Filter");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			Weblocator.TextField(instLiqStatReversalAuth.disBankFilter, "DB");
			boolean status=Weblocator.PressEnterBtn(instLiqStatReversalAuth.disBankFilter);
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=4)
	public void Verify_DispBranch_Filter() {
		Log.startTestCase("Verify DispBranch Filter");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			Weblocator.TextField(instLiqStatReversalAuth.disBranchFilter, "784");
			Weblocator.PressEnterBtn(instLiqStatReversalAuth.disBranchFilter);
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=5)
	public void Verify_Search_with_Invalid_data() {
		Log.startTestCase("Verify Search with Invalid data");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			Weblocator.TextField(instLiqStatReversalAuth.disBranchFilter, "dfdsf");
			Weblocator.explicitWait(1);
			Weblocator.PressEnterBtn(instLiqStatReversalAuth.disBranchFilter);
			String noItem=Weblocator.getPagetext(elecomm.noItemToShowMsg);
			s_assert.assertEquals(noItem, "No items to show.");
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=6)
	public void Verify_User_Info_Details() {
		Log.startTestCase("Verify User Info Details");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			dashboard.InstrumentLiqStatReversalAuth();
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			Weblocator.TextField(instLiqStatReversalAuth.disBranchFilter, "784");
			boolean status=Weblocator.PressEnterBtn(instLiqStatReversalAuth.disBranchFilter);
			Weblocator.Openlinks(instLiqStatReversalAuth.productCodeFirstCol);
			Weblocator.Openlinks(elecomm.userinfoBtnF10);
			Weblocator.getWindowHandle();
			Weblocator.getPagetext(elecomm.makerName);
			Weblocator.Openlinks(elecomm.userInfoClose);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(dashboard.instrumentLiqStatReversalAuthMenu);
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=7)
	public void Verify_End_To_End() {
		Log.startTestCase("Verify_End_To_End");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Boolean status=instLiqStatReversal.retrieve("D-DBMICR", instStatusreversalAuth);
			if (status) {
				boolean status1=instLiqStatReversal.modify();
				if (status1) {
					boolean status2=instLiqStatReversal.modifyWithOption("Paid", "Payment stopped by the drawer." ,"Return "+elecomm.loginUserName()+""+Weblocator.GetDateTime());
					if (status2) {
						String reveStatus=instLiqStatReversal.reversalStatusGet();
						if (!reveStatus.equals(null)) {
							dashboard.logout();
							login.login(checkerName);
							dashboard.InstrumentLiqStatReversalAuth();
							boolean productcode=instLiqStatReversalAuth.retrieve();
							if (productcode) {
								boolean msg=instLiqStatReversalAuth.reject(instStatusreversalAuth, "reject "+elecomm.loginUserName()+""+Weblocator.GetDateTime());
								if (msg) {
									boolean productcode1=instLiqStatReversalAuth.retrieve();
									if (productcode1) {
										String msgnotfound=instLiqStatReversalAuth.auth(instStatusreversalAuth);
										s_assert.assertNotNull(msgnotfound, "Not found message not present");
									}
									s_assert.assertTrue(productcode1, "after retrive btn productcode1 Not is not prsent");
								}
								s_assert.assertTrue(msg, "Reject Message is not present");
							}
							s_assert.assertTrue(productcode, "after retrive btn productcode Not is not prsent");
						}
						s_assert.assertNotNull(reveStatus, "reversal Status Getting Null");
					}
					s_assert.assertTrue(status2, "return Drop down is not present");
				}
				s_assert.assertTrue(status1, "Modify link not open");
			}
			s_assert.assertTrue(status, "No Records found");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}	
	
}