package com.Icollect.pagesTest_B_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.scheduleLiquidationPage;
import com.util.Log;
import com.util.Weblocator;

public class ScheduleLiquidationPageTest extends scheduleLiquidationPage{
	SoftAssert s_assert;
	
	@Test(priority=0)
	public void Verify_ScheduleLiquidation_Paid_Status() {
		Log.startTestCase("Verify_ScheduleLiquidation_Paid_Status");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			
			Boolean status=schLiq.retrieve("D-DBMICR", "DB", "784");
			s_assert.assertTrue(status, "No Records founds");
			if (status) {
				String schLiqNo=schLiq.searchFilter(ReceiptAuth_ForSchLiq);
				if (!schLiqNo.equals("No Items Founds")) {
					String msg=schLiq.paid(ReceiptAuth_ForSchLiq);
					s_assert.assertEquals(msg, "No items to show.", "No items MSG not present");
				}
				s_assert.assertNotEquals(schLiqNo, "No items Founds","No items msg is present");
			}
		}catch (Exception e) {
		
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}	
	
}