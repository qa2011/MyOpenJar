package com.Icollect.pagesTest_B_Type;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentReceiptAuthPage;
import com.util.Log;
import com.util.Weblocator;

import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WriteException;

public class InstrumentReceiptPageAuthTest extends InstrumentReceiptAuthPage{

	SoftAssert s_assert;
	public String refNo=null;

	@Test(priority=0)
	public void verify_EndToEndInst_Receipt() {
		Log.startTestCase("Instrument Receipt Auth - Verify end to end functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String schduleno=instReceipt.retrieve("D-DBMICR", thereRefNo);
			s_assert.assertNotNull(schduleno, "Schdule not is not Null");
			refNo="RefNo"+Weblocator.randomeNum();
			String noItemMsg=instReceipt.recivedVerify(refNo);
			s_assert.assertEquals(noItemMsg, "No items to show.","Msg Not Match");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
			dashboard.logout();
			login.login("rachitranjans@hcl.com");
			dashboard.InstrumentReceiptAuth();

			instReceiptAuth.retrieve("D-DBMICR", "ANURAGSI");
			String status=instReceiptAuth.reject(refNo);
			s_assert.assertEquals(status, "Rejected");

			instReceiptAuth.retrieve("D-DBMICR", "ANURAGSI");
			instReceiptAuth.auth(refNo);
			
			Weblocator.Openlinks(dashboard.instrumentReceiptAuthSubMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@AfterTest
	public void updateExcle() throws BiffException, IOException, WriteException {
		Weblocator.ReadExcel();
		try {
			Weblocator.WriteExcel();
			//Label label6 = new Label(0, row, "USED"); //status
			//WebDriverManager.excelSheet.addCell(label6);
			
			Label label7 = new Label(7, row, "Y"); // ReceiptAuth_ForSchLiq
			Weblocator.excelSheet.addCell(label7);
			
			Weblocator.myFirstWbook.write();
		} catch (Exception e) {
			Weblocator.printExceptionTrace(e);
		}
		Weblocator.myFirstWbook.close();
	}

}