package com.Icollect.pagesTest_B_Type;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.DeferredEnrichmentEntryPage;
import com.util.Log;
import com.util.Weblocator;

public class DeferredEnrichmentEntryPageTest extends DeferredEnrichmentEntryPage{

	SoftAssert s_assert;

	@Test(priority=0)
	public void verify_Default_values_On_Page_load() {
		Log.startTestCase("DefEnrichmentEntry-Verify default values on page load");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.depDateFromStr), "00/00/0000");
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.depDateToStr), "00/00/0000");
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.depNumber), "(ALL)");
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.clientCode), "(ALL)");
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.productCode), "(ALL)");
			s_assert.assertEquals(Weblocator.GetAttributevalue(enrichmentEntry.instNumber), "(ALL)");
			Weblocator.Openlinks(dashboard.DeferredEnrichmentEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_RetriveBtn() {
		Log.startTestCase("DefEnrichmentEntry-Verify Retrieve button functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String clientname=Weblocator.getPagetext(enrichmentEntry.clientNameFirstRow);
			s_assert.assertEquals(clientname, Weblocator.getPagetext(enrichmentEntry.clientNameFirstRow));
			Weblocator.Openlinks(dashboard.DeferredEnrichmentEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=2)
	public void verify_InstrumentNo() {
		Log.startTestCase("DefEnrichmentEntry-Verify error message when invalid instrument number is retrieved");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntry.clear();

			Weblocator.TextField(enrichmentEntry.instNumberTextField, "Invalid_Invalid");
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "TA0206-No records retrieved");
			Weblocator.Openlinks(dashboard.DeferredEnrichmentEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void verifyGridlabels() {
		Log.startTestCase("DefEnrichmentEntry-Verify the Grid labels on page");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntry.clear();
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol1), "E+(F2) col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol2), "Info col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol3), "Client col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol4), "Product col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol5), "Dep slip col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol6), "inst # col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol7), "inst Dt col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol8), "Amount col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol9), "Drawee Br col is not present");
			s_assert.assertTrue(Weblocator.IselementPresent(enrichmentEntry.instCol10), "Disp Bank col is not present");
			Weblocator.Openlinks(dashboard.DeferredEnrichmentEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=4)
	public void verifyInstrumentDetailsPopup() {
		Log.startTestCase("DefEnrichmentEntry-Verify Info details pop up in Grid");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			enrichmentEntry.clear();
			Weblocator.Openlinks(elecomm.retrieveBtnF7);
			String clientname=Weblocator.getPagetext(enrichmentEntry.clientNameFirstRow);
			Weblocator.Openlinks(enrichmentEntry.searchBtnInfoCol);
			Weblocator.getWindowHandle();
			String clientdesc=Weblocator.getPagetext(enrichmentEntry.clientDescInstrumentDetailPopup);
			Weblocator.Openlinks(enrichmentEntry.closeInstrumentDetailPopup);
			Weblocator.getWindowHandle();
			s_assert.assertEquals(clientname, clientdesc);
			Weblocator.Openlinks(dashboard.DeferredEnrichmentEntryMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}







}