package com.Icollect.pagesTest_B_Type;

import java.awt.event.KeyEvent;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentReceiptPage;
import com.util.Log;
import com.util.Weblocator;

public class InstrumentReceiptPageTest extends InstrumentReceiptPage{

	SoftAssert s_assert;

	@Test(priority=0)
	public void verify_RadioBtn_ByDefaultSelected() {
		Log.startTestCase("Instrument Receipt - Verify page load default values");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Boolean isSelected=driver.findElement(instReceipt.regularRadioBtn).isSelected();
			s_assert.assertTrue(isSelected, "By default radio button is not selected");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_Invalid_ProductCode() {
		Log.startTestCase("Instrument Receipt - Verify the error message on invalid product code");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String schduleno=instReceipt.retrieve("sfsdf", thereRefNo);
			String msg=elecomm.PopupHandle_dataSave();
			s_assert.assertEquals(msg, "PHV201-Invalid Product Code");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority=2)
	public void verify_ALT_Q_Functionality() {
		Log.startTestCase("Instrument Receipt - verify the Alt+Q button functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.keyPressALTQ(instReceipt.productTextField);
			Boolean status=elecomm.closeALTQ();
			s_assert.assertTrue(status, "Product ALT Q is not close");

			Weblocator.keyPressALTQ(instReceipt.dispBankTextField);
			Boolean status1=elecomm.closeALTQ();
			s_assert.assertTrue(status1, "dispBank ALT Q is not close");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void verify_MakerID_Pending_For_Auth() {
		Log.startTestCase("Instrument Receipt - Verify maker ID");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.keyPressALTQ(instReceipt.productTextField);
			Boolean status=elecomm.closeALTQ();
			s_assert.assertTrue(status, "ALT Q is not close");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=4)
	public void verify_KeyPress_Functionality() {
		Log.startTestCase("Instrument Receipt - Verify Key press functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.genralkeyPress(KeyEvent.VK_F1);
			Weblocator.TextField(instReceipt.productTextField, "D-DBMICR");
			Weblocator.TextField(instReceipt.dispBankTextField,"DB");
			Weblocator.TextField(instReceipt.dispBranchTextField,"784");
			Boolean status1=Weblocator.genralkeyPress(KeyEvent.VK_F7);
			s_assert.assertTrue(status1, "F7 button is not working");

			Weblocator.Openlinks(instReceipt.schedulerNoFirstRow);
			Boolean status3=Weblocator.genralkeyPress(KeyEvent.VK_F6);
			s_assert.assertTrue(status3, "F6 button is not working");
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.closeBtn);
			Weblocator.getWindowHandle();

			Boolean status4=Weblocator.genralkeyPress(KeyEvent.VK_F11);
			s_assert.assertTrue(status4, "F11 button is not working");

			String msg=elecomm.PopupHandle_dataSave();
			//s_assert.assertEquals(msg, "No instruments selected.Please Select at least one instrument to save.");

			Boolean status=Weblocator.genralkeyPress(KeyEvent.VK_F1);
			s_assert.assertTrue(status, "F1 button is not working");
			Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}




}