package com.Icollect.pagesTest_N_Type;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.InstrumentLiquidationPage;
import com.util.Log;
import com.util.Weblocator;

public class InstrumentLiquidationPageTest extends InstrumentLiquidationPage{

	SoftAssert s_assert;

	@Test(priority=0)
	public void verify_PageLoad_DefaultValues() {
		Log.startTestCase("Instrument Liquidation-verify page load default values");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Boolean abc=driver.findElement(instLiq.regularRadioBtn).isSelected();
			s_assert.assertTrue(abc, "regularRadioBtn by default is not selected");
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=1)
	public void verify_seek_Of_Client() {
		Log.startTestCase("Instrument Liquidation-Verify seek window of Client field");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			s_assert.assertEquals(status, "New");
			Weblocator.Openlinks(elecomm.addInstF7Btn);
			Weblocator.Openlinks(instLiq.clientTextField);
			Weblocator.explicitWait(1);
			s_assert.assertTrue(Weblocator.IselementPresent(instLiq.clientSuggestList), "Client suggest list is not open");
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}


	@Test(priority=2)
	public void verify_seek_Of_DispBank() {
		Log.startTestCase("Instrument Liquidation-Verify seek window of Dispatch Bank field");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(instLiq.dispBankTexfield, "DB");
			String DBhint=Weblocator.getPagetext(instLiq.dispBankGet);
			s_assert.assertEquals(DBhint, "Deutsche Bank");
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=3)
	public void verify_seek_Of_Product() {
		Log.startTestCase("Instrument Liquidation-Verify seek window of Product Text field");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.TextField(instLiq.productCodeTextField, "D-DBMICR");
			String producthint=Weblocator.getPagetext(instLiq.productCodeGet);
			s_assert.assertEquals(producthint, "MICR Cheques - DB Br.");
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=4)
	public void verify_Default_Date() {
		Log.startTestCase("Instrument Liquidation-Verify default date on page load");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String date=Weblocator.GetAttributevalue(instLiq.scheduleDateTextField);
			s_assert.assertEquals(date, "22/11/2018","schedule Date is not matched");
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	/*@Test(priority=11)
	public void verify_Liquidation_Type_Return() {
		Log.startTestCase("");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			instLiq_RefNo="InstLiqRef"+testdata;
			CommanClass.TextField(instLiq.refrenceNo, instLiq_RefNo);
			if (status.equalsIgnoreCase("New")) {

				Boolean clientNameIspresent=CommanClass.IselementPresent(instLiq.GetGridDetailsAfterSaveBtn);
				if (clientNameIspresent) {
					CommanClass.Openlinks(instLiq.liqTypeDropListBtn);
					CommanClass.Openlinks(instLiq.liqTypeDroplistOptionReturn);
					//CommanClass.TextField(link, entertext)
					CommanClass.TextField(instLiq.returnReasonTextField, "Testing return");
					CommanClass.clearText(instLiq.returnAmountTextField);
					CommanClass.TextField(instLiq.returnAmountTextField, "1000");
					CommanClass.scrollingByCoordinatesofAPage();
					CommanClass.Openlinks(elecomm.saveBtnF11Capital);
					CommanClass.getWindowHandle();
					CommanClass.Openlinks(elecomm.selectBtn);
					CommanClass.getWindowHandle();
					String check=CommanClass.Getactualtext(instLiq.GetGridDetailsAfterSaveBtn);
					s_assert.assertEquals(check, "ABIL","Client name is not match");
				}
				else {
				clientnameonGrid=instLiq.addInst("ABIL", "1000","Return");
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
				}
			}
			instLiq.clearData();
			CommanClass.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + CommanClass.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}*/

	@Test(priority=6)
	public void verify_Liquidation_Type_Paid() {
		Log.startTestCase("Instrument Liquidation-verify Paid functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {/*
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			if (status.equalsIgnoreCase("New")) {
				String clientnameonGrid=instLiq.addInst("ABIL", "1000","Paid");
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
			}
			instLiq.clearData();
			CommanClass.Openlinks(dashboard.instrumentLiquidationMenu);
		 */} catch (Exception e) {
			 e.printStackTrace();
			 exception = true;
			 s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		 }
		s_assert.assertAll();
	}

	//@Test(priority=7)
	public void verify_Liquidation_Type_Open() {
		Log.startTestCase("Instrument Liquidation-verify Open Liquidation functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			if (status.equalsIgnoreCase("New")) {
				String clientnameonGrid=instLiq.addInst("ABIL", "1000","Open");
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
			}
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}

	@Test(priority=5)
	public void verify_Liquidation_Type_Paid_For_Zero_Proof() {
		Log.startTestCase("Instrument Liquidation-Verify zero proof error message");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {/*
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			if (status.equalsIgnoreCase("New")) {
				CommanClass.Openlinks(elecomm.addInstF7Btn);
				CommanClass.TextField(clientTextField, "ABIL");
				CommanClass.TextField(instTextField, "Test"+testdata);
				CommanClass.TextField(instAmountTextField, "1000");
				CommanClass.clearText(instDateTexField);
				CommanClass.TextFieldWithOutTAB(instDateTexField, "16/11/2018");
				CommanClass.TextField(bankBranchTextField, "VADGA1,BOM");
				CommanClass.Openlinks(liqTypeDropListBtn);

				CommanClass.Openlinks(liqTypeDroplistOption2);
				CommanClass.Openlinks(elecomm.selectBtn);
				CommanClass.getWindowHandle();
				CommanClass.Openlinks(elecomm.saveBtnF11);
				String msg=elecomm.PopupHandle_dataSave();
				//s_assert.assertEquals(msg, "TX0515-Paid Amount is not zero proofed.");
			}
			instLiq.clearData();
			CommanClass.Openlinks(dashboard.instrumentLiquidationMenu);
		 */} catch (Exception e) {
			 e.printStackTrace();
			 exception = true;
			 s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		 }
		s_assert.assertAll();
	}

	//@Test(priority=10)
	public void verify_Modify_Delete_Added_instrument() {
		Log.startTestCase("Instrument Liquidation-Verify Delete Instrument functionality");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			String status=instLiq.retrieve("D-DBMICR", thereRefNoGet);
			if (status.equalsIgnoreCase("New")) {
				instLiq.addInst("ABIL", "1000","Return");
				Weblocator.TextField(instLiq.returnReasonTextField, "Testing return "+Weblocator.randomeNum());
				Weblocator.TextField(instLiq.chargeInstTextField, Weblocator.randomeNum());
				String clientnameonGrid=Weblocator.GetAttributevalue(instLiq.GetGridDetailsAfterSaveBtn);
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");

				Weblocator.Openlinks(elecomm.deleteInstBtnF8);
				Weblocator.getWindowHandle();
				s_assert.assertTrue(Weblocator.Openlinks(elecomm.cancelBtnC),"Cancle Button is not present");
				Weblocator.getWindowHandle();

				Weblocator.Openlinks(elecomm.deleteInstBtnF8);
				Weblocator.getWindowHandle();
				s_assert.assertTrue(Weblocator.Openlinks(elecomm.nOBtnN),"No Button is not present");
				Weblocator.getWindowHandle();


				Weblocator.Openlinks(elecomm.deleteInstBtnF8);
				Weblocator.getWindowHandle();
				s_assert.assertTrue(Weblocator.Openlinks(elecomm.yesBtnY),"Yes Button is not present");
				Weblocator.getWindowHandle();

				String msg2=elecomm.PopupHandle_dataSave();  //TX0534-Use Delete(F5) Option To Delete Liquidation Entry

				driver.findElement(elecomm.deleteInstBtnF8).sendKeys(Keys.F5);
				Weblocator.getWindowHandle();
				Weblocator.Openlinks(elecomm.yesBtnY);
				Weblocator.getWindowHandle();
				s_assert.assertEquals(Weblocator.getPagetext(elecomm.noItemToShowMsg), "No items to show.");
			}
			instLiq.clearData();
			Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}






}