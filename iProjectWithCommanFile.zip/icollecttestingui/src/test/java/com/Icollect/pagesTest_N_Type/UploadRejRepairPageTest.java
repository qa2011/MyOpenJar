package com.Icollect.pagesTest_N_Type;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.UploadRRPage;
import com.util.ElementCommon;
import com.util.Weblocator;
import com.util.Log;
import com.util.ReadConfig;


public class UploadRejRepairPageTest extends UploadRRPage{
	SoftAssert a_Assert;
	public static String testdata=null;
	public static String testassertion="softassertion1";
	ReadConfig readconfig=new ReadConfig();
	boolean getFileUpdateStatus1;
	boolean getFileUpdateStatus2;
	String fileWithInvalidInsDate="";
	String fileWithInvalidPckPoint="";
	String endString="d";

	@BeforeMethod
	public void creatFile() throws IOException {

		//-------------------fileWithInvalidInsDate--------------------
		String Extn1=ElementCommon.randomeNum(2)+endString;
		fileWithInvalidInsDate=System.getProperty("user.dir")+"\\InputFolder\\tranUploadFile\\fileWithInvalidInsDate\\22111830DEL_30_N."+Extn1;
		String text1 = "H22111830DEL_30_N."+Extn1+"796       22112018            BRANCHUPLD                    N\n" + 
				"DRELLIFE   A74                         DPICK02   2211201800002000000000020000                                                                                                              \n" + 
				"C887771    DB        DB,ND     00000001000024112018R1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"C887772    SBI       SBI,ND    00000001000022112018R2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"DLUPAS-DEL DEL001                      DPICK05   2211201800001000000000050000                                                                                                              \n" + 
				"C887779    DB        DB,ND     00000005000022112018G                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \n" + 
				"T00002000000000070000";
		getFileUpdateStatus1=ElementCommon.getFileUpdate(fileWithInvalidInsDate, text1);
		//---------------------------fileWithInvalidPckPoint-----------
		String Extn2=ElementCommon.randomeNum(2)+endString;
		fileWithInvalidPckPoint=System.getProperty("user.dir")+"\\InputFolder\\tranUploadFile\\fileWithInvalidPckPoint\\22111830DEL_30_N."+Extn2;
		String text2 = "H22111830DEL_30_N."+Extn2+"796       22112018            BRANCHUPLD                    N\n" + 
				"DRELLIFE   A30                         DPICK02   2211201800002000000000020000                                                                                                              \n" + 
				"C887771    DB        DB,ND     00000001000022112018R1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"C887772    SBI       SBI,ND    00000001000022112018R2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"DLUPAS-DEL DEL001                      DPICK05   2211201800001000000000050000                                                                                                              \n" + 
				"C887779    DB        DB,ND     00000005000022112018G                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \n" + 
				"T00002000000000070000";
		getFileUpdateStatus2=ElementCommon.getFileUpdate(fileWithInvalidPckPoint, text2);
	}
	
	@AfterMethod
	public void deleteFile() {
		elecomm.deleteFile(fileWithInvalidInsDate);
		elecomm.deleteFile(fileWithInvalidPckPoint);
	}

	@Test(priority=0)
	public void verifycontents_on_Upload_RR_DBGCS_6639() {
		Log.startTestCase("verifycontents_on_Upload_RR_DBGCS_6639: Verify Contents : Transactions -> Data Entry page");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {    
			a_Assert.assertTrue(Weblocator.IselementPresent(breadcrumbNavigation), "breadcrumbNavigation not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(batchNumberLabel), "batch not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(batchTextField), "batchTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(status), "status not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(statusTextField), "statusTextField not present");			
			a_Assert.assertTrue(Weblocator.IselementPresent(PDCBatch), "PDCBatch not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PDCBatchRadioBtn_yes), "PDCBatchRadioBtn_yes not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PDCBatchRadioBtn_no), "PDCBatchRadioBtn_no not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TheirReference), "TheirReference not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TheirReferenceTextField), "TheirReferenceTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PickupLocation), "PickupLocation not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PickupLocationTextField), "PickupLocationTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PickupDt_date), "PickupDt_date not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(productLabel), "Product not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(productLabelTextField), "ProductTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ActivationDt), "ActivationDt not present");
			
			a_Assert.assertTrue(Weblocator.IselementPresent(ActivationDt_dateLabel), "ActivationDt_date not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(DispBank), "DispBank not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(DispBankTextField), "DispBankTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(DispBranch), "DispBranch not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(DispBranchTextField), "DispBranchTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ArrangementLabel), "Arrangement not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalDep), "TotalDep not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalAmnt), "RTotalAmnt not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalAmntField), "TotalAmntField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(RemarksLabel), "Remarks not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(RemarkTextField), "RemarksTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedDep), "ReportedDep not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedDepTextField), "ReportedDepTextField not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedAmntLabel), "ReportedAmnt not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedAmntTxtFiled), "RReportedAmntTextFiled not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(saveBtnDisabled), "saveBtn not present");									
			a_Assert.assertTrue(Weblocator.IselementPresent(clearButton), "clearBtn not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(retrieveBtn), "retrieveBtn not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(elecomm.userinfoBtnF10), "userInfoBtn not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(breadcrumbNavigation), "breadcrumbNavigation is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(DF2Header), "DF2Header is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(InfoHeader), "InfoHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(batchNoHeader), "batchNoHeader");
			a_Assert.assertTrue(Weblocator.IselementPresent(productHeader), "productHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(pickupDateHeader), "pickupDateHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(pickupLocHeader), "pickupLocHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(totalDepHeader), "totalDepHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(totalAmtHeader), "totalAmtHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(PDCHeader), "PDCHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(modfyHeader), "modfyHeader is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(delHeader), "delHeader is not present");							
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	

	@Test(priority=1)	
	public void verify_Deletion_RR_DBGCS_6646() {
		Log.startTestCase("verify_Deletion_RR_DBGCS_6646: Verify Contents : verify_Deletion_RR_DBGCS_6646");
		a_Assert = new SoftAssert();
		boolean exception = false;
		try {                        
			String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidPckPoint);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(dashboard.UploadRejRep);
			Weblocator.explicitWait(2);
			if (StringUtils.isNotBlank(batchNo)) {
				boolean batchPresent=validat_RjctdRcrd(batchNo);
				Weblocator.explicitWait(2);
				if (batchPresent) {
					boolean batchPresent1=Not_Delete_Rej_Record();// Click on No button while deleting record
					Weblocator.explicitWait(2);
					if (batchPresent1) {
						boolean deleteStatus=Delete_Rej_Record(batchNo);
						Weblocator.explicitWait(2);
					}
				}
			}
			a_Assert.assertNotNull(batchNo, "Batch no is getting null");
			Weblocator.Openlinks(elecomm.clearBtnF1);
			
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	

	@Test(priority=2)
	public void Verify_ClearButton_functionalityOn_Batch_Screen() {
		Log.startTestCase("Verify_ClearButton_functionalityOn_Batch_Screen");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidPckPoint);
			Weblocator.Openlinks(dashboard.UploadRejRep);
			Weblocator.explicitWait(2);
			validat_RjctdRcrd(batchNo);	
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(EditrejtdRcrd);
			Weblocator.explicitWait(2);
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(batchTextFieldgetBatch),"batchTextFieldgetBatch is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(statusTextFieldgetText),"statusTextFieldgetText is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(PickupLocationTextFieldgetText),"PickupLocationTextFieldgetText is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(PickupDt_dategetText),"PickupDt_date is not empty" );
			
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(ProductTextFieldgetText),"ProductTextFieldgetText is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(ActivationDt_dategetText),"ActivationDt_dategetText is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(DispBankTextFieldgetText),"DispBankTextFieldgetText is not empty" );
			
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(DispBranchTextFieldgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(ArrangementTextFieldgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(TotalDepTextFieldgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(TotalAmntFieldgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(ReportedDepTextFieldgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertNotNull(Weblocator.GetAttributevalue(ReportedAmntTextFiledgetText),"PickupLocationTextField is not empty" );
			a_Assert.assertTrue(Weblocator.IselementPresent(saveBtnn), "saveBtn not present");		
			Weblocator.Openlinks(clearButton);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	
	
	@Test(priority=3)
	public void Verify_Contents_On_Deposit_Screen() {
		Log.startTestCase("Verify_Contents_On_Deposit_Screen");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidPckPoint);
			//Elements.Openlinks(dashboard.UploadRejRep);
			//validat_RjctdRcrd(batchNo,true);	
			Weblocator.Openlinks(F2rejtdRcrd);						
			Weblocator.explicitWait(1);	
			a_Assert.assertTrue(Weblocator.IselementPresent(DepositTabSelected), "Deposit tab not selected ");	
			a_Assert.assertTrue(Weblocator.IselementPresent(DepositEntryheader), "Deposit tab not selected ");						
			Weblocator.Openlinks(EditDept);	
			Weblocator.explicitWait(2);
			//ClickYesNoButton(ConfirmationMsg,"Yes");	
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.yesBtn2);
			Weblocator.getWindowHandle();
			//a_Assert.assertTrue(Elements.IselementPresent(batchTextField),"batchTextField is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(Product),"Product is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ProductTextField),"ProductTextField is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(DepActivationDate),"DepActivationDate is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ActivationDt_date),"ActivationDt_date is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(client),"client is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(clientCodeTxt),"clientCodeTxt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(Arrangement),"Arrangement is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(DepArrangementCodeText),"DepArrangementCodeText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(pickupPoint),"pickupPoint is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(pickupPointTxt),"pickupPointTxt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(DepDate),"DepDate is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(DepDateText),"DepDateText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(depNo),"depNo is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(depNoText),"depNoText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(Summary),"Summary is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(SummaryText),"SummaryText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(payerId),"payerId is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(payerIdText),"payerIdText" );
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalInst),"TotalInst is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalInstTextfield),"totalInstTextfield is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(DepTotalAmntField),"DepTotalAmntField is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalAmountTextfield),"totalAmountTextfield is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(Remarks),"Remarks is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(RemarksTextField),"RemarksTextField is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedAmnt),"ReportedAmnt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedAmntTextFiled),"ReportedAmntTextFiled is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedInst),"ReportedInst is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(ReportedInsttxt),"ReportedInsttxt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalStub),"totalStub is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalStubtxt),"totalStubtxt is not present" );
			
			a_Assert.assertTrue(Weblocator.IselementPresent(balanceDep),"balanceDep is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(balanceDepText),"balanceDepText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(balanceAmnt),"balanceAmnt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(balanceAmntText),"balanceAmntText is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(depTotalAmt),"depTotalAmt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(depTotalAmtTxt),"depTotalAmtTxt is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalDep),"totalDep is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalDepTextField),"TotalDepTextField is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalAmntOfDep),"totalAmntOfDep is not present" );
			a_Assert.assertTrue(Weblocator.IselementPresent(totalAmntOfDepTextField),"TotalAmntField is not present" );
			
			a_Assert.assertTrue(Weblocator.IselementPresent(saveBtnEnabled), "saveBtn not present");	
			a_Assert.assertTrue(Weblocator.IselementPresent(clearBtn), "clearBtn not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(userInfoBtn), "userInfoBtn not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(backBtn_f12), "backBtn_f12 not present");
			//Elements.Openlinks(elecomm.clearBtnF1);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	
	@Test(priority=4)
	public void Verify_ClearButton_functionalityOn_Deposit_Screen() {
		Log.startTestCase("Verify_ClearButton_functionalityOn_Deposit_Screen");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidPckPoint);
			//Elements.Openlinks(dashboard.UploadRejRep);
			Weblocator.explicitWait(2);	
			Weblocator.Openlinks(F2rejtdRcrd);						
			Weblocator.explicitWait(2);	
			a_Assert.assertTrue(Weblocator.IselementPresent(DepositTabSelected), "Deposit tab not selected ");	
			a_Assert.assertTrue(Weblocator.IselementPresent(DepositEntryheader), "Deposit tab not selected ");						
			Weblocator.Openlinks(EditDept);	
			Weblocator.explicitWait(2);
			//ClickYesNoButton(ConfirmationMsg,"Yes");	
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.yesBtn2);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(clearBtn);
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(dashboard.UploadRejRep);
			Weblocator.getWindowHandle();
			Weblocator.Openlinks(elecomm.yesBtn2);
			Weblocator.explicitWait(2);
			Weblocator.getWindowHandle();
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	//-----------------------End to End----------------------------------
	@Test(priority=5)
	public void verify_Modify_Dep_DBGCS_6648() {
		Log.startTestCase("verify_Modify_Dep_DBGCS_6648: Verify Contents");
		a_Assert = new SoftAssert();
		boolean exception = false;
		try {                                
			String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidPckPoint);
			Weblocator.explicitWait(1);	
			Weblocator.Openlinks(dashboard.UploadRejRep);
			Weblocator.explicitWait(1);	
			System.out.println("BatchNo:>> " + batchNo);
			if (StringUtils.isNotBlank(batchNo)) {
				validat_RjctdRcrd(batchNo);	
				Weblocator.explicitWait(1);
				String Rej_Reason = Open_First_RejRecord();	
				System.out.println("Rej_Reason :>>"+Rej_Reason);
				Update_RejRecord(Rej_Reason);
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(dashboard.transactionUpload);
				dashboard.logout();
				login.login("rachitranjans@hcl.com");
				dashboard.TransactionAuth();
				String msg=trns.batchAuth(batchNo);
				a_Assert.assertEquals(msg, "TA0000 - No records to retrieve");
				dashboard.logout();
				login.login("anuragsin@hcl.com");
			}
			a_Assert.assertNotNull(batchno, "Batch no is getting null");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	
	@Test(priority=6)
	public void verify_Modify_Ins_DBGCS_6653() {
		Log.startTestCase("verify_Modify_Ins_DBGCS_6653: Verify Contents ");
		a_Assert = new SoftAssert();
		boolean exception = false;
		try {                                                                                                    
			String batchNo = tranUpload.getBatchNoFromSuccessUploadFile(fileWithInvalidInsDate);
			Weblocator.explicitWait(1);	
			Weblocator.Openlinks(dashboard.UploadRejRep);
			Weblocator.explicitWait(3);	
			System.out.println("BatchNo:>> " + batchNo);
			//  Please Pass the Batch # having the rejection Reason with Instrument post dated
			if (StringUtils.isNotBlank(batchNo)) {
				validat_RjctdRcrd(batchNo);	
				Weblocator.explicitWait(1);
				String Rej_Reason = Open_First_RejRecord();	
				System.out.println("Rej_Reason :>>"+Rej_Reason);
				Update_RejRecord(Rej_Reason);
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(dashboard.transactionUpload);
				dashboard.logout();
				login.login("rachitranjans@hcl.com");
				dashboard.TransactionAuth();
				Weblocator.explicitWait(1);
				String msg=trns.batchAuth(batchNo);
				Weblocator.explicitWait(1);
				a_Assert.assertEquals(msg, "TA0000 - No records to retrieve");
			}
			a_Assert.assertNotNull(batchno, "Batch no is getting null");

			dashboard.logout();
			login.login("anuragsin@hcl.com");
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}	



}

