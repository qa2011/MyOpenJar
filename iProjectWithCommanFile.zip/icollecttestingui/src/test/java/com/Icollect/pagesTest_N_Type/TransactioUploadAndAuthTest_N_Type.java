package com.Icollect.pagesTest_N_Type;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.Icollect.pages.TransactionUploadPage;
import com.util.ElementCommon;
import com.util.Weblocator;
import com.util.Log;
import com.util.ReadConfig;

public class TransactioUploadAndAuthTest_N_Type extends TransactionUploadPage{

	SoftAssert a_Assert;
	String Product=""; 
	public static String testassertion="softAssertion";
	ReadConfig readconfig=new ReadConfig();
	boolean getFileUpdateStatus;
	String TestFile="";
	String endString="b";

	@BeforeMethod
	public void creatFile() throws IOException {

		String Extn=ElementCommon.randomeNum(3);
		
		TestFile=System.getProperty("user.dir")+"\\InputFolder\\tranUploadFile\\newFile\\22111830DEL_30_N."+Extn;

		//TestFile = ".\\InputFolder\\tranUploadFile\\newFile\\22111830DEL_30_N."+Extn;

		String text = "H22111830DEL_30_N."+Extn+"796       22112018            BRANCHUPLD                    N\r\n" + 
				"DRELLIFE                               DPICK02   2211201800002000000000020000                                                                                                              \r\n" + 
				"C887771    DB        DB,ND     00000001000022112018R1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \r\n" + 
				"EE                                                                                                                                                                                                                                                              001\r\n" + 
				"EE                                                                                                                                                                                                                                                              001\r\n" + 
				"C887772    SBI       SBI,ND    00000001000022112018R2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \r\n" + 
				"ERR                                                                                                                                                                                                                                                             001\r\n" + 
				"ERR                                                                                                                                                                                                                                                             001\r\n" + 
				"DLUPAS-DEL                             DPICK05   2211201800001000000000005000                                                                                                              \r\n" + 
				"C887779    DB        DB,ND     00000000500022112018G                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \r\n" + 
				"T00002000000000025000\r\n" + 
				"";
		getFileUpdateStatus=ElementCommon.getFileUpdate(TestFile, text);
	}
	
	@AfterMethod
	public void deleteFile() {
		elecomm.deleteFile(TestFile);
	}


	@Test(priority=0)
	public void Verify_all_assertions() {
		Log.startTestCase("Verify_all_assertions");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

			System.out.println("Verify_all_assertions Testing");
			a_Assert.assertTrue(Weblocator.IselementPresent(breadcrumbNavigationTransactionUpload), "breadcrumbNavigationTransactionUpload");
			a_Assert.assertTrue(Weblocator.IselementPresent(FileLable), "breadcrumbNavigationTransactionUpload");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadStatusLable), " UploadStatusLable");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadStatusRadioBtn_Online), " UploadStatusRadioBtn_Online");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadStatusRadioBtn_Offline), " UploadStatusRadioBtn_Offline");
			a_Assert.assertTrue(Weblocator.RadioBtn(UploadStatusRadioBtn_Online), "Radio button No by default is not selected");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadTypeLable), " UploadType is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadTypelstbox), " UploadTypelstbox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(RetrieveBtn), " RetrieveBtn is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ChooseFilebtn), " ChooseFilebtn is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(FormHintMaxFilelenght), " FormHintMaxFilelenght is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(OkBtn), " OkBtn is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(ClearBtn), " ClearBtn is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(UploadBtn), " UploadBtn is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalDepositsLable), " TotalDepositsLable is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalAmmountLable), " TotalAmmountLable is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalRejectsLable), " TotalRejectsLable is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(FileUploadedLable), " FileUploadedLable is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(FileRejectedLable), " FileRejectedLable is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalDepositsTxtBox), " TotalDepositsTxtBox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalAmmountTxtBox), " TotalDepositsTxtBox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(TotalRejectsTxtBox), " TotalRejectsTxtBox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(FileUploadedTxtBox), " FileUploadedTxtBox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(FileRejectedTxtBox), " FileRejectedTxtBox is not present");

			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderChkBox), " GridHeaderChkBox is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderInfo), " GridHeaderInfo is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderFileName), " GridHeaderFileName is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderDAteTime), " GridHeaderDAteTime is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderEnc), " GridHeaderEnc is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderProduct), " GridHeaderProduct is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderLocation), " GridHeaderLocation is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderDepositCount), " GridHeaderDepositCount is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderTotalAmt), " GridHeaderTotalAmt is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderRejCount), " GridHeaderRejCount is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderStatus), " GridHeaderStatus is not present");
			a_Assert.assertTrue(Weblocator.IselementPresent(GridHeaderRejReason), " GridHeaderRejReason is not present");

			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=1)
	public void Verify_user_is_able_to_upload_multiple_files() {
		Log.startTestCase("Transaction upload : Verify user is able to upload multiple files");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(UploadTypeDropDwnicon);
			Weblocator.Openlinks(UploadTypeTxnUpload);
			Weblocator.explicitWait(2);
			WebElement chooseFile = driver.findElement(UploadBtn);
			Weblocator.explicitWait(1);

			//WebElement inputElement = driver.findElement(UploadBtn);
			String uploadFilePath = readconfig.newFile();
			String uploadFilePath2 = readconfig.duplicateFile();
			String uploadFilePath3 = readconfig.invalidFile();
			chooseFile.sendKeys(uploadFilePath + "\n " + uploadFilePath2 + "\n " + uploadFilePath3);

			String filecount=Weblocator.GetAttributevalue(ChooseFilebtn);
			//a_Assert.assertEquals(filecount,"3", "File count not match");
			Weblocator.explicitWait(2);
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=2)
	public void Verify_encryption_column_value() {
		Log.startTestCase("Transaction upload : Verify encryption column value");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

			boolean filenamepresent=tranUpload.retrieve(readconfig.ENCFileFormate());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				//a_Assert.assertEquals(statusMsg, "", "");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);


			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=3)
	public void Verify_no_file_upload_criteria() {
		Log.startTestCase("Transaction upload : Verify no file upload criteria");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {

			Weblocator.Openlinks(UploadTypeDropDwnicon);
			Weblocator.Openlinks(UploadTypeTxnUpload);
			Weblocator.Openlinks(RetrieveBtn);
			String msg=elecomm.PopupHandle_dataSave();
			a_Assert.assertEquals(msg, "TX1706 No Files found for the given criteria", "Popup message not present");

			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=4)
	public void Verify_the_validation_on_lenght_of_file_name() {
		Log.startTestCase("Transaction upload : Verify the validation on lenght of file name");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.lengthFileFormate());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "File name is more than 40 character", "Message not equal");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);

			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=5)
	public void Validate_the_functionality_of_reject_count_field() {
		Log.startTestCase("Transaction upload : Validate the functionality of reject count field");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.newFile());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				if (StringUtils.isNotBlank(statusMsg)) {
					String rejectCount=Weblocator.getPagetext(rejectCountCol);
					//------------assertion Put----
				}
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);

			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=6)
	public void Check_file_name_validation_in_header_record() {
		Log.startTestCase("Transaction upload : Check file name validation in header record");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.incorrectFileFormate());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "Incorrect File Name in Header record", "Reason for Upload file is not Equal");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=7)
	public void Check_Product_code_validations() {
		Log.startTestCase("Transaction upload : Check Product code validations.");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.incorrectFileFormate());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				String getproductCode=Weblocator.getPagetext(productCodeCol);
				a_Assert.assertEquals(getproductCode,getproductCode,"Product code not match");
				//a_Assert.assertEquals(statusMsg, "Incorrect File Name in Header record", "Reason for Upload file is not Equal");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=8)
	public void Verify_info_icon_in_grid() {
		Log.startTestCase("Transaction upload : Verify info icon in grid");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.newFile());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				if (StringUtils.isNotBlank(statusMsg)) { 

					String getDateTime=Weblocator.getPagetext(dateTimeCol);
					a_Assert.assertNotNull(getDateTime, "Date Time text field getting null");

					boolean searchIcon=Weblocator.Openlinks(searchIconBtn);
					if (searchIcon) {
						Weblocator.getWindowHandle();
						String getProduct=Weblocator.getPagetext(productCodeInfo);
						String status=Weblocator.getPagetext(statusInfo);
						a_Assert.assertEquals(statusMsg, statusMsg,"Message not match");
						a_Assert.assertTrue(Weblocator.Openlinks(closeBtnInfo),"Close buuton is not present in info grid");
						Weblocator.getWindowHandle();
					}
					a_Assert.assertTrue(searchIcon, "Search Icon button not present");
				}
				a_Assert.assertNotNull(statusMsg,"Status message getting null");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=9)
	public void Verify_button_clicks_using_keys() {
		Log.startTestCase("Transaction upload : Verify button clicks using keys");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			Weblocator.Openlinks(UploadTypeDropDwnicon);
			Weblocator.Openlinks(UploadTypeTxnUpload);
			Weblocator.explicitWait(2);
			WebElement chooseFile = driver.findElement(UploadBtn);
			Weblocator.explicitWait(1);
			chooseFile.sendKeys(readconfig.newFile());
			Weblocator.explicitWait(2);
			//Elements.genralkeyPress(KeyEvent.VK_F7);
			Actions action = new Actions(driver);
			//action.sendKeys(Keys.F12);
			action.sendKeys(Keys.F7);
			action.perform();
			Weblocator.explicitWait(3);

			a_Assert.assertTrue(Weblocator.IselementPresent(fileNameFirstRow), "Retrieve F7 key press not working");
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}


	@Test(priority=10)
	public void Verify_that_Duplicate_file_upload() {
		Log.startTestCase("Verify_that_Duplicate_file_upload");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.duplicateFile());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "This file has already been uploaded", "Reason message is not equal");

			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}
	@Test(priority=11)
	public void Verify_that_empty_file_Upload() {
		Log.startTestCase("Verify_that_empty_file_Upload");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.emptyFile());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "", "Reason for Upload File is not null");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=12)
	public void Verify_that_invalid_file_upload() {
		Log.startTestCase("Verify_that_invalid_file_upload");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.invalidFile());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "Trailer Record Missing", "Reason for Upload file is not Equal");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=13)
	public void Verify_that_File_upload_having_invalid_file_format() {
		Log.startTestCase("Verify_that_File_upload_having_invalid_file_format");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			boolean filenamepresent=tranUpload.retrieve(readconfig.invalidFileFormat());
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				a_Assert.assertEquals(statusMsg, "This file has already been uploaded", "Reason for Upload file is not equal");
			}
			Weblocator.Openlinks(tranUpload.clearBtF1);
			Weblocator.Openlinks(dashboard.transactionUpload);
			Weblocator.explicitWait(2);
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}

	@Test(priority=14)
	public void Verify_that_upload_file_successfully_and_validate_the_messages_valid_File_Upload() {
		Log.startTestCase("Verify_that_upload_file_successfully_and_validate_the_messages_valid_File_Upload");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			//boolean filenamepresent=tranUpload.retrieve(readconfig.newFile());
			boolean filenamepresent=tranUpload.retrieve(TestFile);
			a_Assert.assertTrue(filenamepresent, "Retrive button is not working.");
			if (filenamepresent) {
				String statusMsg=tranUpload.readyToUploadFile();
				if (StringUtils.isNotBlank(statusMsg)) {
					String statusMsgAfterUpload=tranUpload.UploadFile();
					if (StringUtils.isNotBlank(statusMsgAfterUpload)) {
						String batchno=tranUpload.getBatchNo();
						if (StringUtils.isNotBlank(batchno)) {
							Weblocator.Openlinks(dashboard.transactionUpload);
							dashboard.logout();
							login.login("rachitranjans@hcl.com");
							dashboard.TransactionAuth();
							String msg=trns.batchAuth(batchno);
							//a_Assert.assertEquals(msg, "TA0000 - No records to retrieve");
						}
						a_Assert.assertNotNull(batchno, "Batch no is getting null");
					}
					a_Assert.assertEquals(statusMsgAfterUpload, "Uploaded","Upload status is not present");
				}
				a_Assert.assertEquals(statusMsg, "Ready For Upload", "Ready For Upload message is not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();
	}


}