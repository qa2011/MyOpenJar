package com.Icollect.pagesTest_N_Type;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.util.Log;
import com.util.ReadConfig;
import com.util.Setup;
import com.util.Weblocator;

public class DataEntryAndAuthPageTest extends Setup{

	SoftAssert a_Assert;
	String pickUploc_N=""; 
	String Product_N="";
	String Client_N="";
	String pickuppoint_N=""; 
	String totaldep_N=""; 
	String Totalamount_N="";   
	String Totalinst_N="";
	String draweeBranch_N="";
	String instand_EnrichmentCount_N="";

	@BeforeTest
	public void readConfig() {
		ReadConfig readconfig=new ReadConfig();
		pickUploc_N=readconfig.pro.getProperty("pickUploc_N"); 
		Product_N=readconfig.pro.getProperty("Product_N"); 
		Client_N=readconfig.pro.getProperty("Client_N"); 
		pickuppoint_N=readconfig.pro.getProperty("pickuppoint_N"); 
		totaldep_N=readconfig.pro.getProperty("totaldep_N"); 
		Totalamount_N=readconfig.pro.getProperty("Totalamount_N"); 
		Totalinst_N=readconfig.pro.getProperty("Totalinst_N"); 
		draweeBranch_N=readconfig.pro.getProperty("draweeBranch_N"); 
		instand_EnrichmentCount_N=readconfig.pro.getProperty("instand_EnrichmentCount_N"); 
		
	}

	@Test(priority=0)
	public void EndToEndBatchcreationAndAuth() {
		Log.startTestCase("EndToEndBatchcreationAndAuth:");
		a_Assert=new SoftAssert();
		boolean exception = false;
		try {
			trns.batchCreation_N_Type(pickUploc_N, Product_N, Client_N, totaldep_N, Totalamount_N,Totalinst_N, pickuppoint_N,draweeBranch_N);
			
			

		} catch (Exception e) {
			e.printStackTrace();
			exception = true;
			a_Assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		a_Assert.assertAll();

	}








}