package end_To_end_flow;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;

import com.util.ElementCommon;

public class ReadAndWriteFile2 {

	boolean getFileUpdateStatus1;
	boolean getFileUpdateStatus2;
	String fileWithInvalidInsDate="";
	String fileWithInvalidPckPoint="";
	
	
	@Test
	void deleteFile() {
		// initialize File object
				File file = new File("C:\\Users\\AnuragSin\\eclipse-workspace_Demo\\icollecttestingui\\InputFolder\\tranUploadFile\\fileWithInvalidInsDate\\22111830DEL_30_N.85B");

				boolean result;
				try {
					// delete the file specified
					result = file.delete();
					// test if successfully deleted the file
					if (result) {
						System.out.println("Successfully deleted: " + file.getCanonicalPath());
					} else {
						System.out.println("Failed deleting " + file.getCanonicalPath());
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	

	//@Test
	public void creatFile() throws IOException {

		//-------------------fileWithInvalidInsDate--------------------
		String Extn1="01B";
		fileWithInvalidInsDate=System.getProperty("user.dir")+"\\InputFolder\\tranUploadFile\\fileWithInvalidInsDate\\22111830DEL_30_N."+Extn1;
		String text1 = "H22111830DEL_30_N."+Extn1+"796       22112018            BRANCHUPLD                    N\n" + 
				"DRELLIFE   A74                         DPICK02   2211201800002000000000020000                                                                                                              \n" + 
				"C887771    DB        DB,ND     00000001000024112018R1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"C887772    SBI       SBI,ND    00000001000022112018R2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"DLUPAS-DEL DEL001                      DPICK05   2211201800001000000000050000                                                                                                              \n" + 
				"C887779    DB        DB,ND     00000005000022112018G                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \n" + 
				"T00002000000000070000";
		getFileUpdateStatus1=ElementCommon.getFileUpdate(fileWithInvalidInsDate, text1);
		//---------------------------fileWithInvalidPckPoint-----------
		String Extn2="01B";
		fileWithInvalidPckPoint=System.getProperty("user.dir")+"\\InputFolder\\tranUploadFile\\fileWithInvalidPckPoint\\22111830DEL_30_N."+Extn2;
		String text2 = "H22111830DEL_30_N."+Extn2+"796       22112018            BRANCHUPLD                    N\n" + 
				"DRELLIFE   A30                         DPICK02   2211201800002000000000020000                                                                                                              \n" + 
				"C887771    DB        DB,ND     00000001000022112018R1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"EE                                                                                                                                                                                                                                                              001\n" + 
				"C887772    SBI       SBI,ND    00000001000022112018R2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            2    \n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"ERR                                                                                                                                                                                                                                                             001\n" + 
				"DLUPAS-DEL DEL001                      DPICK05   2211201800001000000000050000                                                                                                              \n" + 
				"C887779    DB        DB,ND     00000005000022112018G                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \n" + 
				"T00002000000000070000";
		getFileUpdateStatus2=ElementCommon.getFileUpdate(fileWithInvalidPckPoint, text2);
	}

}

