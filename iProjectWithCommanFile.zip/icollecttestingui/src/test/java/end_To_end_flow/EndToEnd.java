package end_To_end_flow;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.util.Log;
import com.util.Setup;
import com.util.Weblocator;

public class EndToEnd extends Setup{
	SoftAssert s_assert;
	String batchRefNo="";
	String thereRefNo="";
	String depositerRefNo="";
	String instrumentRefNo="";
	String instLiqRefNo="";
	
	
	@Test(priority=1)
	public void DataEntry_Auth() {
		driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
		Log.startTestCase("---------Data Entry and Auth-----------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			DataEntryWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=2)
	public void Deferred_Collection_Entry_and_Auth() {
		Log.startTestCase("----------Deferred Collection Entry and Auth----------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			DeferredCollectEntryWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=3)
	public void Deferred_Enrichment_Entry_With_Auth() {
		Log.startTestCase("-----------Deferred Enrichment Entry With Auth--------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			DeferredEnrichmentEntryWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=4)
	public void Instrument_Liquidation_With_Auth() {
		Log.startTestCase("-----------Instrument Liquidation With Auth-----------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			InstrumentLiquidationWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=5)
	public void Instrument_Receipt_With_Auth() {
		Log.startTestCase("-----------Instrument Receipt With Auth-----------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			InstrumentReceiptWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	//@Test(priority=6)
	public void Deferred_Remarks_Entry_With_Auth() {
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			/*DeferredRemarksEntryWithAuth();
			dashboard.logout();
			login.login(makerName);*/
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=7)
	public void Schedule_Liquidation_With_Auth() {
		Log.startTestCase("-----------Schedule Liquidation With Auth-----------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			ScheduleLiquidationWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	@Test(priority=8)
	public void Instrument_LiqStat_Reversa_With_Auth() {
		Log.startTestCase("-----------Schedule Liquidation With Auth-----------------");
		s_assert = new SoftAssert();
		boolean exception = false;
		try {
			InstrumentLiqStatReversalWithAuth();
			dashboard.logout();
			login.login(makerName);
			Log.endTestCase("---------------------------------------");
		}catch (Exception e) {
			e.printStackTrace();
			exception = true;
			s_assert.assertFalse(exception, "\n" + Weblocator.printExceptionTrace(e));
		}
		s_assert.assertAll();
	}
	
	public void DataEntryWithAuth() {
		//login.login("anuragsin@hcl.com");
		dashboard.Transaction();
		Weblocator.TextField(trns.PickupLocationTextField, "MUM");
		Weblocator.TextField(trns.ProductTextField, "D-DBMICR");
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(1);
		Weblocator.TextField(trns.TotalDepTextField, "1");

		Weblocator.TextField(trns.TotalAmntField, "1000");

		String testdata=Weblocator.randomeNum();

		String TheirReferenceValue="TRef"+testdata;  //---------to be use in feature

		Weblocator.TextField(trns.TheirReferenceTextField,TheirReferenceValue);
		Weblocator.Openlinks(trns.saveBtn);
		Weblocator.explicitWait(1);
		elecomm.GeneralFetchingDataPopup();
		Weblocator.getWindowHandle();
		String batchno=Weblocator.GetAttributevalue(trns.batchTextField);
		System.out.println("Batch No : "+ batchno);
		Weblocator.explicitWait(1);
		Weblocator.TextField(trns.clientTextField, "ABIL");
		Weblocator.explicitWait(2);
		Weblocator.TextField(trns.totalInstTextfield, "1");
		Weblocator.explicitWait(2);
		Weblocator.TextField(trns.totalAmountTextfield, "1000");
		String depositer="Depno"+testdata;
		Weblocator.TextField(trns.inputDepositNoTextField, depositer);
		Weblocator.Openlinks(trns.saveBtn_DepositTAB);
		//elecomm.PopupHandle_dataSave();//-------------------with should
		Weblocator.explicitWait(2);
		dashboard.logout();
		//--------------------------------
		Weblocator.explicitWait(1);
		login.login(checkerName);
		Weblocator.explicitWait(1);
		dashboard.TransactionAuth();
		Weblocator.explicitWait(1);
		Weblocator.TextField(trns.batchFromTextField, batchno);
		Weblocator.TextField(trns.batchToTextField, batchno);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(trns.retrieveBtn);
		Weblocator.explicitWait(1);
		Weblocator.explicitWait(1);
		Weblocator.Openlinks(trns.authCheckBoxforABIL);
		Weblocator.explicitWait(1);
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();
		Weblocator.Openlinks(trns.saveBtn);
		Weblocator.explicitWait(1);
		//elecomm.PopupHandle_dataSave();
		Weblocator.getWindowHandle();
		Weblocator.Openlinks(elecomm.yesBtn2);
		Weblocator.getWindowHandle();
		Weblocator.explicitWait(1);
		elecomm.PopupHandle_dataSave();
		Weblocator.explicitWait(1);

		Weblocator.Openlinks(trns.retrieveBtn);
		Weblocator.explicitWait(1);
		String msg=elecomm.PopupHandle_dataSave();
		if (msg.equalsIgnoreCase("TA0000 - No records to retrieve")) {
			this.batchRefNo=batchno;
			this.thereRefNo=TheirReferenceValue;
			this.depositerRefNo=depositer;

			System.out.println("Batch No:"+this.batchRefNo);
			System.out.println("There Ref No:"+this.thereRefNo);
		}
		Weblocator.explicitWait(1);
		
	}

	public void DeferredCollectEntryWithAuth() throws AWTException {
		dashboard.DeferredCollectionEntryPage();
		String clientname=deferredcollEntry.retrieve(this.batchRefNo);
		s_assert.assertNotNull(clientname, "Client name geting null");
		if (StringUtils.isNotBlank(clientname)) {
			//WebDriverManager.scrollingByCoordinatesofAPage();
			Weblocator.explicitWait(1);
			Weblocator.DoubleClick(deferredcollEntry.selectFirstRow);
			Weblocator.explicitWait(1);
			String instrument_No="Test"+Weblocator.randomeNum();
			Weblocator.TextField(deferredcollEntry.instrumentNoTextField, instrument_No);
			Weblocator.explicitWait(1);
			Weblocator.TextField(deferredcollEntry.draweeBranchCodeTextField, "220028002");
			Weblocator.explicitWait(1);
			Weblocator.TextField(deferredcollEntry.instAmountTextField, "1000");
			Weblocator.explicitWait(1);
			Weblocator.TextFieldWithOutTAB(deferredcollEntry.instrumentDateStrTextField, "16/11/2018");
			Weblocator.Openlinks(elecomm.saveBtnF11);
			Weblocator.explicitWait(2);
			try {
				s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
			}catch (Exception e) {
				Weblocator.Openlinks(elecomm.saveBtnF11);
				s_assert.assertEquals(elecomm.PopupHandle_dataSave(),"Instrument(s) are saved successfully");
			}
			Weblocator.Openlinks(deferredcollEntry.clearBtn);
			dashboard.logout();
			Weblocator.getWindowHandle();
			login.login("rachitranjans@hcl.com");
			dashboard.DeferredCollectionEntryPageAuth();
			deferredcollEntryAuth.Clean_Retrieve();
			deferredcollEntryAuth.SearchBatchNo(this.batchRefNo);
			deferredcollEntryAuth.authentication(this.batchRefNo);
			String msg=deferredcollEntryAuth.BatchRemoveAfterAuth(this.batchRefNo);
			s_assert.assertEquals(msg, "No items to show.");
			if (msg.equalsIgnoreCase("No items to show.")) {
				instrumentRefNo=instrument_No;
			}
		}
		else {
			String msg=elecomm.PopupHandle_dataSave();
			System.out.println("Popup msg:  "+msg);
		}
	}

	public void DeferredEnrichmentEntryWithAuth() throws InterruptedException {

		Weblocator.explicitWait(1);
		dashboard.DeferredEnrichmentEntry();
		String enrichmentSet=verify_Add_New_Enrichment();
		System.out.println(enrichmentSet);

		dashboard.logout();
		//WebDriverManager.explicitWait(1);
		login.login("rachitranjans@hcl.com");
		dashboard.DeferredEnrichmentEntryAuth();
/*		enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
		WebDriverManager.DoubleClick(enrichmentEntryAuth.instNumberFirstRowInstrumentTab);
		s_assert.assertEquals(enrichmentSet,WebDriverManager.getPagetext(enrichmentEntryAuth.enrichSetGet));
		WebDriverManager.scrollingByCoordinatesofAPage_scrollUp();*/

		enrichmentEntryAuth.clear();
		enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
		String msg=enrichmentEntryAuth.auth();
		s_assert.assertEquals(msg, "TA0206-No records retrieved");
		Weblocator.scrollingByCoordinatesofAPage_scrollUp();

	/*	enrichmentEntryAuth.clear();
		enrichmentEntryAuth.retrieveandSearchInst("ANURAGSI");
		String msg1=elecomm.PopupHandle_dataSave();
		s_assert.assertEquals(msg1, "TA0206-No records retrieved");*/
	}
	public String verify_Add_New_Enrichment() throws InterruptedException {
		String clientname=enrichmentEntry.retrieve(instrumentRefNo);  //harcoded the value for now, integration with excel sheet is in progress
		String enrichmentSet=enrichmentEntry.openInstrumentAndSave("PORAS", Weblocator.randomeNum());
		return 	enrichmentSet;
	}

	public void InstrumentLiquidationWithAuth() {
		dashboard.InstrumentLiquidation();
		String status=instLiq.retrieve("D-DBMICR", this.thereRefNo);
		Weblocator.explicitWait(1);
		String instLiq_RefNo="InstLiqRef"+Weblocator.randomeNum();
		Weblocator.TextField(instLiq.refrenceNo, instLiq_RefNo);
		Weblocator.explicitWait(1);
		if (status.equalsIgnoreCase("New")) {
			Weblocator.explicitWait(2);
			Boolean clientNameIspresent=Weblocator.IselementPresent(instLiq.GetGridDetailsAfterSaveBtn);
			Weblocator.explicitWait(2);
			if (clientNameIspresent) {
				Weblocator.DoubleClick(instLiq.GetGridDetailsAfterSaveBtn);
				Weblocator.explicitWait(2);
				Weblocator.Openlinks(instLiq.liqTypeDropListBtn);
				Weblocator.explicitWait(1);
				Weblocator.Openlinks(instLiq.liqTypeDroplistOptionReturn);
				Weblocator.explicitWait(1);
				//WebDriverManager.TextField(link, entertext)
				Weblocator.TextField(instLiq.returnReasonTextField, "Testing return");
				Weblocator.clearText(instLiq.returnAmountTextField);
				Weblocator.TextField(instLiq.returnAmountTextField, "1000");
				Weblocator.scrollingByCoordinatesofAPage();
				Weblocator.Openlinks(elecomm.saveBtnF11Capital);
				Weblocator.explicitWait(5);
				Weblocator.getWindowHandle();
				//WebDriverManager.Openlinks(elecomm.selectBtn);
				Weblocator.getWindowHandle();
				String clientnameonGrid=Weblocator.Getactualtext(instLiq.GetGridDetailsAfterSaveBtn);
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
			}
			else {
				String clientnameonGrid=instLiq.addInst("ABIL", "1000","Return");
				s_assert.assertEquals(clientnameonGrid, "ABIL","Client name is not match");
			}
		}
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(dashboard.instrumentLiquidationMenu);
		dashboard.logout();
		login.login("rachitranjans@hcl.com");
		dashboard.InstrumentLiquidationAuth();
		Weblocator.explicitWait(2);
		Weblocator.Openlinks(elecomm.clearBtnF1);
		String msg=instLiqAuth.retrive(instLiq_RefNo);
		Weblocator.explicitWait(2);
		instLiqAuth.auth();
		instLiqRefNo=instLiq_RefNo;
		Weblocator.Openlinks(dashboard.instrumentLiquidationAuthSubMenu);
	}

	public void InstrumentReceiptWithAuth() throws InterruptedException {
		dashboard.InstrumentReceipt();
		String schduleno=instReceipt.retrieve("D-DBMICR", this.thereRefNo);
		s_assert.assertNotNull(schduleno, "Schdule not is not Null");
		String refNo="RefNo"+Weblocator.randomeNum();
		String noItemMsg=instReceipt.recivedVerify(refNo);
		s_assert.assertEquals(noItemMsg, "No items to show.","Msg Not Match");
		Weblocator.Openlinks(dashboard.instrumentReceiptMenu);
		dashboard.logout();
		login.login("rachitranjans@hcl.com");
		dashboard.InstrumentReceiptAuth();
		instReceiptAuth.retrieve("D-DBMICR", "ANURAGSI");
		instReceiptAuth.auth(refNo);
		Weblocator.Openlinks(dashboard.instrumentReceiptAuthSubMenu);
	}

	public void DeferredRemarksEntryWithAuth() throws InterruptedException {
		dashboard.DeferredRemarksEntry();
		Weblocator.TextField(remarksEntry.depositTextField, this.depositerRefNo);
		remarksEntry.retrieve();
		String clientName=Weblocator.getPagetext(remarksEntry.clientNameFirstRow);
		String date=Weblocator.getPagetext(remarksEntry.dateFirstRow);
		String remark="test"+Weblocator.randomeNum();
		remarksEntry.modify(remark);

		dashboard.logout();
		login.login("rachitranjans@hcl.com");
		dashboard.DeferredRemarksEntryAuth();
		Weblocator.Openlinks(elecomm.clearBtnF1);

		Boolean clientname=remarksEntryAuth.retrieve("anuragsi");
		s_assert.assertTrue(clientname, "clientName is not present");

		Weblocator.Openlinks(elecomm.clearBtnF1);
		remarksEntryAuth.retrieve("anuragsi");
		Weblocator.TextField(remarksEntryAuth.depositFilter, this.depositerRefNo);
		Weblocator.PressEnterBtn(remarksEntryAuth.depositFilter);
		//WebDriverManager.explicitWait(1);
		String noItm=remarksEntryAuth.auth();
		//s_assert.assertEquals(noItm, "No items to show.");
		Weblocator.Openlinks(dashboard.DeferredRemarksMenuAuth);
	}

	public void ScheduleLiquidationWithAuth() {
		dashboard.scheduleLiquidation();
		Boolean status=schLiq.retrieve("D-DBMICR", "DB", "784");
		s_assert.assertTrue(status, "No Records founds");
		if (status) {
			String schLiqNo=schLiq.searchFilter(this.thereRefNo);
			if (!schLiqNo.equals("No Items Founds")) {
				String msg=schLiq.paid(this.thereRefNo);
				s_assert.assertEquals(msg, "No items to show.", "No items MSG not present");
			}
			s_assert.assertNotEquals(schLiqNo, "No items Founds","No items msg is present");
		}

		dashboard.logout();
		login.login(checkerName);
		dashboard.scheduleLiquidationAuth();
		Boolean status1=schLiqAuth.retrieve("anuragsi");
		if (status1) {
			Weblocator.Openlinks(schLiqAuth.scheduleDateFirstCol);
			Weblocator.Openlinks(elecomm.userinfoBtnF10);
			Weblocator.getWindowHandle();
			Boolean check=Weblocator.IselementPresent(elecomm.makerName_schLiqauth);
			s_assert.assertTrue(check, "Maker Name is not present");
			Weblocator.Openlinks(elecomm.userInfoClose);
			Weblocator.getWindowHandle();
		}
		s_assert.assertTrue(status1, "No data found");
		Weblocator.Openlinks(elecomm.clearBtnF1);
		Weblocator.Openlinks(dashboard.scheduleLiquidationAuthSubMenu);
	}
	
	public void InstrumentLiqStatReversalWithAuth() {
		dashboard.InstrumentLiqStatReversal();
		Boolean status=instLiqStatReversal.retrieve("D-DBMICR", this.thereRefNo);
		if (status) {
			boolean status1=instLiqStatReversal.modify();
			if (status1) {
				boolean status2=instLiqStatReversal.modifyWithOption("Paid", "Payment stopped by the drawer." ,"Return "+elecomm.loginUserName()+""+Weblocator.GetDateTime());
				if (status2) {
					String reveStatus=instLiqStatReversal.reversalStatusGet();
					if (!reveStatus.equals(null)) {
						dashboard.logout();
						login.login(checkerName);
						dashboard.InstrumentLiqStatReversalAuth();
						boolean productcode=instLiqStatReversalAuth.retrieve();
						if (productcode) {
							boolean msg=instLiqStatReversalAuth.reject(this.thereRefNo, "reject "+elecomm.loginUserName()+""+Weblocator.GetDateTime());
							if (msg) {
								boolean productcode1=instLiqStatReversalAuth.retrieve();
								if (productcode1) {
									String msgnotfound=instLiqStatReversalAuth.auth(this.thereRefNo);
									s_assert.assertNotNull(msgnotfound, "Not found message not present");
								}
								s_assert.assertTrue(productcode1, "after retrive btn productcode1 Not is not prsent");
							}
							s_assert.assertTrue(msg, "Reject Message is not present");
						}
						s_assert.assertTrue(productcode, "after retrive btn productcode Not is not prsent");
					}
					s_assert.assertNotNull(reveStatus, "reversal Status Getting Null");
				}
				s_assert.assertTrue(status2, "return Drop down is not present");
			}
			s_assert.assertTrue(status1, "Modify link not open");
		}
		s_assert.assertTrue(status, "No Records found");
	
	}


}